// 데모 정적 서버 (Node 만으로 — 파이썬이 없는 PC 에서도 돈다). 데모 폴더를 8791 로 연다.
// IPv4·IPv6 둘 다 받는다 (크롬은 localhost 를 IPv6 로 먼저 찾음).
import { createServer } from 'node:http';
import { createReadStream, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, normalize, extname, sep } from 'node:path';
import { getWeather } from './weather.mjs';
import { getTrains } from './trains.mjs';
import { crowdResponse } from './crowd.mjs';

const demo = join(dirname(dirname(fileURLToPath(import.meta.url))), '데모');
const PORT = Number(process.argv[2]) || 8791;
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.md': 'text/plain; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.mp3': 'audio/mpeg',
};

/* /api/* 요청 제한: IP 당 분당 30회 (터널 뒤에서는 X-Forwarded-For 첫 값) */
const hits = new Map();
function limited(req) {
  let ip = req.socket.remoteAddress || '';
  if (/^(::1|127\.|::ffff:127\.)/.test(ip)) { const f = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim(); if (f) ip = f; }
  const now = Date.now(), a = (hits.get(ip) || []).filter((t) => now - t < 60e3);
  a.push(now); hits.set(ip, a);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > 60e3) hits.delete(k);
  return a.length > 30;
}
/* 공개 허용 목록: 화면이 실제로 부르는 종류만. 내부 자료(캐시·백업·시험·수집 스크립트·README)는 막는다. */
const ALLOW = new Set(['.html', '.js', '.css', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.ico', '.mp3']);
const DENY_DIR = new Set(['수집캐시', '길캐시', 'tour_백업_사진전', 'backup', 'node_modules']);
function allowed(rel) {
  const parts = rel.split(/[\\/]/).filter(Boolean);
  if (parts.some((s) => DENY_DIR.has(s) || s.startsWith('.'))) return false;
  const name = parts[parts.length - 1] || '';
  if (/\.before|\.bak|\.base\./i.test(name) || /^test[.\-_]/i.test(name) || /\.test\./i.test(name)) return false;
  return ALLOW.has(extname(name).toLowerCase());
}

createServer((req, res) => {
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { res.writeHead(400).end(); return; }
  if (p.startsWith('/api/') && limited(req)) { res.writeHead(429, { 'Content-Type': 'application/json; charset=utf-8', 'Retry-After': '60' }).end(JSON.stringify({ ok: false, error: 'rate_limited' })); return; }
  if (p === '/api/weather') { // 동해 날씨(기상청) — 키는 서버에서만 쓰고 브라우저는 결과만 받는다
    getWeather().then((w) => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(w)); })
      .catch(() => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ error: 'fail' })); });
    return;
  }
  if (p === '/api/trains') { // 기차 시간표(국토교통부 TAGO) — ?date=YYYYMMDD&from=묵호&to=청량리. 키는 서버에서만
    const q = new URL(req.url, 'http://x').searchParams;
    getTrains(q.get('date'), q.get('from'), q.get('to')).then((v) => { res.writeHead(v && v.error === 'bad_request' ? 400 : 200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(v)); })
      .catch(() => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ ok: false, error: 'fail' })); });
    return;
  }
  if (p === '/api/crowd') { // 관광지 집중률 예측(한국관광공사) — 하루 한 번 받아 둔 값. ?date=YYYYMMDD 면 그 날 값만. 키는 서버에서만
    const q = new URL(req.url, 'http://x').searchParams;
    crowdResponse(q.get('date')).then((r) => { res.writeHead(r.status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(r.body)); })
      .catch(() => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ ok: false, error: 'fail' })); });
    return;
  }
  let file = normalize(join(demo, p));
  if (!file.startsWith(demo + sep) && file !== demo) { res.writeHead(403).end(); return; } // 폴더 밖 금지
  try {
    let st = statSync(file);
    if (st.isDirectory()) {
      if (!p.endsWith('/')) { res.writeHead(301, { Location: encodeURI(p) + '/' }).end(); return; }
      file = join(file, 'index.html'); st = statSync(file);
    }
    if (!allowed(file.slice(demo.length + 1))) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('없음'); return; }
    res.writeHead(200, { 'Content-Type': TYPES[extname(file).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-cache' });
    createReadStream(file).pipe(res);
  } catch { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('없음'); }
}).listen({ port: PORT, host: '::', ipv6Only: false }, () => console.log(`demo server http://localhost:${PORT}/`));
