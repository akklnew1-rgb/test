// 데모 서버(8791) 끄기: 포트를 잡고 있는 프로세스를 찾아 종료한다.
import { execSync } from 'node:child_process';
const PORT = 8791;
let out = '';
try { out = execSync('netstat -ano -p tcp', { encoding: 'utf8' }); } catch {}
const pids = new Set();
for (const line of out.split(/\r?\n/)) {
  const m = line.trim().match(/^TCP\s+\S+:(\d+)\s+\S+\s+LISTENING\s+(\d+)$/);
  if (m && Number(m[1]) === PORT) pids.add(m[2]);
}
if (!pids.size) { console.log('떠 있는 데모 서버가 없습니다.'); process.exit(0); }
for (const pid of pids) {
  try { execSync(`taskkill /PID ${pid} /F`, { stdio: 'ignore' }); console.log(`서버를 껐습니다 (PID ${pid})`); }
  catch { console.log(`끄지 못했습니다 (PID ${pid})`); }
}
