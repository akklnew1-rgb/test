// 날씨·기차 시간표 서버 코드 시험 — 가짜 응답(fixture)만 쓰고 인터넷은 쓰지 않는다. node run/test-api.mjs
import { toGrid, GRID } from './weather.mjs';
import { parseTrains, STATION_ID } from './trains.mjs';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ok  ' + m); } else { fail++; console.log('  FAIL ' + m); } };
console.log('[API] 기상청 격자 · TAGO 열차 시간표 파서');
ok(GRID.nx === 97 && GRID.ny === 127, `동해시 묵호동 격자 ${GRID.nx},${GRID.ny} (97,127)`);
const seoul = toGrid(37.5665, 126.9780); ok(seoul.nx === 60 && seoul.ny === 127, `격자 변환 식 확인: 서울 시청 ${seoul.nx},${seoul.ny} (공식 60,127)`);
const fx = { response: { header: { resultCode: '00' }, body: { items: { item: [
  { depplandtime: 20261018141000, arrplandtime: 20261018174300, traingradename: 'KTX-이음', trainno: '8004' },
  { depplandtime: 20261018071200, arrplandtime: 20261018104500, traingradename: 'KTX-이음', trainno: '8000' }] } } } };
const l = parseTrains(fx);
ok(l.length === 2 && l[0].dep === '07:12' && l[0].arr === '10:45' && l[1].dep === '14:10' && l[1].grade === 'KTX-이음', '열차 응답 → 출발 시각 순 목록(07:12, 14:10)');
const one = parseTrains({ response: { body: { items: { item: { depplandtime: '20261018190400', arrplandtime: '20261018221500', traingradename: 'ITX', trainno: '1' } } } } });
ok(one.length === 1 && one[0].dep === '19:04', '열차 한 대만 와도(배열이 아니어도) 읽음');
ok(parseTrains({}).length === 0 && parseTrains({ response: { body: { items: '' } } }).length === 0, '빈 응답은 빈 목록');
ok(STATION_ID['묵호'] === 'NAT601545' && STATION_ID['동해'] === 'NAT601485' && STATION_ID['청량리'] === 'NAT130126' && STATION_ID['서울'] === 'NAT010000', '역 번호(묵호·동해·청량리·서울)');
console.log(`API 결과: 통과 ${pass} · 실패 ${fail}`);
process.exit(fail ? 1 : 0);
