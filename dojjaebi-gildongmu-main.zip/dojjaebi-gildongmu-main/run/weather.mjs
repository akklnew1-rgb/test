// 동해 날씨(기상청 단기예보 초단기실황) — 서버쪽 전용. 키는 설정/공공데이터.json 의 datagokr_key 만 읽고 어디에도 찍지 않는다.
// serve.mjs 의 /api/weather 와 묶음.mjs(묶음 만들 때 한 번 받아 넣는 날씨 사진)가 같이 쓴다.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const CFG = join(dirname(here), '설정', '공공데이터.json');
const BASE = 'https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/';

/* 기상청 격자 변환(공식 LCC DFS 식). 위도·경도 → 격자 nx, ny */
export function toGrid(lat, lng) {
  const RE = 6371.00877, GRID = 5.0, SLAT1 = 30.0, SLAT2 = 60.0, OLON = 126.0, OLAT = 38.0, XO = 43, YO = 136;
  const D2R = Math.PI / 180;
  const re = RE / GRID, slat1 = SLAT1 * D2R, slat2 = SLAT2 * D2R, olon = OLON * D2R, olat = OLAT * D2R;
  let sn = Math.tan(Math.PI * 0.25 + slat2 * 0.5) / Math.tan(Math.PI * 0.25 + slat1 * 0.5);
  sn = Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(sn);
  let sf = Math.tan(Math.PI * 0.25 + slat1 * 0.5); sf = Math.pow(sf, sn) * Math.cos(slat1) / sn;
  let ro = Math.tan(Math.PI * 0.25 + olat * 0.5); ro = re * sf / Math.pow(ro, sn);
  let ra = Math.tan(Math.PI * 0.25 + lat * D2R * 0.5); ra = re * sf / Math.pow(ra, sn);
  let theta = lng * D2R - olon;
  if (theta > Math.PI) theta -= 2 * Math.PI;
  if (theta < -Math.PI) theta += 2 * Math.PI;
  theta *= sn;
  return { nx: Math.floor(ra * Math.sin(theta) + XO + 0.5), ny: Math.floor(ro - ra * Math.cos(theta) + YO + 0.5) };
}
export const DONGHAE = { lat: 37.5498, lng: 129.1167 }; // 묵호동 가운데(묵호항 쪽) → 격자 97,127
export const GRID = toGrid(DONGHAE.lat, DONGHAE.lng);

const p2 = (n) => String(n).padStart(2, '0');
function kst(msAgo = 0) { const d = new Date(Date.now() + 9 * 3600e3 - msAgo); return { y: d.getUTCFullYear(), mo: d.getUTCMonth() + 1, d: d.getUTCDate(), h: d.getUTCHours(), mi: d.getUTCMinutes() }; }
const ymd = (t) => `${t.y}${p2(t.mo)}${p2(t.d)}`;

async function call(op, params, key) {
  const qs = new URLSearchParams({ dataType: 'JSON', numOfRows: '60', pageNo: '1', nx: String(GRID.nx), ny: String(GRID.ny), ...params }).toString();
  const res = await fetch(BASE + op + '?serviceKey=' + encodeURIComponent(key) + '&' + qs, { signal: AbortSignal.timeout(8000) });
  const txt = await res.text();
  if (res.status === 403 || /NOT_REGISTERED|NOT REGISTERED/i.test(txt)) { const e = new Error('not_registered'); e.code = 'not_registered'; throw e; }
  let j; try { j = JSON.parse(txt); } catch { throw new Error('bad_response'); }
  const h = j && j.response && j.response.header;
  if (!h || h.resultCode !== '00') { const e = new Error('api_' + (h && h.resultCode)); e.code = 'fail'; throw e; }
  const it = j.response.body && j.response.body.items && j.response.body.items.item;
  return Array.isArray(it) ? it : it ? [it] : [];
}

const SKY_TEXT = { 1: '맑음', 3: '구름 많음', 4: '흐림' };
const PTY_TEXT = { 0: '', 1: '비', 2: '비 또는 눈', 3: '눈', 5: '빗방울', 6: '빗방울·눈날림', 7: '눈날림' };

let cache = null, cacheAt = 0;
/* 10분 캐시. 돌려주는 값: { temp(℃), sky(1·3·4), pty(0 없음), text(맑음·흐림·비 …), wind(m/s), rain1h(mm), baseTime('HH:00'), baseDate, at(ISO) } 또는 { error:'not_registered'|'fail' } */
export async function getWeather() {
  if (cache && Date.now() - cacheAt < 10 * 60e3) return cache;
  let key = '';
  key = process.env.DATAGOKR_KEY || ''; // 공개 서버(Vercel)는 환경 변수
  if (!key) try { key = JSON.parse(readFileSync(CFG, 'utf8')).datagokr_key || ''; } catch { /* 없음 */ }
  if (!key) return { error: 'fail' };
  try {
    const t = kst(40 * 60e3); // 실황은 정시 약 40분 뒤에 올라온다 → 40분 전 정시를 기준으로
    const ncst = await call('getUltraSrtNcst', { base_date: ymd(t), base_time: p2(t.h) + '00' }, key);
    const v = {}; ncst.forEach((x) => { v[x.category] = x.obsrValue; });
    let sky = 0;
    try { // 하늘 상태는 초단기예보에서(첫 시각). 실패해도 날씨 카드는 만든다.
      const t2 = kst(45 * 60e3), bt = (t2.mi >= 30 ? p2(t2.h) : p2((t2.h + 23) % 24)) + '30';
      const bd = t2.mi >= 30 || t2.h > 0 ? ymd(t2) : ymd(kst(24 * 3600e3 + 45 * 60e3));
      const fc = await call('getUltraSrtFcst', { base_date: bd, base_time: bt }, key);
      const s = fc.filter((x) => x.category === 'SKY').sort((a, b) => (a.fcstDate + a.fcstTime).localeCompare(b.fcstDate + b.fcstTime))[0];
      if (s) sky = +s.fcstValue;
    } catch (e) { if (e.code === 'not_registered') throw e; }
    const pty = +v.PTY || 0, temp = v.T1H != null ? +v.T1H : null;
    if (temp == null) return { error: 'fail' };
    const text = pty > 0 ? (PTY_TEXT[pty] || '비') : (SKY_TEXT[sky] || '');
    cache = { temp, sky, pty, text, wind: v.WSD != null ? +v.WSD : null, rain1h: parseFloat(v.RN1) || 0, baseTime: p2(t.h) + ':00', baseDate: ymd(t), at: new Date().toISOString() };
    cacheAt = Date.now();
    return cache;
  } catch (e) {
    return { error: e.code === 'not_registered' ? 'not_registered' : 'fail' };
  }
}
