// ASCII entry for the .bat (cmd can't handle Korean paths)
import '../도구/카카오키넣기.mjs';
