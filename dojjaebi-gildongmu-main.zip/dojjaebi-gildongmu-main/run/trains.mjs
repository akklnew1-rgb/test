// 기차 시간표(국토교통부 TAGO 열차정보) — 서버쪽 전용. 키는 설정/공공데이터.json 의 datagokr_key 만 읽고 어디에도 찍지 않는다.
// serve.mjs 의 /api/trains 와 묶음.mjs(묶음 만들 때 앞으로 며칠 치를 받아 넣는 시간표 사진)가 같이 쓴다.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const CFG = join(dirname(dirname(fileURLToPath(import.meta.url))), '설정', '공공데이터.json');
const BASE = 'https://apis.data.go.kr/1613000/TrainInfo/GetStrtpntAlocFndTrainInfo';
export const STATION_ID = { 묵호: 'NAT601545', 동해: 'NAT601485', 강릉: 'NAT601936', 정동진: 'NAT601774', 청량리: 'NAT130126', 서울: 'NAT010000' };

/* API 응답(JSON 글) → [{ dep:'HH:MM', arr:'HH:MM', grade, no }] 출발 시각 순. 시험에서 가짜 응답으로도 쓴다. */
export function parseTrains(j) {
  const it = j && j.response && j.response.body && j.response.body.items && j.response.body.items.item;
  const arr = Array.isArray(it) ? it : it ? [it] : [];
  const hm = (v) => { const s = String(v || ''); return s.length >= 12 ? s.slice(8, 10) + ':' + s.slice(10, 12) : ''; };
  return arr.map((x) => ({ dep: hm(x.depplandtime), arr: hm(x.arrplandtime), grade: String(x.traingradename || ''), no: String(x.trainno || '') }))
    .filter((x) => x.dep).sort((a, b) => a.dep.localeCompare(b.dep));
}

/* 실제 있는 날짜 + 한국시간 오늘-1 … 오늘+30 만 받는다 (그 밖은 상류 호출 없이 400) */
export function validDate(date) {
  const s = String(date);
  if (!/^\d{8}$/.test(s)) return false;
  const y = +s.slice(0, 4), m = +s.slice(4, 6), d = +s.slice(6, 8), dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return false;
  const today = new Date(Date.now() + 9 * 3600e3), t0 = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
  const diff = Math.round((dt.getTime() - t0) / 86400e3);
  return diff >= -1 && diff <= 30;
}

const cache = new Map(); // 날짜|from|to → { at, v }  (성공 6시간 · 실패 5분)
/* date: 'YYYYMMDD' · from/to: 묵호|동해|청량리|서울 … 돌려주는 값 { ok:true, date, from, to, list:[…] } 또는 { ok:false, error } */
export async function getTrains(date, from, to) {
  const own = (o, k) => typeof k === 'string' && Object.prototype.hasOwnProperty.call(o, k);
  if (!own(STATION_ID, from) || !own(STATION_ID, to) || !validDate(date)) return { ok: false, error: 'bad_request' };
  const k = date + '|' + from + '|' + to, hit = cache.get(k);
  if (hit && Date.now() - hit.at < (hit.v.ok ? 6 * 3600e3 : 5 * 60e3)) return hit.v;
  let key = '';
  key = process.env.DATAGOKR_KEY || ''; // 공개 서버(Vercel)는 환경 변수
  if (!key) try { key = JSON.parse(readFileSync(CFG, 'utf8')).datagokr_key || ''; } catch { /* 없음 */ }
  const fail = (e) => { const v = { ok: false, error: e }; cache.set(k, { at: Date.now(), v }); return v; };
  if (!key) return { ok: false, error: 'no_key' };
  try {
    const qs = new URLSearchParams({ _type: 'json', numOfRows: '60', pageNo: '1', depPlaceId: STATION_ID[from], arrPlaceId: STATION_ID[to], depPlandTime: date }).toString();
    const res = await fetch(BASE + '?serviceKey=' + encodeURIComponent(key) + '&' + qs, { signal: AbortSignal.timeout(8000) });
    const txt = await res.text();
    let j; try { j = JSON.parse(txt); } catch { return fail(/NOT_REGISTERED|NOT REGISTERED/i.test(txt) || res.status === 403 ? 'not_registered' : 'bad_response'); }
    const h = j && j.response && j.response.header;
    if (!h || h.resultCode !== '00') return fail('api_' + (h && h.resultCode));
    const list = parseTrains(j);
    const v = { ok: list.length > 0, date, from, to, list, source: '국토교통부 TAGO 열차정보(코레일)' };
    if (!list.length) v.error = 'empty';
    cache.set(k, { at: Date.now(), v });
    return v;
  } catch { return fail('fail'); }
}
