// 관광지 집중률 방문자 추이 예측(한국관광공사 TatsCnctrRateService) — 서버쪽 전용. 키는 설정/공공데이터.json 의 datagokr_key 만 읽고 어디에도 찍지 않는다.
// 동해시 30곳 × 오늘부터 30일, 하루 한 값(시간대 없음, 100 = 가장 붐빔). 하루 한 번만 받아 파일(데모/tour/수집캐시/crowd.json)에 둔다.
// serve.mjs 의 /api/crowd 와 묶음.mjs(CROWD_SNAPSHOT)가 같이 쓴다.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const CFG = join(ROOT, '설정', '공공데이터.json');
const REPO_CACHE = join(ROOT, '데모', 'tour', '수집캐시', 'crowd.json');
const CACHE_DIR = process.env.VERCEL ? '/tmp/crowd' : dirname(REPO_CACHE); // Vercel 은 /tmp 만 쓸 수 있다
const CACHE = join(CACHE_DIR, 'crowd.json');
const BASE = 'https://apis.data.go.kr/B551011/TatsCnctrRateService/tatsCnctrRatedList';
export const SOURCE = '한국관광공사 관광지 집중률 예측 · 통신 데이터 기반 · 날짜별 예측(실시간 아님)';

const ymd = (d) => d.getUTCFullYear() + String(d.getUTCMonth() + 1).padStart(2, '0') + String(d.getUTCDate()).padStart(2, '0');
export function todayKst() { return ymd(new Date(Date.now() + 9 * 3600e3)); }
export function realDate(s) {
  s = String(s);
  if (!/^\d{8}$/.test(s)) return false;
  const y = +s.slice(0, 4), m = +s.slice(4, 6), d = +s.slice(6, 8), dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

/* API 응답(JSON) 또는 저장해 둔 표본(배열) → { baseYmd, from, to, days, spots:{이름:{YYYYMMDD:값}} }. 시험에서 가짜 응답으로도 쓴다. */
export function parseCrowd(j) {
  const it = Array.isArray(j) ? j : (j && j.response && j.response.body && j.response.body.items && j.response.body.items.item);
  const rows = Array.isArray(it) ? it : it ? [it] : [];
  const spots = {}, days = new Set();
  for (const x of rows) {
    const name = String(x.tAtsNm || '').trim(), d = String(x.baseYmd || ''), v = Number(x.cnctrRate);
    if (!name || !/^\d{8}$/.test(d) || !isFinite(v) || v < 0 || v > 1000) continue;
    (spots[name] = spots[name] || {})[d] = Math.round(v * 10) / 10; days.add(d);
  }
  const list = [...days].sort();
  return { baseYmd: list[0] || '', from: list[0] || '', to: list[list.length - 1] || '', spots };
}
/* 오늘(KST)이 받아 둔 날짜 범위 안에 있나 */
export function covers(v, today) { return !!(v && v.from && v.to && today >= v.from && today <= v.to); }

let mem = null; // { at, v }
function readCache() { for (const f of [CACHE, REPO_CACHE]) { try { return JSON.parse(readFileSync(f, 'utf8')); } catch { /* 다음 */ } } return null; }
function writeCache(v) { try { mkdirSync(CACHE_DIR, { recursive: true }); writeFileSync(CACHE, JSON.stringify(v)); } catch { /* 무시 */ } }

/* 전체: { ok:true, baseYmd, from, to, spots, source, fetchedAt } 또는 { ok:false, error }.
   하루 한 번 새로 받는다(한국 날짜가 바뀌었거나 오늘이 받아 둔 범위 밖이면). 못 받으면 아직 오늘을 덮는 옛 값을 그대로, 그것도 없으면 ok:false */
export async function getCrowd() {
  const today = todayKst();
  if (mem && mem.v.ok && mem.fetchDay === today) return mem.v;
  if (mem && !mem.v.ok && Date.now() - mem.at < 5 * 60e3) return mem.v;
  const disk = readCache();
  if (disk && disk.fetchDay === today && covers(disk, today)) { mem = { at: Date.now(), v: { ok: true, ...disk }, fetchDay: today }; return mem.v; }
  let key = '';
  key = process.env.DATAGOKR_KEY || ''; // 공개 서버(Vercel)는 환경 변수
  if (!key) try { key = JSON.parse(readFileSync(CFG, 'utf8')).datagokr_key || ''; } catch { /* 없음 */ }
  const stale = disk && covers(disk, today) ? { ok: true, ...disk, stale: true } : null;
  const fail = (e) => { const v = stale || { ok: false, error: e }; mem = { at: Date.now(), v, fetchDay: stale ? '' : today }; return v; };
  if (!key) return fail('no_key');
  try {
    const qs = new URLSearchParams({ numOfRows: '1000', pageNo: '1', MobileOS: 'ETC', MobileApp: 'dokkaebi', _type: 'json', areaCd: '51', signguCd: '51170' }).toString();
    const res = await fetch(BASE + '?serviceKey=' + encodeURIComponent(key) + '&' + qs, { signal: AbortSignal.timeout(12000) });
    const txt = await res.text();
    let j; try { j = JSON.parse(txt); } catch { return fail(/NOT_REGISTERED|NOT REGISTERED/i.test(txt) || res.status === 403 ? 'not_registered' : 'bad_response'); }
    const h = j && j.response && j.response.header;
    if (!h || (h.resultCode !== '0000' && h.resultCode !== '00')) return fail('api_' + (h && h.resultCode));
    const p = parseCrowd(j);
    if (!Object.keys(p.spots).length || !covers(p, today)) return fail('empty');
    const v = { ok: true, ...p, source: SOURCE, fetchedAt: new Date().toISOString(), fetchDay: today };
    writeCache({ baseYmd: v.baseYmd, from: v.from, to: v.to, spots: v.spots, source: v.source, fetchedAt: v.fetchedAt, fetchDay: today });
    mem = { at: Date.now(), v, fetchDay: today };
    return v;
  } catch { return fail('fail'); }
}

/* 서버 응답: date 없으면 전체, 있으면 그 날 값만 { ok, date, rates:{이름:값} }. 날짜가 이상하면 bad_request, 받아 둔 범위 밖이면 out_of_range */
export async function crowdResponse(date) {
  if (date != null && date !== '') {
    if (!realDate(date)) return { status: 400, body: { ok: false, error: 'bad_request' } };
    const all = await getCrowd();
    if (!all.ok) return { status: 200, body: { ok: false, error: all.error || 'fail' } };
    if (date < all.from || date > all.to) return { status: 200, body: { ok: false, error: 'out_of_range', from: all.from, to: all.to } };
    const rates = {}; for (const [n, m] of Object.entries(all.spots)) if (m[date] != null) rates[n] = m[date];
    return { status: 200, body: { ok: true, date, rates, baseYmd: all.baseYmd, source: all.source } };
  }
  const all = await getCrowd();
  if (!all.ok) return { status: 200, body: { ok: false, error: all.error || 'fail' } };
  const { fetchDay, ...pub } = all; // eslint-disable-line no-unused-vars
  return { status: 200, body: pub };
}
