// 데모 실행기: 지도 키 적용 → 로컬 서버(8791) → 크롬. 한글 경로를 cmd 가 못 다뤄서 Node 가 전부 맡는다.
// 10/17: 파이썬(고정 경로) 대신 Node 서버(run/serve.mjs) 사용 — 노트북 등 파이썬 없는 PC 에서도 열리게.
//        크롬이 없으면 기본 브라우저로 연다. 실패하면 이유를 보여 주고 run/open.log 에 남긴다.
import { spawn, execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { existsSync, appendFileSync } from 'node:fs';

const here = dirname(fileURLToPath(import.meta.url));
const root = dirname(here);
const PORT = 8791;
const LOG = join(here, 'open.log');
const log = (m) => { console.log(m); try { appendFileSync(LOG, `${new Date().toISOString()} ${m}\n`); } catch {} };
// 선택 인자: node run/open.mjs tour/  → http://localhost:8791/tour/ (없으면 기존처럼 첫 화면)
const sub = (process.argv[2] || '').replace(/^[\\/]+/, '').replace(/\\/g, '/');
const URL_OPEN = `http://localhost:${PORT}/${sub}`;

const chromes = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
];
function openBrowser(url) {
  const c = chromes.find((p) => p && existsSync(p));
  if (c) spawn(c, [url], { detached: true, stdio: 'ignore' }).unref();
  else { log('크롬을 못 찾아 기본 브라우저로 엽니다'); spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref(); }
}
async function alive() {
  try { const r = await fetch(`http://127.0.0.1:${PORT}/`, { signal: AbortSignal.timeout(1500) }); return r.status < 500; } catch { return false; }
}

log(`시작 (node ${process.version}, ${URL_OPEN})`);
console.log('지도 키를 적용하는 중...');
try { execFileSync(process.execPath, [join(root, '도구', '지도키적용.mjs')], { stdio: 'inherit' }); } catch { log('지도 키 적용 실패 — 지도 대신 글·그림 안내로 열립니다'); }

if (await alive()) {
  log(`서버가 이미 떠 있습니다 (포트 ${PORT}). 브라우저만 엽니다.`);
  openBrowser(URL_OPEN);
  process.exit(0);
}

log(`서버를 뒤에서 띄웁니다 (http://localhost:${PORT}/). 끌 때는 "데모 끄기.bat".`);
// 검은 창을 닫아도 서버가 죽지 않도록 창 없이 분리해서 띄운다
spawn(process.execPath, [join(here, 'serve.mjs'), String(PORT)], { cwd: root, detached: true, stdio: 'ignore', windowsHide: true }).unref();
let ok = false;
for (let i = 0; i < 20 && !ok; i++) { await new Promise((r) => setTimeout(r, 300)); ok = await alive(); }
if (!ok) {
  log(`서버가 뜨지 않았습니다. 포트 ${PORT} 를 다른 프로그램이 쓰는지 확인하세요 ("데모 끄기.bat" 후 다시).`);
  process.exit(1);
}
openBrowser(URL_OPEN);
log('브라우저를 열었습니다. 이 창은 닫아도 됩니다.');
process.exit(0);
