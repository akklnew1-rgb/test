// 시연 서버 지킴이 (2026-10-18 사용자 "PC 켜면 자동, 꺼지면 다시") — 작업 스케줄러 \동해시공모전\server 가
// 로그온 3분 뒤 + 30분마다 부른다. 8791 이 응답하지 않으면 run/serve.mjs 를 창 없이 띄운다. 떠 있으면 아무것도 안 함.
// 8791 은 관광 시연(데모/tour/, 공개 주소 :10000/tour/)과 약국 데모가 같이 쓰는 서버 — 끄지 말 것.
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { appendFileSync } from 'node:fs';

const here = dirname(fileURLToPath(import.meta.url));
const LOG = join(here, 'open.log');
const log = (m) => { try { appendFileSync(LOG, `${new Date().toISOString()} [지킴이] ${m}\n`); } catch {} };

async function alive() {
  try { const r = await fetch('http://127.0.0.1:8791/', { signal: AbortSignal.timeout(3000) }); return r.status < 500; } catch { return false; }
}

if (await alive()) process.exit(0);
spawn(process.execPath, [join(here, 'serve.mjs')], { cwd: dirname(here), detached: true, stdio: 'ignore', windowsHide: true }).unref();
await new Promise((r) => setTimeout(r, 2500));
log((await alive()) ? '서버가 꺼져 있어 다시 켬' : '다시 켜기 실패 — serve.mjs 확인');
process.exit(0);
