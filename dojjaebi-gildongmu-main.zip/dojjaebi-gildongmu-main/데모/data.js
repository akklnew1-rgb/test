window.DATA = {
 "generatedAt": "2026-10-10T04:24:23.010Z",
 "center": {
  "lat": 37.5247,
  "lng": 129.1143
 },
 "status": {
  "hospitals": 105,
  "hours": 38,
  "er": 2,
  "erRealtime": 1,
  "erMessages": 0,
  "pharmacies": 37,
  "pharmacyHours": 1
 },
 "pharmacyStatus": "ok",
 "notes": [],
 "hospitals": [
  {
   "name": "근로복지공단 동해병원",
   "type": "종합병원",
   "addr": "강원특별자치도 동해시 하평로 11, (평릉동)",
   "tel": "033-530-3100",
   "lng": 129.106078,
   "lat": 37.5321225,
   "dong": "평릉동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkODkkMzgxMzUxIzExIyQxIyQzIyQ5OSQzNjE0ODEjODEjJDEjJDIjJDgz",
   "doctors": 18,
   "estb": 19830125,
   "hours": null
  },
  {
   "name": "의료법인 동해동인병원",
   "type": "종합병원",
   "addr": "강원특별자치도 동해시 하평로 26, (평릉동)",
   "tel": "033-530-0114",
   "lng": 129.1074625,
   "lat": 37.5299417,
   "dong": "평릉동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkODkkMzgxMzUxIzExIyQxIyQzIyQ4OSQyNjE0ODEjODEjJDEjJDIjJDgz",
   "doctors": 20,
   "estb": 19830725,
   "hours": {
    "Mon": [
     "0840",
     "1700"
    ],
    "Tue": [
     "0840",
     "1700"
    ],
    "Wed": [
     "0840",
     "1700"
    ],
    "Thu": [
     "0840",
     "1700"
    ],
    "Fri": [
     "0840",
     "1700"
    ],
    "Sat": [
     "0840",
     "1200"
    ],
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": "12시30분~13시30분",
    "rcvWeek": "08시30분~16시30분",
    "rcvSat": "08시30분~11시30분",
    "parkXpnsYn": "N",
    "emyDayYn": "Y",
    "emyNgtYn": "Y"
   }
  },
  {
   "name": "동해금강요양병원",
   "type": "요양병원",
   "addr": "강원특별자치도 동해시 동해대로 5143, 동해금강요양병원 (효가동)",
   "tel": "033-520-7000",
   "lng": 129.1066052,
   "lat": 37.5034504,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkOTkkNTgxMzUxIzExIyQxIyQzIyQ5OSQyNjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 3,
   "estb": 20080601,
   "hours": null
  },
  {
   "name": "동해요양병원",
   "type": "요양병원",
   "addr": "강원특별자치도 동해시 중앙로 218-0, 동해요양병원",
   "tel": "033-531-2500",
   "lng": 129.1156782,
   "lat": 37.520357,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkOTkkNTgxMzUxIzExIyQxIyQzIyQ2MiQzNjEyMjIjNzEjJDEjJDgjJDgz",
   "doctors": 7,
   "estb": 20151224,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1800"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "12시~13시",
    "rcvWeek": "09시00분~18시00분",
    "rcvSat": null,
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "동해이레요양병원",
   "type": "요양병원",
   "addr": "강원특별자치도 동해시 덕골길 76-40,  (천곡동)",
   "tel": "033-533-7741",
   "lng": 129.0969083,
   "lat": 37.5179522,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkOTkkNTgxMzUxIzExIyQxIyQzIyQ4OSQyNjEyMjIjNTEjJDEjJDIjJDgz",
   "doctors": 4,
   "estb": 20061013,
   "hours": null
  },
  {
   "name": "All바른의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 발한로 210, (발한동)",
   "tel": "531-7575",
   "lng": 129.1091632,
   "lat": 37.5482742,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQ1IyQ5MiQzNjEyMjIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20150303,
   "hours": null
  },
  {
   "name": "Dr.하석우의한사랑의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 효자남길 16, 1층 (동회동, 월드상가)",
   "tel": "033-522-2244",
   "lng": 129.1087269,
   "lat": 37.4877014,
   "dong": "동회동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzMxIyQxIyQzIyQ2MiQ0NjEwMDIjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20010212,
   "hours": null
  },
  {
   "name": "글로리아산부인과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 86-2, 3층 (천곡동, 대륜빌딩)",
   "tel": "033-532-0050",
   "lng": 129.1150224,
   "lat": 37.5228662,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQxIyQ4OSQzNjEyMjIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20031006,
   "hours": null
  },
  {
   "name": "김인수정형외과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 86-2, (천곡동)",
   "tel": "033-535-3669",
   "lng": 129.1150224,
   "lat": 37.5228662,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQxIyQ5MiQyNjEyMjIjNTEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 20120105,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1800"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "휴진",
    "noTrmtSun": "휴진",
    "lunchWeek": "13시00분-14시00분",
    "rcvWeek": "09시00분-18시00분",
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "꾸러기소아과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 중앙로 249, (천곡동)",
   "tel": "033-531-0222",
   "lng": 129.1134223,
   "lat": 37.522743,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzMxIyQxIyQ3IyQ5MiQyNjE4MzIjODEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 20070504,
   "hours": null
  },
  {
   "name": "누가이비인후과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 한섬로 111-7, 3층 (천곡동, 현진빌딩)",
   "tel": "033-535-3600",
   "lng": 129.1152178,
   "lat": 37.5222543,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzQxIyQxIyQ3IyQxMyQyNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": 4,
   "estb": 20100224,
   "hours": {
    "Mon": [
     "0830",
     "1830"
    ],
    "Tue": [
     "0830",
     "1830"
    ],
    "Wed": [
     "0830",
     "1830"
    ],
    "Thu": [
     "0830",
     "1830"
    ],
    "Fri": [
     "0830",
     "1830"
    ],
    "Sat": [
     "0830",
     "1600"
    ],
    "Sun": null,
    "noTrmtHoli": "오후 4시이후",
    "noTrmtSun": null,
    "lunchWeek": "12:30 ~ 14:00",
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "더맑은신경과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 효자로 683, 3층 (효가동)",
   "tel": "033-521-9991",
   "lng": 129.1088937,
   "lat": 37.4926963,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzIxIyQxIyQxIyQ3OSQzNjEwMDIjNjEjJDEjJDAjJDgz",
   "doctors": 1,
   "estb": 20210826,
   "hours": null
  },
  {
   "name": "동해금강의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 동해대로 5143, (효가동)",
   "tel": "033-520-7051",
   "lng": 129.1066052,
   "lat": 37.5034504,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzQxIyQxIyQ3IyQwMyQyNjEyMjIjNjEjJDEjJDAjJDgz",
   "doctors": 1,
   "estb": 20090513,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1800"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "휴진",
    "noTrmtSun": "휴진",
    "lunchWeek": "12;30--13;30",
    "rcvWeek": "09;00--18;00",
    "rcvSat": null,
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "동해정형외과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 효자로 688, (효가동)",
   "tel": "033-522-2770",
   "lng": 129.1094662,
   "lat": 37.4922591,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzExIyQyIyQ3IyQwMCQzNjEwMDIjNjEjJDEjJDAjJDgz",
   "doctors": 1,
   "estb": 19990329,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1300"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": [
     "0900",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": "12시30분~13시30분",
    "rcvWeek": "08시30분-05시20",
    "rcvSat": "08시30분~12시00분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "동해제일내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 청운1길 48, 2층 201호 (쇄운동)",
   "tel": "033-522-6638",
   "lng": 129.1085081,
   "lat": 37.4859413,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzIxIyQyIyQxIyQwMCQzNjE4MzIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20221004,
   "hours": {
    "Mon": [
     "0830",
     "1800"
    ],
    "Tue": [
     "0830",
     "1800"
    ],
    "Wed": [
     "0830",
     "1800"
    ],
    "Thu": [
     "0830",
     "1800"
    ],
    "Fri": [
     "0830",
     "1800"
    ],
    "Sat": [
     "0830",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": "08시30분~18시00분",
    "rcvSat": "08시30분~13시00분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "동해튼튼마취통증의학과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 한섬로 111-7, 현진빌딩 2층 202,203호 (천곡동)",
   "tel": "033-531-8275",
   "lng": 129.1152178,
   "lat": 37.5222543,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzIxIyQxIyQxIyQ3OSQzNjE0ODEjNjEjJDEjJDgjJDgz",
   "doctors": 2,
   "estb": 20210726,
   "hours": {
    "Mon": [
     "0900",
     "1900"
    ],
    "Tue": [
     "0900",
     "1900"
    ],
    "Wed": [
     "0900",
     "1900"
    ],
    "Thu": [
     "0900",
     "1900"
    ],
    "Fri": [
     "0900",
     "1900"
    ],
    "Sat": [
     "0900",
     "1400"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": null,
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "동해프라임내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 86-2, 대륜빌딩 201호 (천곡동)",
   "tel": "033-533-5580",
   "lng": 129.1150224,
   "lat": 37.5228662,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzExIyQxIyQ3IyQxMyQyNjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 2,
   "estb": 20210121,
   "hours": {
    "Mon": [
     "0830",
     "1800"
    ],
    "Tue": [
     "0830",
     "1800"
    ],
    "Wed": [
     "0830",
     "1800"
    ],
    "Thu": [
     "0830",
     "1800"
    ],
    "Fri": [
     "0830",
     "1800"
    ],
    "Sat": [
     "0830",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "박원일마취통증의학과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 공단1로 7-11, (구미동)",
   "tel": "033-521-0266",
   "lng": 129.1409654,
   "lat": 37.4710864,
   "dong": "구미동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzIxIyQxIyQ1IyQ3MiQyNjE4MzIjNjEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 19920405,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1300"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "휴진",
    "noTrmtSun": "휴진",
    "lunchWeek": "12시 30분~13시 30분",
    "rcvWeek": "09시 00분 ~ 18시 00분",
    "rcvSat": null,
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "박정형외과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 동굴로 104, (천곡동)",
   "tel": "033-533-8255",
   "lng": 129.1155332,
   "lat": 37.5174559,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzUxIyQyIyQ1IyQwMCQ0NjE0ODEjNjEjJDEjJDAjJDgz",
   "doctors": 1,
   "estb": 20040930,
   "hours": null
  },
  {
   "name": "백신경외과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 동해대로 5461, (평릉동)",
   "tel": "033-533-8181",
   "lng": 129.1044874,
   "lat": 37.5296172,
   "dong": "평릉동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzUxIyQxIyQxIyQ3MiQyNjEyMjIjNTEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 19940514,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1800"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": [
     "0900",
     "1200"
    ],
    "Sun": null,
    "noTrmtHoli": "전부 휴진 (대체 공휴일 전부 휴진)",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "13시 00분 ~ 14시 00분",
    "rcvWeek": "08시 30분",
    "rcvSat": "08시 30분",
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "부곡의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 발한로 69-0, (부곡동)",
   "tel": "033-533-1045",
   "lng": 129.1015261,
   "lat": 37.5385698,
   "dong": "부곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQxIyQ3OSQyNjE0ODEjNjEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20100428,
   "hours": null
  },
  {
   "name": "북평리안의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 대동로 120, 2층 (북평동)",
   "tel": "033-522-2345",
   "lng": 129.1270521,
   "lat": 37.4826879,
   "dong": "북평동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzExIyQxIyQ3IyQ5MiQzNjE4MzIjNjEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20200813,
   "hours": null
  },
  {
   "name": "북평의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 전천로 303, (북평동)",
   "tel": "033-521-7180",
   "lng": 129.1247815,
   "lat": 37.4831764,
   "dong": "북평동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzMxIyQxIyQzIyQ2MiQzNjE0ODEjODEjJDEjJDYjJDgz",
   "doctors": 0,
   "estb": 20041130,
   "hours": {
    "Mon": [
     "0840",
     "1700"
    ],
    "Tue": [
     "0840",
     "1700"
    ],
    "Wed": [
     "0840",
     "1700"
    ],
    "Thu": [
     "0840",
     "1700"
    ],
    "Fri": [
     "0840",
     "1700"
    ],
    "Sat": [
     "0840",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": null,
    "rcvWeek": "08시40분",
    "rcvSat": "08시40분",
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "서외과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 동해대로 5007, (효가동)",
   "tel": "033-521-1308",
   "lng": 129.1100562,
   "lat": 37.4930433,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzQxIyQxIyQ3IyQ3MiQzNjEyMjIjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 19911128,
   "hours": null
  },
  {
   "name": "서울베스트안과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 중앙로 237, (천곡동)",
   "tel": "033-531-6162",
   "lng": 129.113774,
   "lat": 37.5220356,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzQxIyQxIyQ3IyQ5OSQyNjE4MzIjODEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 20080523,
   "hours": null
  },
  {
   "name": "성모안과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 76, 다나빌딩 2층 201호 (천곡동)",
   "tel": "033-533-1285",
   "lng": 129.1132361,
   "lat": 37.5229022,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzMxIyQxIyQzIyQ2MiQyNjE0ODEjNjEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20041207,
   "hours": {
    "Mon": [
     "0900",
     "1700"
    ],
    "Tue": [
     "0900",
     "1700"
    ],
    "Wed": [
     "0900",
     "1300"
    ],
    "Thu": [
     "0900",
     "1700"
    ],
    "Fri": [
     "0900",
     "1700"
    ],
    "Sat": [
     "0900",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": "13시00분 ~ 14시00분",
    "rcvWeek": "09시00분 ~ 17시00분",
    "rcvSat": "09시00분 ~ 13시00분",
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "성심의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 발한로 204, (발한동)",
   "tel": "033-531-3900",
   "lng": 129.1090199,
   "lat": 37.5475697,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzExIyQxIyQzIyQ3OSQyNjEwMDIjNTEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 19970516,
   "hours": {
    "Mon": [
     "0830",
     "1800"
    ],
    "Tue": [
     "0830",
     "1800"
    ],
    "Wed": [
     "0830",
     "1800"
    ],
    "Thu": [
     "0830",
     "1800"
    ],
    "Fri": [
     "0830",
     "1800"
    ],
    "Sat": [
     "0830",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": "08시30분~18시00분",
    "rcvSat": "08시30분~13시00분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "세종의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 일출로 15, (발한동, 동해물약국)",
   "tel": "033-532-0511",
   "lng": 129.1096422,
   "lat": 37.5506116,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzExIyQxIyQzIyQ5OSQyNjE0ODEjNjEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20160302,
   "hours": null
  },
  {
   "name": "신세계의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 청운1길 64, 모던파크빌딩 301호 (나안동)",
   "tel": "033-533-3652",
   "lng": 129.1102081,
   "lat": 37.485907,
   "dong": "나안동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzExIyQxIyQzIyQxMyQyNjEyMjIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20130829,
   "hours": null
  },
  {
   "name": "신소아청소년과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 효자로 691, 308, 309호 (효가동, 동성프라자)",
   "tel": "033-522-3773",
   "lng": 129.1097088,
   "lat": 37.4929224,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzExIyQxIyQ3IyQ5OSQyNjEwMDIjNjEjJDEjJDAjJDgz",
   "doctors": 1,
   "estb": 19990205,
   "hours": null
  },
  {
   "name": "심내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 50, 2층 (천곡동, 삼성빌딩)",
   "tel": "033-532-9338",
   "lng": 129.1106683,
   "lat": 37.5238378,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzQxIyQxIyQ3IyQ4OSQyNjEwMDIjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 19901101,
   "hours": null
  },
  {
   "name": "아라한의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 중앙로 249, 4층 401호 (천곡동)",
   "tel": "033-535-6566",
   "lng": 129.1134223,
   "lat": 37.522743,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQxIyQ5MiQzNjEwMDIjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20120210,
   "hours": {
    "Mon": [
     "0900",
     "1700"
    ],
    "Tue": [
     "0900",
     "1700"
    ],
    "Wed": [
     "0900",
     "1100"
    ],
    "Thu": [
     "0900",
     "1700"
    ],
    "Fri": [
     "0900",
     "1700"
    ],
    "Sat": [
     "0900",
     "1100"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": "11시30분-14시00분",
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "아이리스의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 86, (천곡동, 동진빌딩)",
   "tel": "033-535-0032",
   "lng": 129.1147123,
   "lat": 37.5234458,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzIxIyQxIyQxIyQ5OSQ0NjE0ODEjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20161111,
   "hours": null
  },
  {
   "name": "아이맘산부인과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 한섬로 113-7, (천곡동)",
   "tel": "033-532-8081",
   "lng": 129.1159264,
   "lat": 37.5223215,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzMxIyQyIyQ3IyQwMCQ0NjEwMDIjODEjJDEjJDYjJDgz",
   "doctors": 2,
   "estb": 20141222,
   "hours": {
    "Mon": [
     "0910",
     "1740"
    ],
    "Tue": [
     "0910",
     "1740"
    ],
    "Wed": [
     "0910",
     "1740"
    ],
    "Thu": [
     "0910",
     "1740"
    ],
    "Fri": [
     "0910",
     "1740"
    ],
    "Sat": [
     "0910",
     "1400"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": null,
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "연세속이편한내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 효자로 683, 2층 (효가동)",
   "tel": "033-521-0551",
   "lng": 129.1088937,
   "lat": 37.4926963,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzIxIyQxIyQxIyQ2MiQyNjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20221110,
   "hours": null
  },
  {
   "name": "연세의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 발한로 180, (발한동)",
   "tel": "033-535-0096",
   "lng": 129.1063034,
   "lat": 37.5468778,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzMxIyQxIyQ3IyQ2MiQzNjE4MzIjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20021111,
   "hours": {
    "Mon": [
     "0830",
     "1800"
    ],
    "Tue": [
     "0830",
     "1800"
    ],
    "Wed": [
     "0830",
     "1800"
    ],
    "Thu": [
     "0830",
     "1800"
    ],
    "Fri": [
     "0830",
     "1800"
    ],
    "Sat": [
     "0830",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": "08시30분~18시00분",
    "rcvSat": "08시30분~13시00분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "연세진의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 지양길 2-1, (효가동)",
   "tel": "033-522-1013",
   "lng": 129.1084087,
   "lat": 37.492828,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQ1IyQ5OSQ0NjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20131008,
   "hours": null
  },
  {
   "name": "열린이비인후과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 76, 다나빌딩 2층 204호 (천곡동)",
   "tel": "033-533-9955",
   "lng": 129.1132361,
   "lat": 37.5229022,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQxIyQ5MiQ0NjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20030423,
   "hours": {
    "Mon": [
     "0900",
     "1900"
    ],
    "Tue": [
     "0900",
     "1900"
    ],
    "Wed": [
     "0900",
     "1900"
    ],
    "Thu": [
     "0900",
     "1900"
    ],
    "Fri": [
     "0900",
     "1900"
    ],
    "Sat": [
     "0900",
     "1500"
    ],
    "Sun": null,
    "noTrmtHoli": "오후1시까지",
    "noTrmtSun": "휴진",
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": "오전8시 40분~오후 7시 00분",
    "rcvSat": "오전 8시 40분~ 오후 3시 00분",
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "오형균정형외과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 발한로 104, (발한동)",
   "tel": "033-532-8244",
   "lng": 129.1021465,
   "lat": 37.5414633,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzMxIyQxIyQzIyQ5MiQyNjE4MzIjNzEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19870507,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1800"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": [
     "0900",
     "1200"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": "1시00분- 2시00분",
    "rcvWeek": "09시00분- 17시50분",
    "rcvSat": "09시00분 - 11시50분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "원플러스원비뇨기과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 76, 3층 (천곡동, 다나빌딩)",
   "tel": "033-532-0558",
   "lng": 129.1132361,
   "lat": 37.5229022,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzQxIyQxIyQ3IyQ3MiQyNjE4MzIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19971015,
   "hours": null
  },
  {
   "name": "윤이비인후과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 중앙로 237, (천곡동)",
   "tel": "033-535-7501",
   "lng": 129.113774,
   "lat": 37.5220356,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzIxIyQxIyQxIyQ5OSQzNjE4MzIjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20000602,
   "hours": {
    "Mon": [
     "0830",
     "1900"
    ],
    "Tue": [
     "0830",
     "1900"
    ],
    "Wed": [
     "0830",
     "1900"
    ],
    "Thu": [
     "0830",
     "1900"
    ],
    "Fri": [
     "0830",
     "1900"
    ],
    "Sat": [
     "0830",
     "1600"
    ],
    "Sun": null,
    "noTrmtHoli": "오후 1시 이후",
    "noTrmtSun": "휴진",
    "lunchWeek": "13시 00분 ~ 14시 00분",
    "rcvWeek": "08시 30분 ~ 19시 00분",
    "rcvSat": "08시 30분 ~ 16시 00분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "이승재내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 동굴로 106, (천곡동)",
   "tel": "033-532-6880",
   "lng": 129.1157084,
   "lat": 37.5175295,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzUxIyQxIyQ1IyQ2MiQyNjEyMjIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 19960313,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1230"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "휴무",
    "noTrmtSun": "휴무",
    "lunchWeek": "12시30분~14시00분",
    "rcvWeek": "09시00분~18시00분",
    "rcvSat": null,
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "이연수내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 중앙로 229, 2층 (천곡동)",
   "tel": "033-532-4600",
   "lng": 129.1142632,
   "lat": 37.5211818,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzIxIyQxIyQxIyQ3MiQzNjE0ODEjNzEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20101018,
   "hours": {
    "Mon": [
     "0840",
     "0530"
    ],
    "Tue": [
     "0840",
     "0630"
    ],
    "Wed": [
     "0840",
     "0530"
    ],
    "Thu": [
     "0840",
     "0530"
    ],
    "Fri": [
     "0840",
     "0530"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "12시40분~13시40분",
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "이옥찬내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 중앙로 249, (천곡동)",
   "tel": "033-535-5315",
   "lng": 129.1134223,
   "lat": 37.522743,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzIxIyQxIyQ1IyQ4OSQzNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20010625,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1300"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": [
     "0900",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": null,
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "이이비인후과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 청운1길 51, 2층 (쇄운동, 백봉빌딩)",
   "tel": "033-535-1616",
   "lng": 129.1088409,
   "lat": 37.4862869,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzUxIyQyIyQ1IyQwMCQzNjEyMjIjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 19960302,
   "hours": {
    "Mon": [
     "0830",
     "1730"
    ],
    "Tue": [
     "0830",
     "1730"
    ],
    "Wed": [
     "0830",
     "1700"
    ],
    "Thu": [
     "0830",
     "1730"
    ],
    "Fri": [
     "0830",
     "1730"
    ],
    "Sat": [
     "0830",
     "1200"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": null,
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "이재현내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 청운1길 64, 모던파크 201호 (나안동)",
   "tel": "033-521-2288",
   "lng": 129.1102081,
   "lat": 37.485907,
   "dong": "나안동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMTkxIzExIyQxIyQzIyQ5OSQyNjE4MzIjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20160328,
   "hours": null
  },
  {
   "name": "이정신건강의학과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 52, (천곡동)",
   "tel": "033-533-9895",
   "lng": 129.1109039,
   "lat": 37.5237799,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzQxIyQxIyQ3IyQ4OSQyNjE0ODEjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19900920,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1300"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": [
     "0900",
     "1200"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": "09시00분~18시00분",
    "rcvSat": "09시00분~12시00분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "임내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 효자남길 68, 2층동 (효가동)",
   "tel": "033-522-2104",
   "lng": 129.1085588,
   "lat": 37.4922127,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzIxIyQxIyQ5IyQ3MiQyNjEyMjIjNTEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 19970513,
   "hours": null
  },
  {
   "name": "조아가정의학과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 한섬로 94, 3층 (천곡동, 동해농협)",
   "tel": "033-534-7559",
   "lng": 129.114226,
   "lat": 37.5203766,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzUxIyQxIyQ1IyQ5MiQ0NjE0ODEjODEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 20150327,
   "hours": {
    "Mon": [
     "0900",
     "0600"
    ],
    "Tue": [
     "0900",
     "0600"
    ],
    "Wed": [
     "0900",
     "0600"
    ],
    "Thu": [
     "0900",
     "0600"
    ],
    "Fri": [
     "0900",
     "0600"
    ],
    "Sat": [
     "0900",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "탁내과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 68, 204호 (천곡동)",
   "tel": "033-532-7100",
   "lng": 129.1128123,
   "lat": 37.5232812,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzUxIyQyIyQxIyQwMCQ0NjEwMDIjNjEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19931202,
   "hours": null
  },
  {
   "name": "하나통증의학과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 76, 4층 401호 (천곡동)",
   "tel": "033-533-3275",
   "lng": 129.1132361,
   "lat": 37.5229022,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzMxIyQxIyQ3IyQwMyQzNjEwMDIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20071004,
   "hours": {
    "Mon": [
     "0900",
     "1800"
    ],
    "Tue": [
     "0900",
     "1800"
    ],
    "Wed": [
     "0900",
     "1300"
    ],
    "Thu": [
     "0900",
     "1800"
    ],
    "Fri": [
     "0900",
     "1800"
    ],
    "Sat": [
     "0900",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": "12시30분 - 14시00분",
    "rcvWeek": "08시40분 - 17시30분",
    "rcvSat": "08시40분 -12시30분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "한소아과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 천곡로 86-2, 대륜빌딩 2층 (천곡동)",
   "tel": "033-531-6247",
   "lng": 129.1150224,
   "lat": 37.5228662,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxMzUxIzMxIyQxIyQ3IyQ3OSQyNjE0ODEjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 19880228,
   "hours": null
  },
  {
   "name": "홍정안외과의원",
   "type": "의원",
   "addr": "강원특별자치도 동해시 중앙로 237, 4층 (천곡동, 삼양골든상가)",
   "tel": "033-535-0959",
   "lng": 129.113774,
   "lat": 37.5220356,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMiMkNCMkMDAkMzgxOTYxIzIxIyQxIyQxIyQ4MiQ0NjE0ODEjNzEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20010112,
   "hours": {
    "Mon": [
     "0900",
     "1700"
    ],
    "Tue": [
     "0900",
     "1700"
    ],
    "Wed": [
     "0900",
     "1700"
    ],
    "Thu": [
     "0900",
     "1700"
    ],
    "Fri": [
     "0900",
     "1700"
    ],
    "Sat": [
     "0830",
     "1100"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": null,
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "고헌주치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 발한로 206, (발한동)",
   "tel": "033-533-0003",
   "lng": 129.1091305,
   "lat": 37.547894,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzExIyQxIyQzIyQwMyQyNjE4MzIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19830510,
   "hours": {
    "Mon": [
     "1000",
     "1800"
    ],
    "Tue": [
     "1000",
     "1800"
    ],
    "Wed": [
     "1000",
     "1800"
    ],
    "Thu": [
     "1000",
     "1800"
    ],
    "Fri": [
     "1000",
     "1800"
    ],
    "Sat": [
     "1000",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "12시30분~14시00분",
    "rcvWeek": "09시00분~17시50분",
    "rcvSat": "09시00분~12시 50분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "굿모닝치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 청운1길 48, 2층 202호 (쇄운동)",
   "tel": "033-521-1575",
   "lng": 129.1085081,
   "lat": 37.4859413,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzMxIyQxIyQzIyQ3OSQzNjE4MzIjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20040715,
   "hours": {
    "Mon": [
     "0930",
     "1830"
    ],
    "Tue": [
     "0930",
     "1830"
    ],
    "Wed": [
     "0930",
     "1830"
    ],
    "Thu": [
     "0930",
     "1830"
    ],
    "Fri": [
     "0930",
     "1830"
    ],
    "Sat": [
     "0930",
     "1330"
    ],
    "Sun": null,
    "noTrmtHoli": "법적공휴일",
    "noTrmtSun": "매주일요일",
    "lunchWeek": "12시30분~14시00분",
    "rcvWeek": "예약",
    "rcvSat": "예약",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "김주선치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 발한로 63, (부곡동)",
   "tel": "033-535-1515",
   "lng": 129.1019128,
   "lat": 37.5381119,
   "dong": "부곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQ1IyQ2MiQzNjE0ODEjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 19970118,
   "hours": null
  },
  {
   "name": "뉴욕치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 한섬로 111-7, 현진빌딩 4층 404호 (천곡동)",
   "tel": null,
   "lng": 129.1152178,
   "lat": 37.5222543,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQ1IyQ5OSQyNjE4MzIjNjEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20240123,
   "hours": null
  },
  {
   "name": "동해아이온소아치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 한섬로 113-7, 송원빌딩 6층 601호 (천곡동)",
   "tel": "033-533-7528",
   "lng": 129.1159264,
   "lat": 37.5223215,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQxIyQ3MiQzNjEyMjIjNjEjJDEjJDQjJDgz",
   "doctors": 2,
   "estb": 20201021,
   "hours": null
  },
  {
   "name": "동해화이트치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 천곡로 76, 3층 301호 (천곡동, 다나빌딩)",
   "tel": "033-532-7532",
   "lng": 129.1132361,
   "lat": 37.5229022,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzQxIyQxIyQ3IyQ4MiQzNjEyMjIjNjEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20150828,
   "hours": null
  },
  {
   "name": "미소디자인치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 청운1길 55, 2층 (나안동)",
   "tel": "033-522-2878",
   "lng": 129.1095046,
   "lat": 37.4862811,
   "dong": "나안동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQxIyQ4OSQzNjE0ODEjNDEjJDEjJDQjJDgz",
   "doctors": 2,
   "estb": 20180116,
   "hours": null
  },
  {
   "name": "바른치과교정과치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 중앙로 229, 3층 (천곡동)",
   "tel": "033-535-2885",
   "lng": 129.1142632,
   "lat": 37.5211818,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQxIyQ4OSQyNjEyMjIjNTEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 20171120,
   "hours": null
  },
  {
   "name": "박치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 천곡로 86-2, (천곡동)",
   "tel": "033-532-5869",
   "lng": 129.1150224,
   "lat": 37.5228662,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzExIyQxIyQ3IyQ5OSQzNjE0ODEjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 19860426,
   "hours": null
  },
  {
   "name": "베네치아치과교정과치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 청운1길 52, 402호 (쇄운동)",
   "tel": "033-521-2856",
   "lng": 129.108938,
   "lat": 37.4859538,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQxIyQ4MiQzNjEyMjIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20210419,
   "hours": null
  },
  {
   "name": "베네치아치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 청운1길 52, 401호 (쇄운동)",
   "tel": "033-521-2855",
   "lng": 129.108938,
   "lat": 37.4859538,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzQxIyQyIyQ3IyQwMCQ0NjE0ODEjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20140731,
   "hours": null
  },
  {
   "name": "뿌리플란트치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 천곡로 86-2, 대륜빌딩 502호 (천곡동)",
   "tel": "033-534-2080",
   "lng": 129.1150224,
   "lat": 37.5228662,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQ1IyQ2MiQyNjEwMDIjNTEjJDEjJDYjJDgz",
   "doctors": 3,
   "estb": 20250317,
   "hours": null
  },
  {
   "name": "서울프라임치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 발한로 197, 1층 (발한동)",
   "tel": "033-533-0533",
   "lng": 129.1081149,
   "lat": 37.5476051,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQ1IyQ2MiQ0NjE0ODEjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20250728,
   "hours": null
  },
  {
   "name": "시몬치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 발한로 224, (발한동)",
   "tel": "033-531-8575",
   "lng": 129.1087268,
   "lat": 37.5496038,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQ5IyQ3MiQzNjE4MzIjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20161111,
   "hours": null
  },
  {
   "name": "아름다운치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 중앙로 223, 3층 302호 (천곡동, 그린빌딩)",
   "tel": "033-532-1275",
   "lng": 129.1144663,
   "lat": 37.520579,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQ5IyQ3OSQyNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19970521,
   "hours": null
  },
  {
   "name": "연세동해구강악안면외과치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 천곡로 51, 2층 (천곡동)",
   "tel": "033-533-2875",
   "lng": 129.110984,
   "lat": 37.5242825,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQxIyQ5OSQ0NjE0ODEjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20121116,
   "hours": null
  },
  {
   "name": "연세치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 중앙로 249, (천곡동)",
   "tel": "033-521-1646",
   "lng": 129.1134223,
   "lat": 37.522743,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQ1IyQ2MiQzNjEwMDIjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 19970513,
   "hours": {
    "Mon": [
     "0930",
     "0630"
    ],
    "Tue": [
     "0930",
     "0630"
    ],
    "Wed": [
     "0930",
     "0630"
    ],
    "Thu": [
     "0930",
     "0630"
    ],
    "Fri": [
     "0930",
     "0630"
    ],
    "Sat": [
     "0930",
     "0100"
    ],
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": "12시30분~14시00까지",
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "영동세브란스치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 효자남길 16, 월드상가 2층 (동회동)",
   "tel": "033-521-2804",
   "lng": 129.1088085,
   "lat": 37.4877157,
   "dong": "동회동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQ1IyQ4OSQzNjE4MzIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20231113,
   "hours": null
  },
  {
   "name": "예스치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 중앙로 229, 4층 (천곡동)",
   "tel": "033-533-2804",
   "lng": 129.1142632,
   "lat": 37.5211818,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzQxIyQxIyQ3IyQ3OSQzNjEwMDIjNjEjJDEjJDAjJDgz",
   "doctors": 1,
   "estb": 20130401,
   "hours": {
    "Mon": [
     "0900",
     "1730"
    ],
    "Tue": [
     "0900",
     "1730"
    ],
    "Wed": [
     "0900",
     "1730"
    ],
    "Thu": [
     "0900",
     "1730"
    ],
    "Fri": [
     "0900",
     "1730"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": "오전접수-12시까지 오후접수-4시30분까지",
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "우리가족치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 중앙로 248, (천곡동)",
   "tel": "033-534-2875",
   "lng": 129.1145097,
   "lat": 37.5228132,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzQxIyQyIyQ3IyQwMCQzNjE4MzIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20140724,
   "hours": null
  },
  {
   "name": "이플란트치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 중앙로 237-237, 3층 301-1호 (천곡동, 삼양골든빌딩)",
   "tel": "033-534-2275",
   "lng": null,
   "lat": null,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzUxIyQxIyQ1IyQ5OSQyNjE0ODEjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20100423,
   "hours": null
  },
  {
   "name": "장창수치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 천곡로 59-1, (천곡동)",
   "tel": "033-533-0781",
   "lng": 129.1119935,
   "lat": 37.5241136,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQyIyQ1IyQwMCQzNjE0ODEjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 19970118,
   "hours": null
  },
  {
   "name": "정다운치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 발한로 179, 2층 (발한동)",
   "tel": "033-534-2835",
   "lng": 129.1060351,
   "lat": 37.5471751,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzMxIyQxIyQzIyQ5OSQzNjE0ODEjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20110210,
   "hours": null
  },
  {
   "name": "중앙치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 천곡로 68, 203호 (천곡동, 현대코아)",
   "tel": "033-535-5370",
   "lng": 129.1128123,
   "lat": 37.5232812,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQ1IyQxMyQyNjE4MzIjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20010827,
   "hours": {
    "Mon": [
     "0930",
     "1800"
    ],
    "Tue": [
     "0930",
     "1800"
    ],
    "Wed": [
     "0930",
     "1800"
    ],
    "Thu": [
     "0930",
     "1800"
    ],
    "Fri": [
     "0930",
     "1800"
    ],
    "Sat": null,
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": "12시30분~14시00분",
    "rcvWeek": "9시30분~18시00분",
    "rcvSat": "09시30분~12시00분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "참조은치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 중앙로 247, (천곡동)",
   "tel": "033-535-4500",
   "lng": 129.1135222,
   "lat": 37.5225312,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQ1IyQ5OSQzNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": 2,
   "estb": 20010723,
   "hours": null
  },
  {
   "name": "천곡치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 한섬로 66, (천곡동)",
   "tel": "033-533-7551",
   "lng": 129.1110657,
   "lat": 37.5198742,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQ1IyQ4OSQyNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19960522,
   "hours": null
  },
  {
   "name": "최진희치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 대학로 20, (천곡동)",
   "tel": "033-532-9114",
   "lng": 129.1132288,
   "lat": 37.5223595,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzIxIyQxIyQxIyQ4MiQzNjE0ODEjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 19950420,
   "hours": {
    "Mon": [
     "1000",
     "1830"
    ],
    "Tue": [
     "1000",
     "1830"
    ],
    "Wed": [
     "1000",
     "1830"
    ],
    "Thu": [
     "1000",
     "1830"
    ],
    "Fri": [
     "1000",
     "1830"
    ],
    "Sat": [
     "1000",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": "전부휴진",
    "noTrmtSun": "전부휴진",
    "lunchWeek": "01시00분~14시30분",
    "rcvWeek": "10시00분~17시30분",
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "치아사랑치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 청운1길 51-1, 2층 (쇄운동)",
   "tel": "033-521-2279",
   "lng": 129.1089965,
   "lat": 37.4862817,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzMxIyQxIyQ3IyQwMyQyNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20120419,
   "hours": {
    "Mon": [
     "0930",
     "1830"
    ],
    "Tue": [
     "0930",
     "2000"
    ],
    "Wed": [
     "0930",
     "1330"
    ],
    "Thu": null,
    "Fri": [
     "0930",
     "1830"
    ],
    "Sat": [
     "0930",
     "1200"
    ],
    "Sun": null,
    "noTrmtHoli": "전부 휴진",
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "12시30분~14시00분, 수요일은 점심시간 없이 진료",
    "rcvWeek": "18시00분, 화요일은 19시30분, 수요일은 13시00분",
    "rcvSat": "11시30분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "태도치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 송정중앙로 11, (송정동)",
   "tel": "033-522-2875",
   "lng": 129.1263224,
   "lat": 37.4946139,
   "dong": "송정동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzExIyQxIyQ3IyQ3OSQyNjEwMDIjNTEjJDEjJDYjJDgz",
   "doctors": 2,
   "estb": 19840420,
   "hours": null
  },
  {
   "name": "효치과의원",
   "type": "치과의원",
   "addr": "강원특별자치도 동해시 발한로 186-1, 먹보만두찐빵 (발한동)",
   "tel": "033-532-0717",
   "lng": 129.1068599,
   "lat": 37.546943,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkNzIkMzgxMzUxIzExIyQxIyQ3IyQ4MiQzNjE4MzIjNjEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20180906,
   "hours": null
  },
  {
   "name": "동해시보건소",
   "type": "보건소",
   "addr": "강원특별자치도 동해시 천곡로 100-2, (천곡동)",
   "tel": "033-530-2401",
   "lng": 129.1171161,
   "lat": 37.5228646,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkOTIkMzgxMzUxIzExIyQxIyQzIyQ3OSQyNjEwMDIjNjEjJDEjJDgjJDgz",
   "doctors": 2,
   "estb": 19800401,
   "hours": null
  },
  {
   "name": "삼화보건지소",
   "type": "보건지소",
   "addr": "강원특별자치도 동해시 무릉1길 10, (이로동, 삼화동주민센터)",
   "tel": "033-530-2420",
   "lng": 129.0676214,
   "lat": 37.4884058,
   "dong": "이로동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkOTIkMzgxOTYxIzExIyQxIyQzIyQxMyQzNjE4MzIjNjEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20070302,
   "hours": null
  },
  {
   "name": "감초당한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 발한로 213-1, (발한동)",
   "tel": "033-535-5385",
   "lng": 129.1085608,
   "lat": 37.54857,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzIxIyQxIyQxIyQ2MiQyNjE0ODEjNjEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 19980829,
   "hours": null
  },
  {
   "name": "경희약손한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 청운1길 52, (쇄운동)",
   "tel": "033-522-4246",
   "lng": 129.1089113,
   "lat": 37.4859527,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzMxIyQxIyQzIyQ4OSQyNjE0ODEjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20010723,
   "hours": null
  },
  {
   "name": "경희한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 일출로 2-1, (발한동)",
   "tel": "033-535-7177",
   "lng": 129.1092693,
   "lat": 37.5495252,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzIxIyQxIyQ1IyQ3OSQyNjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20250327,
   "hours": null
  },
  {
   "name": "광제한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 효자로 687-1, (효가동)",
   "tel": "033-521-7560",
   "lng": 129.1092933,
   "lat": 37.4928864,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzIxIyQxIyQxIyQ5OSQzNjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19990222,
   "hours": {
    "Mon": [
     "0930",
     "1900"
    ],
    "Tue": [
     "0930",
     "1900"
    ],
    "Wed": [
     "0930",
     "1900"
    ],
    "Thu": [
     "0930",
     "1900"
    ],
    "Fri": [
     "0930",
     "1900"
    ],
    "Sat": [
     "0930",
     "1500"
    ],
    "Sun": null,
    "noTrmtHoli": "휴무",
    "noTrmtSun": "휴무",
    "lunchWeek": "13시00분 -14시00분",
    "rcvWeek": "09시00분-18시30분",
    "rcvSat": "09시00분-14시30분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "더편한한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 중앙로 248, 삼양골드3차상가 2층 201호 (천곡동)",
   "tel": "033-534-1075",
   "lng": 129.1145097,
   "lat": 37.5228132,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzUxIyQxIyQxIyQ5OSQ0NjEwMDIjNTEjJDEjJDIjJDgz",
   "doctors": 3,
   "estb": 20250704,
   "hours": null
  },
  {
   "name": "동해명가한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 중앙로 247, 우리은행 203호 (천곡동)",
   "tel": "033-535-1075",
   "lng": 129.1135222,
   "lat": 37.5225312,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzMxIyQxIyQzIyQ3MiQ0NjE0ODEjNzEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20100708,
   "hours": null
  },
  {
   "name": "동해한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 대학로 20, 501호 (천곡동, 명동빌딩)",
   "tel": "033-532-3032",
   "lng": 129.1132288,
   "lat": 37.5223595,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzExIyQxIyQzIyQ5MiQzNjE0ODEjNzEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20060110,
   "hours": null
  },
  {
   "name": "백세한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 오일장길 6, 1층 (구미동)",
   "tel": "033-521-1921",
   "lng": 129.1273111,
   "lat": 37.4803885,
   "dong": "구미동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzMxIyQxIyQzIyQ2MiQ0NjE0ODEjNDEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20190805,
   "hours": null
  },
  {
   "name": "북평해맑은한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 오일장1길 9, (구미동)",
   "tel": "033-522-5375",
   "lng": 129.1259694,
   "lat": 37.4821688,
   "dong": "구미동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzMxIyQxIyQzIyQxMyQzNjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20040923,
   "hours": null
  },
  {
   "name": "수강한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 일출로 2-4, (발한동)",
   "tel": "033-532-3777",
   "lng": 129.1093455,
   "lat": 37.5492883,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzExIyQyIyQzIyQwMCQzNjEyMjIjNjEjJDEjJDAjJDgz",
   "doctors": 1,
   "estb": 19660609,
   "hours": null
  },
  {
   "name": "영동한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 발한로 125, (발한동)",
   "tel": "033-533-3505",
   "lng": 129.1018641,
   "lat": 37.5436957,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzIxIyQyIyQ1IyQwMCQzNjEwMDIjNjEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20010829,
   "hours": null
  },
  {
   "name": "원강한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 천곡로 55, (천곡동)",
   "tel": "033-533-4767",
   "lng": 129.1114122,
   "lat": 37.5241841,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzExIyQxIyQzIyQxMyQzNjE4MzIjNjEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19881110,
   "hours": {
    "Mon": [
     "0900",
     "1830"
    ],
    "Tue": [
     "0900",
     "1830"
    ],
    "Wed": [
     "0900",
     "1830"
    ],
    "Thu": [
     "0900",
     "1830"
    ],
    "Fri": [
     "0900",
     "1830"
    ],
    "Sat": [
     "0900",
     "1300"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": "전부 휴진",
    "lunchWeek": "13시00분~14시00분",
    "rcvWeek": "09시00분~18시00분",
    "rcvSat": "09시00분~12시30분",
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "익수당한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 중앙로 175, (천곡동)",
   "tel": "033-533-2412",
   "lng": 129.1169699,
   "lat": 37.5166765,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzExIyQyIyQzIyQwMCQ0NjE0ODEjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 19680527,
   "hours": null
  },
  {
   "name": "작은나무한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 발한로 75, 1층 (부곡동)",
   "tel": "033-838-7900",
   "lng": 129.1014566,
   "lat": 37.5391062,
   "dong": "부곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzQxIyQxIyQ3IyQ3MiQyNjEwMDIjNTEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20190930,
   "hours": null
  },
  {
   "name": "중앙제일한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 천곡로 52, (천곡동)",
   "tel": "033-535-1136",
   "lng": 129.1109039,
   "lat": 37.5237799,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzUxIyQyIyQxIyQwMCQzNjEwMDIjNzEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20050602,
   "hours": null
  },
  {
   "name": "청운한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 효자남길 8-17, 2층 (나안동)",
   "tel": null,
   "lng": 129.1102949,
   "lat": 37.4869647,
   "dong": "나안동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzUxIyQxIyQxIyQ3OSQzNjEyMjIjNTEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 20230801,
   "hours": null
  },
  {
   "name": "칠성한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 중앙로 223, (천곡동)",
   "tel": "033-535-8075",
   "lng": 129.1144663,
   "lat": 37.520579,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzIxIyQxIyQxIyQwMyQ0NjEwMDIjODEjJDEjJDIjJDgz",
   "doctors": 1,
   "estb": 20000421,
   "hours": {
    "Mon": [
     "0830",
     "1800"
    ],
    "Tue": [
     "0830",
     "1800"
    ],
    "Wed": [
     "0830",
     "1800"
    ],
    "Thu": null,
    "Fri": [
     "0830",
     "1800"
    ],
    "Sat": [
     "0830",
     "1200"
    ],
    "Sun": [
     "0830",
     "1200"
    ],
    "noTrmtHoli": "8시 30분 - 12시",
    "noTrmtSun": "8시 30분 - 12시",
    "lunchWeek": "12시 30분 - 1시 30분",
    "rcvWeek": "오후 5시 30분",
    "rcvSat": "오전 11시 30분",
    "parkXpnsYn": "N",
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "한섬한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 한섬로 61-1, (천곡동)",
   "tel": "033-533-4322",
   "lng": 129.1108516,
   "lat": 37.5205312,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzExIyQxIyQ3IyQ2MiQyNjEyMjIjNjEjJDEjJDQjJDgz",
   "doctors": 1,
   "estb": 20000612,
   "hours": null
  },
  {
   "name": "할아버지한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 중앙로 231, (천곡동)",
   "tel": "033-532-0065",
   "lng": 129.1141,
   "lat": 37.5213951,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzIxIyQxIyQ1IyQ4MiQzNjE0ODEjODEjJDEjJDYjJDgz",
   "doctors": 1,
   "estb": 20020830,
   "hours": null
  },
  {
   "name": "홍제한의원",
   "type": "한의원",
   "addr": "강원특별자치도 동해시 청운1길 64, 2층 (나안동)",
   "tel": "033-522-3669",
   "lng": 129.1102081,
   "lat": 37.485907,
   "dong": "나안동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMTMkMzgxNzAyIzMxIyQxIyQzIyQ4MiQzNjE0ODEjNDEjJDEjJDgjJDgz",
   "doctors": 1,
   "estb": 20000701,
   "hours": null
  }
 ],
 "er": [
  {
   "hpid": "A2200038",
   "name": "근로복지공단동해병원",
   "addr": "강원특별자치도 동해시 하평로 11-  (평릉동, (평릉동))",
   "tel": "033-530-3100",
   "telEr": "033-530-3100",
   "lng": 129.1058560226859,
   "lat": 37.53232311891651,
   "kind": "응급실운영신고기관"
  },
  {
   "hpid": "A2200003",
   "name": "의료법인동해동인병원",
   "addr": "강원특별자치도 동해시 하평로 26-  (평릉동, (평릉동))",
   "tel": "033-530-0114",
   "telEr": "033-530-0114",
   "lng": 129.1074043067605,
   "lat": 37.530006805605616,
   "kind": "지역응급의료기관"
  }
 ],
 "erRealtime": [
  {
   "hpid": "A2200003",
   "name": "의료법인동해동인병원",
   "tel": "033-530-0114",
   "hvec": 8,
   "hvoc": 2,
   "hvgc": 29,
   "hvicc": 14,
   "hvctayn": "Y",
   "hvmriayn": "Y",
   "hvventiayn": "Y",
   "hvidate": 20261010131950
  }
 ],
 "erMessages": [],
 "pharmacies": [
  {
   "name": "명진약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 발한로 69, (부곡동)",
   "tel": "033-533-6171",
   "lng": 129.1015261,
   "lat": 37.5385698,
   "dong": "부곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzMxIyQxIyQzIyQ3MiQyNjE4MzIjNjEjJDEjJDQjJDgz",
   "doctors": null,
   "estb": 19911014,
   "hours": {
    "Mon": [
     "0830",
     "2030"
    ],
    "Tue": [
     "0830",
     "2030"
    ],
    "Wed": [
     "0830",
     "2030"
    ],
    "Thu": [
     "0830",
     "2030"
    ],
    "Fri": [
     "0830",
     "2030"
    ],
    "Sat": [
     "0830",
     "1900"
    ],
    "Sun": null,
    "noTrmtHoli": null,
    "noTrmtSun": null,
    "lunchWeek": null,
    "rcvWeek": null,
    "rcvSat": null,
    "parkXpnsYn": null,
    "emyDayYn": "N",
    "emyNgtYn": "N"
   }
  },
  {
   "name": "은광약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 발한로 236-1, (발한동)",
   "tel": "033-531-3585",
   "lng": 129.1078527,
   "lat": 37.5502959,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQxIyQ2MiQyNjE0ODEjNjEjJDEjJDAjJDgz",
   "doctors": null,
   "estb": 19731204,
   "hours": null
  },
  {
   "name": "한빛약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 중앙로 214, (천곡동)",
   "tel": "033-535-8060",
   "lng": 129.1157318,
   "lat": 37.5199392,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQ1IyQ3MiQzNjE0ODEjNDEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20000830,
   "hours": null
  },
  {
   "name": "그랜드약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 청운1길 48, (쇄운동)",
   "tel": "033-535-7770",
   "lng": 129.1085081,
   "lat": 37.4859413,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzExIyQyIyQ3IyQwMCQyNjE4MzIjNDEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20160518,
   "hours": null
  },
  {
   "name": "메디칼25시약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 삼화로 16, (이로동)",
   "tel": "033-534-1722",
   "lng": 129.067569,
   "lat": 37.4872403,
   "dong": "이로동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzExIyQxIyQ3IyQ4OSQzNjE4MzIjODEjJDEjJDYjJDgz",
   "doctors": null,
   "estb": 20060823,
   "hours": null
  },
  {
   "name": "동해물약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 일출로 15, 동해물약국 가,나동 (발한동)",
   "tel": "033-531-4822",
   "lng": 129.1096422,
   "lat": 37.5506116,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzUxIyQxIyQxIyQ3MiQyNjEwMDIjODEjJDEjJDIjJDgz",
   "doctors": null,
   "estb": 19980728,
   "hours": null
  },
  {
   "name": "한마음약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 효자로 691, (효가동)",
   "tel": "033-521-9998",
   "lng": 129.1097088,
   "lat": 37.4929224,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzQxIyQxIyQ3IyQwMyQzNjEwMDIjNjEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20000801,
   "hours": null
  },
  {
   "name": "김약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 충혼길 41, (천곡동)",
   "tel": "033-535-7010",
   "lng": 129.1158502,
   "lat": 37.5176115,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzExIyQxIyQzIyQ5MiQ0NjE0ODEjNjEjJDEjJDAjJDgz",
   "doctors": null,
   "estb": 20080407,
   "hours": null
  },
  {
   "name": "한성약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 발한로 209, (발한동)",
   "tel": "033-535-5320",
   "lng": 129.1085372,
   "lat": 37.5483494,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzMxIyQxIyQ3IyQ3OSQzNjE4MzIjNTEjJDEjJDYjJDgz",
   "doctors": null,
   "estb": 20170927,
   "hours": null
  },
  {
   "name": "도미당약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 발한로 202-2, (발한동)",
   "tel": "033-531-3583",
   "lng": 129.1088965,
   "lat": 37.5475964,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzUxIyQxIyQxIyQxMyQzNjE0ODEjNzEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 19791015,
   "hours": null
  },
  {
   "name": "우리들약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 동해대로 5133, (효가동)",
   "tel": "033-521-2277",
   "lng": 129.1068632,
   "lat": 37.5033987,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzMxIyQxIyQzIyQ3OSQzNjEwMDIjNjEjJDEjJDQjJDgz",
   "doctors": null,
   "estb": 20220630,
   "hours": null
  },
  {
   "name": "금강산약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 중앙로 231, (천곡동)",
   "tel": "033-535-2353",
   "lng": 129.1141,
   "lat": 37.5213951,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzMxIyQxIyQzIyQ5OSQzNjE4MzIjNjEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20000404,
   "hours": null
  },
  {
   "name": "대학로약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 대학로 20, 명동빌딩 (천곡동)",
   "tel": "033-532-0088",
   "lng": 129.1132288,
   "lat": 37.5223595,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzMxIyQxIyQ3IyQ5MiQzNjE4MzIjNjEjJDEjJDAjJDgz",
   "doctors": null,
   "estb": 20190628,
   "hours": null
  },
  {
   "name": "으뜸길약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 효자로 690, (효가동, 으뜸약국)",
   "tel": "033-522-3868",
   "lng": 129.1097409,
   "lat": 37.4922586,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzIxIyQxIyQ5IyQ3OSQzNjE0ODEjNjEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20190930,
   "hours": null
  },
  {
   "name": "하나약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 삼화로 9-1, (이로동, 하나약국)",
   "tel": "070-7722-8240",
   "lng": 129.0683736,
   "lat": 37.4873469,
   "dong": "이로동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzMxIyQxIyQzIyQxMyQyNjEwMDIjODEjJDEjJDIjJDgz",
   "doctors": null,
   "estb": 19950913,
   "hours": null
  },
  {
   "name": "해맑은약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 중앙로 249, (천곡동)",
   "tel": "033-533-2160",
   "lng": 129.1134223,
   "lat": 37.522743,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzMxIyQxIyQzIyQ4MiQ0NjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20050216,
   "hours": null
  },
  {
   "name": "태화약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 중앙로 180, (천곡동)",
   "tel": "033-531-8642",
   "lng": 129.1171815,
   "lat": 37.5172571,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzMxIyQxIyQ3IyQ4MiQ0NjE0ODEjNDEjJDEjJDQjJDgz",
   "doctors": null,
   "estb": 19941128,
   "hours": null
  },
  {
   "name": "동서약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 구미1길 1, 1층 (북평동)",
   "tel": "033-521-2468",
   "lng": 129.1269332,
   "lat": 37.4828798,
   "dong": "북평동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzQxIyQxIyQ3IyQ4MiQ0NjEwMDIjNjEjJDEjJDAjJDgz",
   "doctors": null,
   "estb": 19960910,
   "hours": null
  },
  {
   "name": "정약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 효자남길 16, 1층 (동회동, 월드상가)",
   "tel": "033-522-0764",
   "lng": 129.1087269,
   "lat": 37.4877014,
   "dong": "동회동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzExIyQxIyQzIyQ4OSQzNjE4MzIjNTEjJDEjJDIjJDgz",
   "doctors": null,
   "estb": 20041101,
   "hours": null
  },
  {
   "name": "무지개약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 천곡로 76, 다나빌딩 1층 104호 (천곡동)",
   "tel": "033-532-0609",
   "lng": 129.1132361,
   "lat": 37.5229022,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzExIyQxIyQzIyQ3OSQ0NjE0ODEjNTEjJDEjJDYjJDgz",
   "doctors": null,
   "estb": 20190102,
   "hours": null
  },
  {
   "name": "조은약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 하평로 14, (평릉동)",
   "tel": "033-532-0299",
   "lng": 129.1064137,
   "lat": 37.5309016,
   "dong": "평릉동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzUxIyQxIyQ1IyQ5MiQ0NjEwMDIjNjEjJDEjJDAjJDgz",
   "doctors": null,
   "estb": 20010328,
   "hours": null
  },
  {
   "name": "튼튼온누리약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 효자남길 68, 1층 (효가동)",
   "tel": "033-521-9327",
   "lng": 129.1085588,
   "lat": 37.4922127,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzQxIyQxIyQ3IyQ5MiQzNjE4MzIjNDEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20200910,
   "hours": null
  },
  {
   "name": "옵티마북삼약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 효자로 683, 1층 101호 (효가동)",
   "tel": "033-522-1596",
   "lng": 129.1088937,
   "lat": 37.4926963,
   "dong": "효가동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQxIyQ3MiQ0NjE0ODEjNzEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 19880914,
   "hours": null
  },
  {
   "name": "희망약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 천곡로 86-2, 110호 (천곡동, 대륜빌딩)",
   "tel": "033-535-0628",
   "lng": 129.1150224,
   "lat": 37.5228662,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQxIyQ3MiQ0NjEwMDIjNjEjJDEjJDQjJDgz",
   "doctors": null,
   "estb": 19880914,
   "hours": null
  },
  {
   "name": "광제약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 송정중앙로 59, (송정동)",
   "tel": "033-522-4109",
   "lng": 129.1260124,
   "lat": 37.4988336,
   "dong": "송정동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQxIyQ2MiQ0NjEwMDIjODEjJDEjJDIjJDgz",
   "doctors": null,
   "estb": 19780720,
   "hours": null
  },
  {
   "name": "강원약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 중앙로 223, (천곡동)",
   "tel": "033-533-4373",
   "lng": 129.1144663,
   "lat": 37.520579,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQxIyQ2MiQ0NjE0ODEjNDEjJDEjJDQjJDgz",
   "doctors": null,
   "estb": 19790901,
   "hours": null
  },
  {
   "name": "현대프라자약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 향로복개로 2, (발한동)",
   "tel": "033-531-3193",
   "lng": 129.1021255,
   "lat": 37.5416203,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQxIyQ2MiQzNjEyMjIjNTEjJDEjJDYjJDgz",
   "doctors": null,
   "estb": 19800613,
   "hours": null
  },
  {
   "name": "금강약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 발한로 180, (발한동)",
   "tel": "033-533-2309",
   "lng": 129.1063034,
   "lat": 37.5468778,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxMzUxIzIxIyQxIyQxIyQ2MiQyNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 19780526,
   "hours": null
  },
  {
   "name": "미소약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 청운1길 51, (쇄운동)",
   "tel": "033-521-3977",
   "lng": 129.1088409,
   "lat": 37.4862869,
   "dong": "쇄운동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzIxIyQyIyQxIyQwMCQyNjEyMjIjODEjJDEjJDYjJDgz",
   "doctors": null,
   "estb": 20070201,
   "hours": null
  },
  {
   "name": "영동약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 중앙로 237, (천곡동)",
   "tel": "033-533-7702",
   "lng": 129.113774,
   "lat": 37.5220356,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzIxIyQxIyQxIyQ3MiQ0NjE0ODEjNTEjJDEjJDIjJDgz",
   "doctors": null,
   "estb": 20000907,
   "hours": null
  },
  {
   "name": "삼성약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 발한로 212-1, (발한동)",
   "tel": "033-532-6918",
   "lng": 129.1090325,
   "lat": 37.5484192,
   "dong": "발한동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzIxIyQxIyQ1IyQ4MiQzNjEwMDIjNDEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20110331,
   "hours": null
  },
  {
   "name": "삼삼온누리약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 천곡로 50, 삼성빌딩 1층 가호 (천곡동)",
   "tel": "533-3993",
   "lng": 129.1106683,
   "lat": 37.5238378,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzIxIyQyIyQ1IyQwMCQyNjEwMDIjNzEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20091123,
   "hours": null
  },
  {
   "name": "그린옵티마약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 한섬로 111-7, (천곡동)",
   "tel": "033-533-8441",
   "lng": 129.1152178,
   "lat": 37.5222543,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzIxIyQxIyQ5IyQ2MiQzNjEyMjIjNDEjJDEjJDgjJDgz",
   "doctors": null,
   "estb": 20130530,
   "hours": null
  },
  {
   "name": "건강약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 천곡로 68, 현대코아 111호 (천곡동)",
   "tel": "033-535-7525",
   "lng": 129.1128123,
   "lat": 37.5232812,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzMxIyQxIyQ3IyQ4MiQyNjE0ODEjNDEjJDEjJDQjJDgz",
   "doctors": null,
   "estb": 20181218,
   "hours": null
  },
  {
   "name": "동해선약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 청운1길 64, 102호 (나안동)",
   "tel": "033-522-0128",
   "lng": 129.1102081,
   "lat": 37.485907,
   "dong": "나안동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzQxIyQxIyQ3IyQwMyQzNjE4MzIjODEjJDEjJDIjJDgz",
   "doctors": null,
   "estb": 20220504,
   "hours": null
  },
  {
   "name": "시네마약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 한섬로 111-7, (천곡동)",
   "tel": "033-532-4488",
   "lng": 129.1152178,
   "lat": 37.5222543,
   "dong": "천곡동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzIxIyQyIyQ5IyQwMCQzNjEyMjIjNjEjJDEjJDAjJDgz",
   "doctors": null,
   "estb": 20130201,
   "hours": null
  },
  {
   "name": "효선약국",
   "type": "약국",
   "addr": "강원특별자치도 동해시 하평로 10, 효선약국 1층 (평릉동)",
   "tel": "033-532-4952",
   "lng": 129.1061525,
   "lat": 37.5308931,
   "dong": "평릉동",
   "ykiho": "JDQ4MTYyMiM1MSMkMSMkNCMkMDMkMzgxOTYxIzUxIyQxIyQxIyQ3OSQzNjEyMjIjODEjJDEjJDIjJDgz",
   "doctors": null,
   "estb": 20221004,
   "hours": null
  }
 ]
};
