// 동해 응급·약국 길잡이 — 데이터 수집 (Node 18+, fetch 내장)
// 사용: node 수집.mjs   → 같은 폴더에 data.js 생성
// 인증키는 ../설정/공공데이터.json 의 datagokr_key 에서 읽는다 (출력·저장하지 않음).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CFG = path.join(HERE, '..', '설정', '공공데이터.json');
const OUT = path.join(HERE, 'data.js');

const rawKey = JSON.parse(fs.readFileSync(CFG, 'utf8')).datagokr_key || '';
if (!rawKey) { console.error('datagokr_key 가 없습니다.'); process.exit(1); }
const KEY = rawKey.includes('%') ? rawKey : encodeURIComponent(rawKey);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const enc = encodeURIComponent;

// 키가 들어간 URL 은 절대 출력하지 않는다.
async function call(base, params, { retry = 1 } = {}) {
  const q = Object.entries(params).map(([k, v]) => `${k}=${enc(v)}`).join('&');
  const url = `${base}${base.includes('?') ? '&' : '?'}serviceKey=${KEY}&${q}${q ? '&' : ''}_type=json`;
  let last = { ok: false, status: 0, error: 'unknown' };
  for (let i = 0; i <= retry; i++) {
    try {
      const res = await fetch(url, { headers: { Accept: 'application/json' } });
      const text = await res.text();
      if (!res.ok) { last = { ok: false, status: res.status, error: 'HTTP ' + res.status }; }
      else {
        let j;
        try { j = JSON.parse(text); }
        catch { last = { ok: false, status: res.status, error: '비JSON 응답' }; if (i < retry) await sleep(400); continue; }
        const code = j?.response?.header?.resultCode;
        if (code && code !== '00') { last = { ok: false, status: res.status, error: 'resultCode ' + code + ' ' + (j.response.header.resultMsg || '') }; if (code === '03') return { ...last, empty: true }; }
        else return { ok: true, status: res.status, body: j?.response?.body ?? null };
      }
    } catch (e) { last = { ok: false, status: 0, error: String(e.message || e) }; }
    if (i < retry) await sleep(500);
  }
  return last;
}

function items(body) {
  const it = body?.items;
  if (!it || it === '') return [];
  const x = it.item ?? it;
  if (x == null || x === '') return [];
  return Array.isArray(x) ? x : [x];
}
const num = (v) => (v === undefined || v === null || v === '' ? null : Number(v));
const log = (...a) => console.log(...a);

const status = { hospitals: 0, hours: 0, er: 0, erRealtime: 0, erMessages: 0, pharmacies: 0, pharmacyHours: 0 };
const notes = [];

// 1. 병원 목록
async function fetchBasis(url, label) {
  const all = [];
  for (let page = 1; page <= 10; page++) {
    const r = await call(url, { sidoCd: '320000', sgguCd: '320200', numOfRows: '200', pageNo: String(page) });
    if (!r.ok) return { ok: false, error: r.error, list: all };
    const list = items(r.body);
    all.push(...list);
    const total = num(r.body?.totalCount) ?? list.length;
    if (all.length >= total || list.length === 0) break;
    await sleep(150);
  }
  return { ok: true, list: all };
}

const hospRes = await fetchBasis('https://apis.data.go.kr/B551182/hospInfoServicev2/getHospBasisList', '병원');
if (!hospRes.ok) notes.push('병원 목록 실패: ' + hospRes.error);
const mapFac = (h) => ({
  name: h.yadmNm, type: h.clCdNm, addr: h.addr, tel: h.telno || null,
  lng: num(h.XPos), lat: num(h.YPos), dong: h.emdongNm || null, ykiho: h.ykiho,
  doctors: num(h.drTotCnt), estb: h.estbDd || null, hours: null,
});
const hospitals = hospRes.list.map(mapFac);
status.hospitals = hospitals.length;
log('병원', hospitals.length);

// 운영시간
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
function mapHours(d) {
  const h = {};
  for (const D of DAYS) {
    const s = d['trmt' + D + 'Start'], e = d['trmt' + D + 'End'];
    const ss = s == null ? '' : String(s).padStart(4, '0'), ee = e == null ? '' : String(e).padStart(4, '0');
    h[D] = ss && ee && !(ss === '0000' && ee === '0000') ? [ss, ee] : null; // 0000~0000 = 휴진
  }
  return {
    ...h,
    noTrmtHoli: d.noTrmtHoli || null, noTrmtSun: d.noTrmtSun || null,
    lunchWeek: d.lunchWeek || null, rcvWeek: d.rcvWeek || null, rcvSat: d.rcvSat || null,
    parkXpnsYn: d.parkXpnsYn || null,
    emyDayYn: d.emyDayYn || null, emyNgtYn: d.emyNgtYn || null,
  };
}
const HOURS_ENDPOINTS = [
  'https://apis.data.go.kr/B551182/MadmDtlInfoService2.8/getDtlInfo2.8', // 2026-10 실측: 2.7 은 폐기, 2.8 동작
  'https://apis.data.go.kr/B551182/MadmDtlInfoService2.7/getDtlInfo2.7',
  'https://apis.data.go.kr/B551182/MadmDtlInfoService2/getDtlInfo2',
];
let hoursEp = null; // 동작이 확인된 엔드포인트
let hoursDead = false;
async function fetchHours(ykiho) {
  if (hoursDead) return null;
  const eps = hoursEp ? [hoursEp] : HOURS_ENDPOINTS;
  for (const ep of eps) {
    const r = await call(ep, { ykiho }, { retry: 1 });
    if (r.ok) {
      hoursEp = ep; const l = items(r.body);
      if (!l[0]) return null;
      const m = mapHours(l[0]);
      return DAYS.some((D) => m[D]) ? m : null; // 진료시간이 하나도 없으면 '정보 없음'
    }
    if (!hoursEp && (r.status === 403 || r.status === 404 || r.status === 401)) { continue; }
    if (!hoursEp) continue;
  }
  return undefined; // 오류
}
async function fillHours(list, label) {
  let ok = 0, fail = 0, firstFails = 0;
  for (const f of list) {
    if (hoursDead) break;
    const h = await fetchHours(f.ykiho);
    if (h === undefined) {
      fail++;
      if (!hoursEp) { firstFails++; if (firstFails >= 3) { hoursDead = true; notes.push(label + ' 운영시간 API 사용 불가(연속 실패) — 운영시간 없이 진행'); } }
    } else { if (h) { f.hours = h; ok++; } }
    await sleep(150);
  }
  return ok;
}
status.hours = await fillHours(hospitals, '병원');
log('운영시간(병원)', status.hours, hoursEp ? '엔드포인트 OK' : '엔드포인트 실패');

// 3. 응급의료기관 기본
const Q0 = '강원특별자치도', Q1 = '동해시';
const erBasic = await call('https://apis.data.go.kr/B552657/ErmctInfoInqireService/getEgytListInfoInqire', { Q0, Q1, numOfRows: '10' });
let er = [];
if (erBasic.ok) {
  er = items(erBasic.body).map((e) => ({
    hpid: e.hpid, name: e.dutyName, addr: e.dutyAddr, tel: e.dutyTel1 || null, telEr: e.dutyTel3 || null,
    lng: num(e.wgs84Lon), lat: num(e.wgs84Lat), kind: e.dutyEmclsName || null,
  }));
} else notes.push('응급의료기관 기본 실패: ' + erBasic.error);
status.er = er.length;
log('응급의료기관', er.length);
await sleep(150);

// 4. 응급실 실시간 가용병상
const erRt = await call('https://apis.data.go.kr/B552657/ErmctInfoInqireService/getEmrrmRltmUsefulSckbdInfoInqire', { STAGE1: Q0, STAGE2: Q1, numOfRows: '10' });
let erRealtime = [];
if (erRt.ok) {
  erRealtime = items(erRt.body).map((e) => ({
    hpid: e.hpid, name: e.dutyName, tel: e.dutyTel3 || null,
    hvec: num(e.hvec), hvoc: num(e.hvoc), hvgc: num(e.hvgc), hvicc: num(e.hvicc),
    hvctayn: e.hvctayn || null, hvmriayn: e.hvmriayn || null, hvventiayn: e.hvventiayn || null,
    hvidate: e.hvidate || null,
  }));
} else notes.push('응급실 실시간 실패: ' + erRt.error);
status.erRealtime = erRealtime.length;
log('응급실 실시간', erRealtime.length);
await sleep(150);

// 5. 응급실 메시지
const erMsg = await call('https://apis.data.go.kr/B552657/ErmctInfoInqireService/getEmrrmSrsillDissMsgInqire', { Q0, Q1, numOfRows: '20' });
let erMessages = [];
if (erMsg.ok) {
  erMessages = items(erMsg.body).map((e) => ({ hpid: e.hpid, name: e.dutyName, msg: e.symBlkMsg || e.symBlkMsgTyp || null, type: e.symTypCodMag || null, from: e.symBlkSttDtm || null, to: e.symBlkEndDtm || null }));
} else notes.push('응급실 메시지: ' + erMsg.error);
status.erMessages = erMessages.length;
log('응급실 메시지', erMessages.length);
await sleep(150);

// 6. 약국
let pharmacies = [];
let pharmacyStatus = 'ok';
const ph = await fetchBasis('https://apis.data.go.kr/B551182/pharmacyInfoService/getParmacyBasisList', '약국');
if (ph.ok) {
  pharmacies = ph.list.map(mapFac).map((p) => ({ ...p, type: '약국' }));
  status.pharmacies = pharmacies.length;
  hoursDead = false;
  status.pharmacyHours = await fillHours(pharmacies, '약국');
} else {
  pharmacyStatus = /403|401/.test(ph.error) ? '키 미등록(승인 대기)' : '조회 실패: ' + ph.error;
  notes.push('약국 API: ' + ph.error);
}
log('약국', pharmacies.length, pharmacyStatus);

const data = {
  generatedAt: new Date().toISOString(),
  center: { lat: 37.5247, lng: 129.1143 },
  status, pharmacyStatus, notes,
  hospitals, er, erRealtime, erMessages, pharmacies,
};
fs.writeFileSync(OUT, 'window.DATA = ' + JSON.stringify(data, null, 1) + ';\n', 'utf8');
log('data.js 생성:', Math.round(fs.statSync(OUT).size / 1024) + 'KB');
log('요약', JSON.stringify(status));
if (notes.length) log('참고', notes.join(' | '));
