// 동해시티투어버스 자료 만들기: node citytour수집.mjs  →  citytour.js (window.CITYTOUR)
// - 시간표·요금·규칙·정류장 좌표는 citytour.base.mjs (동해문화관광재단 dcitybus.com, 확인일 2026-10-17).
// - 정류장 ↔ 우리 장소(직선 400m 이내 + 이름이 같은 몇 곳): 카카오 걷기 길찾기(보통·무릎 두 가지)를 미리 받아 둠. 새 호출 상한 80, 길캐시/ 공유(다시 돌려도 호출 0회).
// - 공휴일: 한국천문연구원 특일정보 API 를 먼저 시도(서버 쪽, 키는 설정/공공데이터.json 의 datagokr_key, 찍지 않음). 안 되면 base 의 손 목록(확인필요).
// - 키는 어디에도 찍지 않고 citytour.js 에도 넣지 않는다.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { STOPS, END_TIMES, RULES, LINK_RADIUS, LINK_EXTRA, LINK_MAX_EXTRA, HOLIDAYS_FALLBACK } from './citytour.base.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const CACHE = join(HERE, '길캐시');
mkdirSync(CACHE, { recursive: true });
const KEYS = JSON.parse(readFileSync(join(HERE, '..', '..', '설정', '공공데이터.json'), 'utf8'));
const KEY = KEYS.kakao_rest_key, DKEY = KEYS.datagokr_key;
const require = createRequire(import.meta.url);
const D = require('./places.js'), P = require('./planner.js');
const pts = [...Object.values(D.stations), ...D.places];
const CAP = Number(process.env.CAP) || 80, DELAY = 150, DRY = !!process.env.DRY;
let calls = 0, cached = 0, failed = 0, would = 0;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(path, params) { // 길수집.mjs 와 같은 캐시 이름 규칙
  const qs = new URLSearchParams(params).toString();
  const h = createHash('sha1').update(path + '?' + qs).digest('hex').slice(0, 16);
  const f = join(CACHE, h + '.json');
  if (existsSync(f)) { cached++; return JSON.parse(readFileSync(f, 'utf8')); }
  if (DRY) { would++; return null; }
  if (!KEY) return null;
  if (calls >= CAP) throw new Error('호출 상한 ' + CAP);
  await sleep(DELAY); calls++;
  const res = await fetch('https://dapi.kakao.com' + path + '?' + qs, { headers: { Authorization: 'KakaoAK ' + KEY } });
  const txt = await res.text();
  if (!res.ok) { failed++; console.log('실패', path, res.status); return null; }
  writeFileSync(f, txt, 'utf8');
  return JSON.parse(txt);
}
function simplify(pts2, n) {
  if (pts2.length <= n) return pts2;
  const sq = (a, b, c) => { let x = b[0], y = b[1], dx = c[0] - x, dy = c[1] - y; if (dx || dy) { const t = Math.max(0, Math.min(1, ((a[0] - x) * dx + (a[1] - y) * dy) / (dx * dx + dy * dy))); x += t * dx; y += t * dy; } return (a[0] - x) ** 2 + (a[1] - y) ** 2; };
  let eps = 1e-9;
  for (let k = 0; k < 40; k++) {
    const keep = new Uint8Array(pts2.length); keep[0] = keep[pts2.length - 1] = 1;
    const st = [[0, pts2.length - 1]];
    while (st.length) { const [s, e] = st.pop(); let m = -1, md = 0; for (let i = s + 1; i < e; i++) { const d = sq(pts2[i], pts2[s], pts2[e]); if (d > md) { md = d; m = i; } } if (m >= 0 && md > eps) { keep[m] = 1; st.push([s, m], [m, e]); } }
    const out = pts2.filter((_, i) => keep[i]);
    if (out.length <= n) return out;
    eps *= 1.6;
  }
  return [pts2[0], pts2[pts2.length - 1]];
}
const r5 = (v) => Math.round(v * 1e5) / 1e5;
const dedupe = (p) => p.filter((q, i) => i === 0 || q[0] !== p[i - 1][0] || q[1] !== p[i - 1][1]);
const at = (p) => p.routeAt || p;
async function walk(a, b0, mode) {
  const b = at(b0);
  const j = await api('/v2/routing/walk', { start_x: a.lng, start_y: a.lat, end_x: b.lng, end_y: b.lat, route_mode: mode });
  if (!j || j.status !== 'OK' || !j.route) return null;
  const pr = j.route.properties || {};
  let path = [];
  (j.route.legs || []).forEach((l) => (l.steps || []).forEach((s) => { if (s.path && s.path.points) path = path.concat(s.path.points); }));
  path = dedupe(path);
  if (!(pr.totalTime > 0)) return null;
  return { sec: Math.round(pr.totalTime), m: Math.round(pr.totalDistance), path: simplify(path, 40).map((q) => [r5(q[0]), r5(q[1])]) };
}

// 연결 만들기
const stops = [];
let linkCount = 0;
for (const s of STOPS) {
  const links = [];
  const extra = LINK_EXTRA[s.i] || [];
  for (const p of pts) {
    const m = Math.round(P.hav(s, at(p)) * 1000);
    const near = m <= LINK_RADIUS, ex = extra.indexOf(p.id) >= 0 && m <= LINK_MAX_EXTRA;
    if (!near && !ex) continue;
    const w = await walk(s, p, 'BROAD_FIRST'), wa = await walk(s, p, 'ACCESSIBLE');
    const rec = { place: p.id, m, extra: !near };
    if (w) rec.walk = w;
    if (wa) rec.walkAccessible = wa;
    links.push(rec); linkCount++;
  }
  stops.push({ i: s.i, name: s.name, short: s.short, lat: s.lat, lng: s.lng, times: s.times, links });
}

// 공휴일
async function holidays() {
  const out = { year: 2026, source: '', confirmed: false, note: '', list: [] };
  if (DRY || !DKEY) return { ...HOLIDAYS_FALLBACK, source: '손으로 적은 목록(확인필요)' };
  try {
    const got = [];
    for (let mo = 1; mo <= 12; mo++) {
      const u = 'https://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getRestDeInfo?solYear=2026&solMonth=' + String(mo).padStart(2, '0') + '&_type=json&ServiceKey=' + encodeURIComponent(DKEY);
      const res = await fetch(u);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const j = await res.json();
      const items = j && j.response && j.response.body && j.response.body.items && j.response.body.items.item;
      if (!j.response) throw new Error('응답 형식 아님');
      (Array.isArray(items) ? items : items ? [items] : []).forEach((it) => { if (it.isHoliday === 'Y') { const d = String(it.locdate); got.push({ date: d.slice(0, 4) + '-' + d.slice(4, 6) + '-' + d.slice(6), name: it.dateName }); } });
      await sleep(120);
    }
    return { ...out, confirmed: true, source: '한국천문연구원 특일정보 API(getRestDeInfo)', note: '2026-10-17 수집', list: got };
  } catch (e) {
    console.log('공휴일 API 사용 불가(' + e.message + ') → 손으로 적은 목록(확인필요)');
    return { ...HOLIDAYS_FALLBACK, source: '손으로 적은 목록(확인필요) — 특일정보 API 는 이 키로 403' };
  }
}
const hol = await holidays();

const CT = { name: '동해시티투어버스', ...RULES, endTimes: END_TIMES, runs: 7, stops, holidays: hol, linkRadius: LINK_RADIUS };
writeFileSync(join(HERE, 'citytour.js'),
  '// 자동 생성: node citytour수집.mjs — 동해시티투어버스 시간표·요금·정류장·걷기 길(카카오 미리 받음). 직접 고치지 말 것. [경도,위도] 순서\n' +
  '(typeof window !== "undefined" ? window : globalThis).CITYTOUR = ' + JSON.stringify(CT) + ';\n', 'utf8');
console.log(JSON.stringify({ 정류장: stops.length, 연결: linkCount, 새호출: calls, 캐시사용: cached, 실패: failed, DRY새호출예정: DRY ? would : undefined, 공휴일: hol.list.length + '건 · ' + hol.source }));
