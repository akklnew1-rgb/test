// 편의 시설 자료 만들기: node 편의수집.mjs [--fresh]
//  - 전국공중화장실표준데이터(15012892) · 전국관광안내소표준데이터(15013112) 를 공공데이터포털 파일 받기 길(표준데이터 JSON 내려받기)로 받아 동해시만 거른다.
//    (OpenAPI 는 이 키가 그 서비스에 활용신청되어 있지 않아 쓰지 못함 — 키 없이도 되는 파일 받기를 쓴다)
//  - 숙박업소(3045119)·음식점현황(3045118) 파일은 자료/공공데이터/ 에 받아 둔 UTF-8 CSV 를 읽고, 주소를 카카오 로컬로 좌표 바꿈(합쳐 60회 이하, 캐시).
//  - 코스 점(장소·가게·역)에서 가까운 것만 골라 facilities.js (window.FACILITIES) 로 쓴다.
// 키: 설정/공공데이터.json 의 kakao_rest_key 만 읽고 어디에도 찍지 않는다.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const TOUR = dirname(fileURLToPath(import.meta.url));
const ROOT = join(TOUR, '..', '..');
const CACHE = join(TOUR, '수집캐시');
const PUB = join(ROOT, '자료', '공공데이터');
const FRESH = process.argv.includes('--fresh');
const D = createRequire(import.meta.url)(join(TOUR, 'places.js'));
const F = createRequire(import.meta.url)(join(TOUR, 'fac.js'));
mkdirSync(CACHE, { recursive: true });

/* ---------- 표준데이터 받기 (사이트의 JSON 내려받기와 같은 길) ---------- */
async function stdAll(pk) {
  const H = { 'User-Agent': 'Mozilla/5.0' };
  const hdr = await (await fetch(`https://www.data.go.kr/download/columList.json?pk=${pk}&ext=JSON`, { headers: H })).json();
  const t = hdr.tableVO, recs = [];
  for (let p = 1; p <= Math.ceil(hdr.totalCount / 10000); p++) {
    const q = new URLSearchParams();
    (t.colNmList || []).forEach((c) => q.append('colNmList', c));
    q.set('totalCount', hdr.totalCount); q.set('svcTableNm', t.svcTableNm); q.set('perPage', 10000); q.set('page', p); q.set('publicDataPk', pk);
    const j = await (await fetch(`https://www.data.go.kr/download/standard.json?${q}`, { headers: H })).json();
    (Array.isArray(j) ? j : []).forEach((x) => recs.push(x));
  }
  return { total: hdr.totalCount, recs };
}
const isDonghae = (r) => /동해시/.test([r.RDNMADR, r.LNMADR, r.INSTT_NM].join(' ')) && /강원/.test([r.RDNMADR, r.LNMADR, r.INSTT_NM].join(' '));
async function cachedStd(name, pk) {
  const f = join(CACHE, name);
  if (!FRESH && existsSync(f)) return JSON.parse(readFileSync(f, 'utf8'));
  const r = await stdAll(pk);
  const out = { got: new Date().toISOString().slice(0, 10), total: r.total, recs: r.recs.filter(isDonghae) };
  writeFileSync(f, JSON.stringify(out));
  return out;
}
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // 공공데이터포털 인증서 폐기 확인이 이 PC 에서 막힘(읽기 전용 공개 자료만 받음)
const toiletRaw = await cachedStd('표준_화장실_동해.json', '15012892');
const infoRaw = await cachedStd('표준_관광안내소_동해.json', '15013112');

/* ---------- 코스 점 ---------- */
const pts = [...Object.values(D.stations), ...D.places, ...D.eateries].map((p) => ({ id: p.id, lat: p.lat, lng: p.lng }));
const RADIUS = 1500; // 코스 점에서 이 거리 안(m)만 남김
const near = (r) => pts.some((p) => F.dist(p.lat, p.lng, r.lat, r.lng) <= RADIUS);

const h24 = (s) => /^\s*00:00\s*~\s*24:00/.test(s || '');
const toilets = toiletRaw.recs.map((r, i) => ({
  id: 'wc' + (i + 1), name: String(r.TOILET_NM || '').trim(), lat: +(+r.LATITUDE).toFixed(6), lng: +(+r.LONGITUDE).toFixed(6),
  hours: String(r.OPEN_TIME || '').trim(), h24: h24(r.OPEN_TIME),
  acc: (+r.MEN_HANDICAP_TOILET_BOWL_NUMBER || 0) + (+r.LADIES_HANDICAP_TOILET_BOWL_NUMBER || 0) > 0, // 장애인용 대변기가 있음
  diaper: r.DIPERS_EXCHG_POSI ? String(r.DIPERS_EXCHG_POSI).trim() : '', // 기저귀 교환대 위치(자료가 비어 있으면 '')
  bell: r.EMG_BELL_YN ? String(r.EMG_BELL_YN).trim() : '', // 비상벨(자료가 비어 있으면 '')
  addr: String(r.RDNMADR || r.LNMADR || '').trim(), ref: r.REFERENCE_DATE,
})).filter((r) => r.lat && r.lng && near(r));

const hhmmOk = (s) => /^\d{1,2}:\d{2}$/.test(s || '');
const infos = infoRaw.recs.map((r, i) => {
  const open = r.SUMMER_OPER_OPEN_HHMM, close = r.SUMMER_OPER_CLOSE_HHMM;
  const same = open === r.WINTER_OPER_OPEN_HHMM && close === r.WINTER_OPER_CLOSE_HHMM;
  const sane = hhmmOk(open) && hhmmOk(close) && open < close; // 캠핑장 사무실처럼 "14:00~11:00" 로 적힌 곳(체크인 시각)은 안내소 시간으로 쓸 수 없어 뺌
  return { id: 'ti' + (i + 1), name: String(r.TRSMIC_NM || '').trim(), place: String(r.TRSMIC_LC || '').trim(), addr: String(r.RDNMADR || '').trim(),
    hours: sane ? (same ? open + '~' + close : '하절기 ' + open + '~' + close + ' / 동절기 ' + r.WINTER_OPER_OPEN_HHMM + '~' + r.WINTER_OPER_CLOSE_HHMM) : '', sane,
    closed: r.RSTDE && r.RSTDE !== '없음' ? String(r.RSTDE).trim() : '', tel: String(r.GUIDANCE_PHONE_NUMBER || '').trim(), lat: +(+r.LATITUDE).toFixed(6), lng: +(+r.LONGITUDE).toFixed(6), ref: r.REFERENCE_DATE };
}).filter((r) => r.sane && r.lat && r.lng && near(r)).map(({ sane, ...r }) => r);

/* ---------- 숙박업소·음식점: 주소 → 좌표 (카카오 로컬, 합쳐 60회 이하, 캐시) ---------- */
const csv = (f) => {
  const t = readFileSync(join(PUB, f), 'utf8').replace(/^﻿/, '');
  return t.split(/\r?\n/).filter(Boolean).slice(1).map((l) => { const o = []; let c = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { o.push(c); c = ''; } else c += ch; } o.push(c); return o; });
};
const lodgingRows = csv('강원특별자치도_동해시_숙박업소_20251104_utf8.csv').map((r) => ({ name: r[1], addr: r[2], tel: r[3], kind: r[4], ref: r[5] }));
const foodRows = csv('강원특별자치도_동해시_음식점현황_20260324_utf8.csv').map((r) => ({ name: r[2], addr: r[3], kind: r[6], ref: r[7] }));
const roadKey = (a) => { const m = /(동해시\s+)([^\s,()]+(?:로|길)\d*)\s?(\d+(?:-\d+)?)/.exec(a.replace(/(로|길)(\d)/, '$1$2')); return m ? { road: m[2], no: m[3], q: '강원특별자치도 동해시 ' + m[2] + ' ' + m[3] } : null; };
const eatNames = new Set(D.eateries.map((e) => e.name));
// 한 끼 가게에서 가까울 만한 식당만 골라 부름: 식사 업태 + (묵호: 일출로·묵호시장길 / 천곡: 한섬로) — 합쳐 41곳 이하
const MEAL_KIND = /한식|횟집|중국식|분식|일식|경양식|냉면|탕류|칼국수|김밥/;
const BAN = /카페|커피|주점|호프|맥주|포차/;
const eatCand = [];
for (const r of foodRows) {
  if (!MEAL_KIND.test(r.kind) || BAN.test(r.name) || eatNames.has(r.name)) continue;
  const k = roadKey(r.addr); if (!k) continue;
  const dong = (/\(([^,)]*)/.exec(r.addr) || [, ''])[1];
  if (dong === '묵호진동' && ((k.road === '일출로' && parseInt(k.no, 10) <= 200) || k.road === '묵호시장길')) eatCand.push({ ...r, k, grp: 'mukho' });
  else if (dong === '천곡동' && k.road === '한섬로' && parseInt(k.no, 10) <= 200) eatCand.push({ ...r, k, grp: 'cheon' });
}
// 길 번호가 가까운 것부터: 묵호는 부흥(일출로 93)·오부자(일출로 151)·오뚜기(일출로 10-1) 사이를 우선, 천곡은 한섬로 135-3 가까운 순
const numOf = (k) => parseFloat(String(k.no).replace('-', '.'));
const mukhoSorted = eatCand.filter((r) => r.grp === 'mukho').sort((a, b) => (a.k.road === '일출로' ? 0 : 1) - (b.k.road === '일출로' ? 0 : 1) || Math.abs(numOf(a.k) - 100) - Math.abs(numOf(b.k) - 100));
const cheonSorted = eatCand.filter((r) => r.grp === 'cheon').sort((a, b) => Math.abs(numOf(a.k) - 135) - Math.abs(numOf(b.k) - 135));
const BUDGET = 60;
const lodgingList = lodgingRows.map((r) => ({ ...r, k: roadKey(r.addr) })).filter((r) => r.k);
const room = BUDGET - lodgingList.length;
const eatPick = [...mukhoSorted.slice(0, Math.max(0, room - 8)), ...cheonSorted.slice(0, 8)];

const geoFile = join(CACHE, '편의지오캐시.json');
const geo = existsSync(geoFile) ? JSON.parse(readFileSync(geoFile, 'utf8')) : {};
let calls = 0;
const cfg = JSON.parse(readFileSync(join(ROOT, '설정', '공공데이터.json'), 'utf8'));
async function geocode(q) {
  if (q in geo) return geo[q];
  if (calls >= BUDGET) return null;
  calls++;
  let out = null;
  try {
    const r = await fetch('https://dapi.kakao.com/v2/local/search/address.json?size=1&query=' + encodeURIComponent(q), { headers: { Authorization: 'KakaoAK ' + cfg.kakao_rest_key } });
    if (r.ok) { const j = await r.json(); const d = j.documents && j.documents[0]; if (d) out = [+(+d.y).toFixed(6), +(+d.x).toFixed(6)]; } else console.error('카카오 로컬 응답', r.status);
  } catch (e) { console.error('카카오 로컬 실패:', e.message); }
  geo[q] = out; writeFileSync(geoFile, JSON.stringify(geo)); await new Promise((s) => setTimeout(s, 120));
  return out;
}
const lodging = [], eats = [];
for (const r of lodgingList) { const c = await geocode(r.k.q); if (c) lodging.push({ name: r.name, kind: r.kind, addr: r.addr, tel: r.tel, lat: c[0], lng: c[1], ref: r.ref }); }
for (const r of eatPick) { const c = await geocode(r.k.q); if (c) eats.push({ name: r.name, kind: r.kind, addr: r.addr, lat: c[0], lng: c[1], ref: r.ref }); }
const mukho = D.stations.mukho;
const lodgingNear = lodging.filter((r) => F.dist(mukho.lat, mukho.lng, r.lat, r.lng) <= 3000); // 묵호역 3km 안만 남김(화면은 1km 안 곳 수와 가장 가까운 3곳)
// 식당은 한 끼 가게 4곳 중 어느 곳에서든 700m 안인 것만
const eatNear = eats.filter((r) => D.eateries.some((e) => F.dist(e.lat, e.lng, r.lat, r.lng) <= 700));

const out = {
  generated: new Date().toISOString().slice(0, 10),
  radius: RADIUS,
  source: {
    toilet: '공공데이터포털 전국공중화장실표준데이터(동해시 ' + toiletRaw.recs.length + '곳 중 코스 둘레 ' + toilets.length + '곳) · 자료 기준일 ' + [...new Set(toilets.map((t) => t.ref))].join(', '),
    info: '공공데이터포털 전국관광안내소표준데이터(동해시 ' + infoRaw.recs.length + '곳 중 안내소 시간이 정상인 ' + infos.length + '곳) · 자료 기준일 ' + [...new Set(infos.map((t) => t.ref))].join(', '),
    lodging: '공공데이터포털 강원특별자치도 동해시_숙박업소(2025-11-04) · 주소를 카카오 로컬로 좌표로 바꿈',
    food: '공공데이터포털 강원특별자치도 동해시_음식점현황(2026-03-24) · 주소를 카카오 로컬로 좌표로 바꿈',
  },
  toilets, infos, lodging: lodgingNear, eats: eatNear,
};
writeFileSync(join(TOUR, 'facilities.js'), '// 자동 생성: node 편의수집.mjs (' + out.generated + ') — 직접 고치지 말 것\n(function(root){var F=' + JSON.stringify(out, null, 1) + ';\nif(typeof module!==\'undefined\'&&module.exports)module.exports=F;else root.FACILITIES=F;})(typeof window!==\'undefined\'?window:globalThis);\n', 'utf8');

// 동해시만 거른 원자료도 자료/공공데이터 에 UTF-8 CSV 로 남김
const esc = (v) => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
const dump = (name, recs) => { const cols = Object.keys(recs[0] || {}); writeFileSync(join(PUB, name), '﻿' + [cols.join(','), ...recs.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\r\n'), 'utf8'); };
dump('전국공중화장실표준데이터_동해시_utf8.csv', toiletRaw.recs);
dump('전국관광안내소표준데이터_동해시_utf8.csv', infoRaw.recs);

console.log(JSON.stringify({ 화장실_동해전체: toiletRaw.recs.length, 화장실_코스둘레: toilets.length, 안내소_동해전체: infoRaw.recs.length, 안내소_채택: infos.length, 숙박_전체: lodgingRows.length, 숙박_좌표: lodging.length, 숙박_묵호역3km: lodgingNear.length, 식당_후보: eatPick.length, 식당_좌표: eats.length, 식당_근처채택: eatNear.length, 카카오로컬호출: calls, 캐시항목: Object.keys(geo).length }));
