// 코스 계산기·분류기·제보 반영·한 끼 장 규칙 시험: node test.cjs
const D = require('./places.js'), P = require('./planner.js'), AI = require('./ai.js');
require('./routes.js'); const ROUTES = globalThis.ROUTES, RP = ROUTES.pairs; // 미리 받은 카카오 길찾기(길수집.mjs)
const fs = require('fs');
let pass = 0, fail = 0;
function ok(c, msg) { if (c) { pass++; console.log('  ok  ' + msg); } else { fail++; console.log('  FAIL ' + msg); } }
const T = (s) => P.toMin(s);
const base = { now: 780, train: T('18:10'), end: 'mukho', slow: true, avoidStairs: true, interests: [] };
const ids = (pl) => pl.stops.map((s) => s.id);

console.log('[1] 돌아오는 시각은 항상 기차 15분 전 이내 (기차 x 출발 시각 x 조건 조합)');
let n = 0, bad = 0;
for (const train of ['15:10', '16:40', '18:10', '19:40']) for (const now of [660, 780, 840, 900]) for (const slow of [true, false]) for (const rain of [true, false]) for (const end of ['mukho', 'donghae']) for (const mode of ['normal', 'late']) {
  const pl = P.plan(D, { ...base, train: T(train), now, slow, avoidStairs: slow, rain, end, mode });
  n++;
  if (pl.feasible && pl.back.arrive > T(train) - 15) bad++;
  // 각 장의 도착·떠남도 시간순
  let t = now; pl.stops.forEach((s) => { if (s.arrive < t || s.leave <= s.arrive) bad++; t = s.leave; });
}
ok(bad === 0, `${n}가지 조합에서 위반 ${bad}건`);

console.log('[2] 부모님/무릎 → 계단 있는 곳 없음, 느리게 걷기');
const par = P.plan(D, base);
ok(par.stops.every((s) => !s.place.stairs), '부모님 코스에 계단 있는 곳 없음: ' + ids(par).join('>'));
ok(!ids(par).includes('lighthouse'), '묵호등대(계단)는 빠짐');
const fast = P.plan(D, { ...base, slow: false, avoidStairs: false });
ok(ids(fast).includes('lighthouse') || fast.stops.length >= par.stops.length, '일반 코스는 계단 곳도 후보 (등대 포함 또는 곳 수 같거나 많음): ' + ids(fast).join('>'));
const leg3 = P.leg(D.stations.mukho, D.places.find((p) => p.id === 'skyvalley'), true), leg4 = P.leg(D.stations.mukho, D.places.find((p) => p.id === 'skyvalley'), false);
ok(leg3.walk > leg4.walk, `같은 거리 도보 시간 느리게 ${leg3.walk}분 > 보통 ${leg4.walk}분`);

console.log('[3] 비 → 실내 우선');
const dry = P.plan(D, base), wet = P.plan(D, { ...base, rain: true });
const indoor = (pl) => pl.stops.filter((s) => s.place.indoor).length, outdoor = (pl) => pl.stops.filter((s) => !s.place.indoor).length;
ok(wet.stops[0].place.indoor, '비 오면 첫 장이 실내: ' + ids(wet).join('>'));
ok(outdoor(wet) < outdoor(dry), `야외 곳 수 ${outdoor(dry)} → ${outdoor(wet)} 로 줄어듦`);
ok(indoor(wet) >= indoor(dry), '실내 곳 수는 줄지 않음');

console.log('[4] 운영시간 존중');
const sky = D.places.find((p) => p.id === 'skyvalley');
const lateNow = P.plan(D, { ...base, now: T('17:30'), train: T('19:40'), mode: 'late' });
ok(lateNow.stops.every((s) => s.arrive + 0 <= s.place.open[1] && s.leave <= s.place.open[1]), '모든 장이 문 닫기 전에 끝남');
const early = P.plan(D, { ...base, train: T('19:40'), mode: 'late' });
const nm = early.stops.find((s) => s.id === 'nightmarket');
ok(!nm || nm.startVisit >= 18 * 60, '야시장은 18:00 이후에만: ' + (nm ? P.fmt(nm.startVisit) : '(없음)'));
ok(!!nm, '막차(19:40) 코스에는 야시장이 들어감');
const eve = P.plan(D, base);
ok(!ids(eve).includes('nightmarket'), '18:10 기차 코스에는 야시장 없음');

console.log('[5] 막차·1박');
const night = P.plan(D, { ...base, mode: 'night' });
ok(night.tomorrow && night.tomorrow.place.id === 'chuam', '1박: 내일 마지막 장은 추암');
ok(night.tomorrow.arrive < night.tomorrow.sunrise && night.tomorrow.sunrise === T('06:25') + 1440, '일출 06:25(예시) 전에 도착: ' + P.fmt(night.tomorrow.arrive));
ok(!ids(night).includes('chuam'), '오늘 코스에는 추암 없음(내일로 남김)');

console.log('[6] 동해역으로 끝내기');
const dh = P.plan(D, { ...base, end: 'donghae' });
ok(dh.endStation.name === '동해역' && dh.back.arrive <= T('18:10') - 15, '동해역 도착 ' + P.fmt(dh.back.arrive));

console.log('[7] 제보 → 효과 (붐빔 → 순서 바뀜)');
const before = P.plan(D, base);
const rep = { type: 'crowd', placeId: 'skyvalley', minutes: 20, simTs: 780 };
const fx1 = P.effectsFromReports([rep], 780, true);
const after = P.plan(D, { ...base, fx: fx1 });
ok(fx1.crowd.skyvalley && fx1.crowd.skyvalley.until === 840, '붐빔 효과 생김, 14:00 까지(60분)');
// (실제 역 위치 반영 뒤 도째비골은 14:26 도착이라 14:00 에 풀리는 붐빔과 겹치지 않음 → 순서 바뀜은 첫 장(논골담길) 붐빔 제보로 확인)
const fxN = P.effectsFromReports([{ type: 'crowd', placeId: 'nolgol', minutes: 20, simTs: 780 }], 780, true);
const afterN = P.plan(D, { ...base, fx: fxN });
ok(ids(before).join() !== ids(afterN).join(), `순서 바뀜: ${ids(before).join('>')}  →  ${ids(afterN).join('>')}`);
ok(afterN.back.arrive <= T('18:10') - 15, '순서가 바뀐 코스도 기차 15분 전 이내');
const sAfter = after.stops.find((s) => s.id === 'skyvalley');
ok(!sAfter || sAfter.arrive >= fx1.crowd.skyvalley.until || sAfter.delay > 0, '도째비골은 붐빔이 풀린 뒤에 가거나 기다림이 들어감 (도착 ' + (sAfter ? P.fmt(sAfter.arrive) : '-') + ')');
ok(after.back.arrive <= T('18:10') - 15, '바뀐 코스도 기차 15분 전 이내');
const fxOld = P.effectsFromReports([rep], 780 + 61, true);
ok(!fxOld.crowd.skyvalley, '61분 지나면 붐빔 제보 소멸');
const fxEdge = P.effectsFromReports([rep], 780 + 59, true);
ok(!!fxEdge.crowd.skyvalley, '59분 지났어도 아직 유효');
const fxTwo = P.effectsFromReports([rep], 780, false);
ok(!fxTwo.crowd.skyvalley && fxTwo.pending.length === 1, '한 건으로 반영 끄면 1건은 대기');
const fxTwo2 = P.effectsFromReports([rep, { ...rep, simTs: 790 }], 800, false);
ok(!!fxTwo2.crowd.skyvalley, '같은 제보 2건이면 반영');
const closed = P.plan(D, { ...base, fx: P.effectsFromReports([{ type: 'closed', placeId: 'nolgol', simTs: 780 }], 780, true) });
ok(!ids(closed).includes('nolgol'), '휴무 제보 → 코스에서 빠짐');
const view = P.plan(D, { ...base, fx: P.effectsFromReports([{ type: 'view', placeId: 'eodal', simTs: 780 }], 780, true) });
ok(ids(view).includes('eodal'), '풍경 좋음 제보 → 어달해변이 코스에 들어옴');

console.log('[8] "여기 왔어요" (도착한 장 고정, 이후만 재계산)');
const stopsA = P.plan(D, base).stops;
const fixed = [stopsA[0]];
const fxA = P.effectsFromReports([{ type: 'crowd', placeId: stopsA[1].id, minutes: 20, simTs: stopsA[0].arrive }], stopsA[0].arrive, true);
const re = P.plan(D, { ...base, now: stopsA[0].arrive, fixed, fx: fxA });
ok(re.stops[0].id === stopsA[0].id && re.stops[0].arrive === stopsA[0].arrive, '첫 장은 그대로 고정');
ok(re.back.arrive <= T('18:10') - 15, '재계산해도 기차 15분 전 이내');

console.log('[9] 분류기(규칙)');
const c1 = AI.aiClassifyReport('도째비골 줄 20분', null, '');
ok(c1.type === 'crowd' && c1.placeId === 'skyvalley' && c1.minutes === 20, '"도째비골 줄 20분" → 붐빔·도째비골·20분');
const c2 = AI.aiClassifyReport('논골담길 가게 오늘 휴무예요', null, '');
ok(c2.type === 'closed' && c2.placeId === 'nolgol', '"논골담길 … 휴무" → 휴무·논골담길');
const c3 = AI.aiClassifyReport('노을 최고', null, 'lighthouse');
ok(c3.type === 'view' && c3.placeId === 'lighthouse', '"노을 최고" → 좋은 풍경');
const c4 = AI.aiClassifyReport('', 'crowd', 'skyvalley');
ok(c4.type === 'crowd' && c4.minutes === 20, '글이 없으면 고른 종류 사용');
const c5 = AI.aiClassifyReport('야시장 줄이 길어요', null, '');
ok(c5.placeId === 'nightmarket', '"야시장" 은 도째비골과 구분');

console.log('[10] 말·글 해석(규칙)');
const p1 = AI.aiParseRequest('6시 10분 기차, 부모님과 가요', 780);
ok(p1.train === T('18:10') && p1.companions.includes('부모님'), '"6시 10분 기차, 부모님과" → 18:10 · 부모님');
const p2 = AI.aiParseRequest('오전 11시 30분 기차 무릎이 안 좋아요 사진 찍고 싶어요', 540);
ok(p2.train === T('11:30') && p2.knee && p2.interests.includes('사진'), '오전 11:30 · 무릎 · 사진');
const p3 = AI.aiParseRequest('19:40 막차 친구랑 비 와요 동해역에서 타요 2명', 780);
ok(p3.train === T('19:40') && p3.rain && p3.end === 'donghae' && p3.count === 2 && p3.companions.includes('친구'), '19:40 · 비 · 동해역 · 2명 · 친구');
ok(AI.aiParseRequest('2시간 걸려요', 780).train === null, '"2시간" 은 시각으로 읽지 않음');

console.log('[11] 도째비에게 묻기');
const sk = D.places.find((p) => p.id === 'skyvalley');
ok(AI.aiAnswer(sk, '도째비가 무슨 뜻이에요?').found, '준비된 질문에 답');
ok(AI.aiAnswer(sk, '주차장 요금이 얼마예요').text === AI.NOT_FOUND, '모르는 것은 "그건 기록에 없어요 — 관광안내소에 물어보세요"');
ok(D.places.every((p) => p.qa.length >= 2 && p.출처 && typeof p.확인필요 === 'boolean' && (p.확인필요 === false ? p.contentid && /\d:\d\d/.test(p.openText) || /상시/.test(p.openText) : true)), '모든 장소: 질문 2개 이상 · 출처 · 확인필요 표시(운영시간을 자료에서 읽은 곳만 false)');
ok(D.places.every((p) => p.contentid ? p.좌표확인필요 === false && p.출처 === '한국관광공사 관광정보' && p.원문 && p.원문.length > 40 : p.좌표확인필요 === true), '관광공사와 짝지은 곳: 좌표확인필요 false · 출처 · 개요 원문 / 못 찾은 곳: 대략 좌표');

console.log('[11b] 관광공사 실제 자료 (좌표·이야기·사진)');
const real = D.places.filter((p) => p.contentid);
ok(real.length >= 6, `관광공사와 짝지은 장소 ${real.length}/${D.places.length}`);
ok(real.every((p) => p.lat > 37.40 && p.lat < 37.65 && p.lng > 128.95 && p.lng < 129.20 && p.addr && /동해시/.test(p.addr)), '짝지은 곳 좌표·주소가 동해시 안');
const sentences = (t) => t.split(/(?<=[.!?요])\s+/).filter(Boolean);
ok(real.every((p) => sentences(p.story).length >= 2 && sentences(p.story).length <= 4), '이야기는 2~4문장: ' + real.map((p) => p.id + ' ' + sentences(p.story).length).join(', '));
const nums = (t) => (t.match(/\d[\d,.]*/g) || []).map((x) => x.replace(/[,.]+$/, ''));
ok(real.every((p) => nums(p.story).every((n) => p.원문.replace(/,/g, '').includes(n.replace(/,/g, '')))), '이야기 속 숫자는 모두 원문(개요)에 있는 숫자 — 사실을 더하지 않음');
const PHOTO_OK = (p) => !p.photo || (/^사진캐시\/\d+\.(jpg|png|gif|webp)$/.test(p.photo) && /^Type[13]$/.test(p.photoType) && fs.existsSync(require('path').join(__dirname, p.photo)) && fs.statSync(require('path').join(__dirname, p.photo)).size > 1000);
ok(real.every(PHOTO_OK), '사진은 사진캐시/ 의 파일(실제로 있음) + 공공누리 제1·3유형만');
ok(real.every((p) => !!p.photo === !!p.photoType), '사진과 공공누리 유형은 함께 있거나 함께 없음(유형 없으면 그림)');
ok(real.some((p) => !p.photo) && real.some((p) => p.photo), '사진이 없는 곳(그림으로 대신)과 있는 곳이 모두 있음');
const lh = D.places.find((p) => p.id === 'lighthouse'), sv = D.places.find((p) => p.id === 'skyvalley');
ok(lh.open[0] === 540 && lh.open[1] === 1020 && /09:00~17:00/.test(lh.openText), '묵호등대 운영시간은 자료의 09:00~17:00');
ok(sv.open[0] === 600 && sv.open[1] === 1020, '스카이밸리: 하절기 18:00 / 동절기 17:00 → 짧은 쪽 17:00 기준');
ok(D.places.find((p) => p.id === 'nightmarket').확인필요 === true && !D.places.find((p) => p.id === 'nightmarket').contentid, '야시장은 관광공사 자료에 없어 대략값 · 확인필요 유지');

console.log('[12] 끼니 시간 슬롯 (2026-10-18) — 코스에는 특정 식당을 넣지 않고 점심·저녁 시간만 잡는다');
const meals = (pl) => pl.stops.filter((s) => s.kind === 'meal');
const eat = (id) => D.eateries.find((e) => e.id === id);
const EATIDS = new Set(D.eateries.map((e) => e.id));
const isRestaurantId = (id) => /^eat_/.test(id) || EATIDS.has(id);
ok(D.eateries.length >= 4 && D.eateries.length <= 6 && D.eateries.every((e) => e.contentid && e.tourapi && !/\(예시\)/.test(e.name) && !e.예시 && e.출처 === '한국관광공사 관광정보' && e.확인필요 === true && e.좌표확인필요 === false && e.원문), '식당 자료(지도에 보여 주는 용도): 관광공사 contentid · 출처 · 영업은 방문 전 확인');
ok(D.eateries.every(PHOTO_OK), '식당 자료 사진도 사진캐시/ 파일 + 공공누리 제1·3유형만(지도 카드에는 쓰지 않음)');
ok(D.eateries.every((e) => !Object.keys(e).some((k) => /rating|star|rank|review|ad$|별점|순위|후기|광고/i.test(k))), '별점·순위·후기·광고 칸이 없음');
const lunch = P.plan(D, { ...base, now: T('11:30'), train: T('15:10'), date: '2026-10-24' });
ok(meals(lunch).length === 1 && meals(lunch)[0].place.slot && meals(lunch)[0].place.mealKind === 'lunch', '점심 시간대가 걸치면 점심 시간 슬롯이 정확히 한 번 들어감: ' + ids(lunch).join('>'));
ok(meals(lunch)[0].startVisit >= 660 && meals(lunch)[0].startVisit <= 810, '점심은 11:00~13:30 사이에 시작: ' + P.fmt(meals(lunch)[0].startVisit));
ok(lunch.back.arrive <= T('15:10') - 15, '점심 시간이 들어가도 기차 15분 전 도착: ' + P.fmt(lunch.back.arrive));
ok(P.plan(D, base).mealNeeded === false && meals(P.plan(D, base)).length === 0, '13:00~18:10 코스는 끼니 겹침이 60분 미만 → 끼니 슬롯 없음(기존 코스 그대로)');
// 슬롯은 자리 중립: 앞 장소와 같은 좌표 · 이동 0분 · 다음 장 길은 앞 장소에서 계산
{ const pm = P.plan(D, { ...base, now: T('10:00'), train: T('19:40'), food: true, date: '2026-10-24', routes: RP }); const i = pm.stops.findIndex((s) => s.kind === 'meal');
  const prevP = i > 0 ? pm.stops[i - 1].place : pm.startStation;
  ok(i >= 0 && pm.stops[i].legMin === 0 && pm.stops[i].place.lat === prevP.lat && pm.stops[i].place.lng === prevP.lng && pm.stops[i].place.base === P.realPos(prevP), '슬롯: 앞 장소와 같은 자리(좌표) · 이동 0분: ' + ids(pm).join('>'));
  ok(!pm.stops[i + 1] || pm.stops[i + 1].real === !!(RP[P.realPos(prevP).id + '|' + pm.stops[i + 1].id] || RP[pm.stops[i + 1].id + '|' + P.realPos(prevP).id]), '슬롯 뒤 장의 길은 슬롯이 아니라 앞 장소 기준의 실제 길을 씀'); }
// 조합 훑기: 슬롯은 0~1번, 식당 id 는 0개, 기차 15분 전 도착과 시간 순서 유지
let nM = 0, nBad = 0, nWith = 0, nRest = 0;
for (const train of ['13:30', '15:10', '16:40', '18:10', '19:40']) for (const now of [600, 690, 720, 780, 960, 1030]) for (const food of [false, true]) for (const slow of [true, false]) for (const end of ['mukho', 'donghae']) for (const mode of ['normal', 'late']) {
  const tr = mode === 'late' ? T(D.trains.last[end]) : T(train); // 앱이 하는 대로: 막차 모드는 그 역의 막차
  const pl = P.plan(D, { ...base, train: tr, now, slow, avoidStairs: slow, end, mode, food, date: '2026-10-24' });
  nM++;
  const ms = meals(pl);
  if (ms.length > 1) nBad++;
  if (ms.length) nWith++;
  if (pl.stops.some((s) => isRestaurantId(s.id))) nRest++;
  if (pl.feasible && pl.back.arrive > tr - 15) nBad++;
  let t = now; pl.stops.forEach((s) => { if (s.arrive < t || s.leave <= s.arrive) nBad++; t = s.leave; });
}
ok(nBad === 0 && nWith > 0, `끼니 슬롯 조합 ${nM}가지 중 ${nWith}가지에 슬롯 · 위반 ${nBad}건(두 번 이상·시간 순서·기차 15분 전)`);
ok(nRest === 0, `코스에 식당(eat_…) 장이 한 곳도 없음 (${nM}가지 조합, 식당 장 ${nRest}건)`);
const young = P.plan(D, { ...base, now: T('12:00'), food: true, slow: false, avoidStairs: false, soft: false });
ok(meals(young).length === 1 && meals(young)[0].place.slot, '일반 코스도 점심 시간 슬롯이 들어감: ' + meals(young)[0].id);
const asked = P.plan(D, { ...base, now: T('14:00'), train: T('18:10'), food: true });
ok(meals(asked).length === 1 && asked.mealNeeded, '"먹고 싶다" 하면 끼니 겹침이 짧아도 슬롯이 들어감(14:00 출발): ' + P.fmt(meals(asked)[0].startVisit));
const tight = P.plan(D, { ...base, now: T('12:00'), train: T('12:55'), food: true });
ok(meals(tight).length === 0 && tight.mealNeeded === false, '남는 시간이 50분 미만(12:00~12:40)이면 슬롯을 넣지 않음');
const noMeal = P.plan(D, { ...base, now: T('11:30'), train: T('15:10'), meal: false });
ok(meals(noMeal).length === 0, 'meal:false 이면 넣지 않음');
// 먹고 싶은 음식 낱말은 이제 식당을 고르지 않는다: foodWord 가 있어도 식당 장 0
const wantPar = AI.aiParseRequest('6시 10분 기차, 부모님과 가요. 점심도 먹고 싶어요', 720);
ok(wantPar.food && wantPar.companions.includes('부모님'), '"점심도 먹고 싶어요" → food (끼니 슬롯 요청)');
const wantPl = P.plan(D, { ...base, now: T('12:00'), food: true, foodWord: '물회', date: '2026-10-24' });
ok(meals(wantPl).length === 1 && meals(wantPl)[0].place.slot && !wantPl.stops.some((s) => isRestaurantId(s.id)), '"물회" 를 말해도 식당을 고르지 않고 점심 시간만: ' + ids(wantPl).join('>'));
// 막차 = 저녁 시간 슬롯
const lastTrain = P.plan(D, { ...base, train: T('19:40'), mode: 'late', date: '2026-10-24' });
ok(meals(lastTrain).length === 1 && meals(lastTrain)[0].place.mealKind === 'dinner' && meals(lastTrain)[0].startVisit >= 1020 && meals(lastTrain)[0].startVisit <= 1170, '막차 코스에 저녁 시간 슬롯(17:00~19:30 시작): ' + P.fmt(meals(lastTrain)[0].startVisit));
ok(lastTrain.back.arrive <= T('19:40') - 15 && lastTrain.stops.some((s) => s.id === 'nightmarket'), '저녁 시간이 들어가도 막차 15분 전 도착 · 야시장도 그대로 들어감: ' + ids(lastTrain).join('>'));
// 식당 제보(줄·휴무)는 코스를 바꾸지 않는다 — 계산기에 식당이 없으니 같은 코스
const baseFood = P.plan(D, { ...base, now: T('12:00'), food: true, date: '2026-10-24' });
const fxShop = P.effectsFromReports([{ type: 'crowd', placeId: 'eat_obuja', minutes: 30, simTs: T('12:00') }, { type: 'closed', placeId: 'eat_ottugi', simTs: T('12:00') }], T('12:00'), true);
ok(ids(P.plan(D, { ...base, now: T('12:00'), food: true, date: '2026-10-24', fx: fxShop })).join() === ids(baseFood).join(), '식당 줄·휴무 제보가 들어와도 코스는 그대로(식당이 코스에 없음)');
// 이미 먹은 뒤(여기 왔어요)에는 또 넣지 않음
const first = P.plan(D, { ...base, now: T('12:00'), food: true, date: '2026-10-24' });
const mi = first.stops.findIndex((s) => s.kind === 'meal');
const afterEat = P.plan(D, { ...base, now: first.stops[mi].leave, food: true, date: '2026-10-24', fixed: first.stops.slice(0, mi + 1) });
ok(meals(afterEat).length === 1 && afterEat.stops[mi].id === first.stops[mi].id, '끼니 슬롯 뒤에는 그 슬롯 그대로, 두 번째 슬롯 없음');

console.log('[13] 제보 분류: 가게 낱말은 반영하지 않음 · 볼거리 제보는 그대로');
const f1 = AI.aiClassifyReport('물회집 줄 30분', null, '');
ok(f1.type === 'crowd' && f1.shop === true && !f1.placeId && !f1.food, '"물회집 줄 30분" → 가게 제보라서 반영 안 함(shop, 장소 없음)');
const f2 = AI.aiClassifyReport('오뚜기칼국수 오늘 휴무', null, '');
ok(f2.type === 'closed' && f2.shop === true && !f2.placeId, '"오뚜기칼국수 오늘 휴무" → 가게 제보(반영 안 함)');
ok(AI.aiClassifyReport('영빈관횟집 오늘 메뉴 우럭미역국 가능', null, '').shop === true && AI.aiClassifyReport('부흥횟집 줄 길어요', null, '').shop === true, '"영빈관횟집 오늘 메뉴"·"부흥횟집 줄" 도 가게 제보');
ok(AI.aiClassifyReport('야시장 줄이 길어요', null, '').placeId === 'nightmarket' && !AI.aiClassifyReport('야시장 줄이 길어요', null, '').shop, '"야시장" 은 볼거리(도째비골 야시장) — 그대로 반영');
ok(AI.aiClassifyReport('도째비골 줄 20분', null, '').type === 'crowd' && AI.aiClassifyReport('도째비골 줄 20분', null, '').placeId === 'skyvalley' && AI.aiClassifyReport('도째비골 줄 20분', null, '').shop === false, '볼거리 제보("도째비골 줄 20분")는 그대로 분류');
ok(AI.aiClassifyReport('', 'crowd', 'eat_buheung').placeId !== 'eat_buheung', '고른 장소가 가게(eat_…)여도 반영하지 않음');
ok(['먹고 싶어요', '맛집 가고 싶어요', '물회 좋아해요', '밥 먹고', '식사는 어디서', '배고파요', '점심 먹을래요'].every((t) => AI.aiParseRequest(t, 780).food) && !AI.aiParseRequest('6시 10분 기차, 부모님과', 780).food, '"먹·맛집·물회·밥·식사·배고·점심" 이 있으면 food(끼니 시간 요청)');
{ const aiSrc = fs.readFileSync(require('path').join(__dirname, 'ai.js'), 'utf8'); ok(/aiReadMenu/.test(aiSrc), '메뉴판 읽기 함수는 ai.js 에 남아 있되 화면에서는 안 씀(가게에 묶인 도우미 제거)'); }

console.log('[길] 실제 길(카카오 길찾기 미리 받은 값) — 걷기·ACCESSIBLE·대중교통·fallback');
const PT = Object.fromEntries([...Object.values(D.stations), ...D.places, ...D.eateries].map((p) => [p.id, p]));
const nPairs = Object.keys(RP).length;
ok(nPairs >= 80 && Object.values(RP).every((r) => r.walk || r.transit || r.drive), `${nPairs}쌍이 들어 있고 모두 걷기·대중교통·자동차 값 중 하나가 있음`);
ok(Object.values(RP).every((r) => [r.walk, r.walkAccessible, r.transit, r.drive].filter(Boolean).every((x) => x.path.length >= 2 && x.path.length <= 40 && x.sec > 0 && x.m > 0)), '모든 길의 점이 2~40개, 시간·거리 양수');
ok(ROUTES.maps.length === 4 && ROUTES.maps.every((m) => fs.existsSync(require('path').join(__dirname, m.src))), '정적 지도 그림 4장(마지막은 망상·삼화까지 넓게)이 파일로 있음');
const lg = P.leg(PT.mukho, PT.mukhoport, false, RP);
ok(lg.real && lg.mode === 'walk' && lg.min === Math.ceil(RP['mukho|mukhoport'].walk.sec / 60) && /실제 길/.test(lg.text), '실제 길이 있으면 그 시간을 씀: ' + lg.text);
const lgR = P.leg(PT.mukhoport, PT.mukho, false, RP);
ok(lgR.min === lg.min && JSON.stringify(lgR.path) === JSON.stringify(lg.path.slice().reverse()), '반대 방향은 같은 시간 · 점 순서만 뒤집힘');
const old = P.leg(PT.mukho, PT.mukhoport, false);
ok(!old.real && /어림/.test(old.text) && old.min === Math.ceil(P.hav(PT.mukho, PT.mukhoport) * 1.3 / 4 * 60), '길 값을 안 주면 예전 어림(직선 x1.3, 4km/h): ' + old.text);
ok(P.leg(PT.mukho, PT.mukhoport, false, {}).min === old.min && P.leg(PT.mukho, PT.mukhoport, false, { 'x|y': {} }).real === false, '길이 없는 쌍은 예전 어림으로 fallback');
// 부모님/무릎 = ACCESSIBLE 길 x 4/3 (지어낸 값으로 확인)
const fakeR = { 'mukho|mukhoport': { walk: { sec: 360, m: 400, path: [[1, 1], [2, 2]] }, walkAccessible: { sec: 600, m: 500, path: [[1, 1], [1.5, 1.2], [2, 2]] } } };
const fa = P.leg(PT.mukho, PT.mukhoport, true, fakeR), fn = P.leg(PT.mukho, PT.mukhoport, false, fakeR);
ok(fn.min === 6 && fa.min === Math.ceil(600 / 60 * 4 / 3) && fa.path.length === 3, `부모님(느리게)은 ACCESSIBLE 10분 x 4/3 = ${fa.min}분, 보통은 walk 6분`);
// 걷기 20분 넘으면: 대중교통이 택시 어림보다 짧을 때만 버스, 아니면 택시
const fakeT = { 'mukho|eodal': { walk: { sec: 2000, m: 2200, path: [[1, 1], [2, 2]] }, transit: { sec: 540, m: 2300, transfers: 0, fare: 1530, summary: '버스 21-4번 · 환승 0회', walkSec: 0, path: [[1, 1], [2, 2]] } } };
const bus = P.leg(PT.mukho, PT.eodal, false, fakeT);
ok(bus.mode === 'bus' && bus.min === 9 && bus.text === '버스 21-4번 9분 · 환승 0회' && bus.transfers === 0, '걷기 34분 > 20분 → 더 짧은 버스: ' + bus.text);
const slowT = { 'mukho|eodal': { walk: fakeT['mukho|eodal'].walk, transit: { ...fakeT['mukho|eodal'].transit, sec: 3600 } } };
const tx = P.leg(PT.mukho, PT.eodal, false, slowT);
ok(tx.mode === 'taxi' && /택시 약 \d+분\(어림\)/.test(tx.text), '버스가 택시보다 길면 택시 어림: ' + tx.text);
// 추암(먼 곳): 실제 자료에서는 버스가 택시보다 훨씬 오래 걸려 택시. 버스가 짧은 자료를 주면 버스를 고른다
const chReal = P.leg(PT.mukho, PT.chuam, false, RP);
ok(chReal.mode === 'taxi' && RP['mukho|chuam'].transit.sec / 60 > chReal.min, `추암: 실제 버스 ${Math.round(RP['mukho|chuam'].transit.sec / 60)}분 > 택시 어림 ${chReal.min}분 → 택시`);
const chFast = P.leg(PT.mukho, PT.chuam, false, { 'mukho|chuam': { transit: { sec: 900, m: 9000, transfers: 1, fare: 1530, summary: '버스 21-4→161번 · 환승 1회', walkSec: 0, path: [[1, 1], [2, 2]] } } });
ok(chFast.mode === 'bus' && chFast.min === 15 && chFast.path.length === 2, '추암: 버스가 택시 어림보다 짧은 자료면 버스(먼 곳도): ' + chFast.text);
// 모든 쌍에서 선택이 규칙과 맞는지
let ruleBad = 0, buses = 0;
for (const k of Object.keys(RP)) {
  const [x, y] = k.split('|'); const r = RP[k];
  for (const slow of [false, true]) {
    const l = P.leg(PT[x], PT[y], slow, RP);
    const wm = r.walk ? Math.ceil((slow ? (r.walkAccessible || r.walk) : r.walk).sec / 60 * (slow ? 4 / 3 : 1)) : null;
    const tax = r.drive ? Math.ceil(5 + r.drive.sec / 60) : Math.ceil(6 + P.hav(PT[x], PT[y]) * 1.3 / 45 * 60);
    const canWalk = wm !== null && wm <= (slow ? 15 : 30);
    if (l.mode === 'walk' && !canWalk) ruleBad++;
    if (l.mode === 'bus') { buses++; if (canWalk || !(r.transit && Math.ceil(r.transit.sec / 60) < tax)) ruleBad++; }
    if (l.mode === 'taxi' && (canWalk || (r.transit && Math.ceil(r.transit.sec / 60) < tax))) ruleBad++;
  }
}
ok(ruleBad === 0, `${nPairs}쌍 x 2(보통·느리게) 선택이 규칙과 맞음 (버스 ${buses}건)`);
// 코스 계산에 반영
const plR = P.plan(D, { ...base, slow: false, avoidStairs: false, routes: RP }), plO = P.plan(D, { ...base, slow: false, avoidStairs: false, routes: false });
ok(plR.stops.every((st) => st.moveText) && plR.stops.some((st) => st.real && st.path && st.path.length >= 2) && plR.back.text, '코스의 각 장에 이동 글(moveText)·실제 길 점이 들어감: ' + plR.stops.map((st) => st.moveText).join(' / '));
ok(plO.stops.every((st) => !st.real && /어림/.test(st.moveText)), 'o.routes=false 면 예전 어림만');
const plParent = P.plan(D, { ...base, routes: RP });
ok(plParent.stops.every((st) => !st.place.stairs) && plParent.stops.every((st) => st.mode !== 'walk' || st.legMin <= 15), '부모님 코스: 걷는 구간은 (ACCESSIBLE x 4/3) 15분 이내만');
const ng = P.plan(D, { ...base, mode: 'night', routes: RP });
ok(ng.tomorrow && ng.tomorrow.moveText && ng.tomorrow.arrive < ng.tomorrow.sunrise, '1박: 내일 추암 이동 글 + 일출 전 도착: ' + ng.tomorrow.moveText);
// 도착 보장(기차 15분 전)은 실제 길로도 항상
let nR = 0, badR = 0;
for (const train of ['15:10', '16:40', '18:10', '19:40']) for (const now of [660, 780, 840, 900]) for (const slow of [true, false]) for (const rain of [true, false]) for (const end of ['mukho', 'donghae']) for (const mode of ['normal', 'late']) {
  const pl = P.plan(D, { ...base, train: T(train), now, slow, avoidStairs: slow, rain, end, mode, routes: RP });
  nR++;
  if (pl.feasible && pl.back.arrive > T(train) - 15) badR++;
  let t = now; pl.stops.forEach((st) => { if (st.arrive < t || st.leave <= st.arrive || (!st.moveText && !st.place.slot)) badR++; t = st.leave; });
}
ok(badR === 0, `실제 길로 ${nR}가지 조합에서 기차 15분 전 도착·시간순 위반 ${badR}건`);


console.log('[14] 추가한 14곳 (2026-10-17) — 자료 · 권역 · 사진 없음 · 그림');
const NEWIDS = ['suibyeon', 'jeonmangdae', 'daejin', 'nobong', 'mangsang', 'chuambeach', 'chuamsculpt', 'bukpyeong', 'hanseom', 'cheongokpark', 'gamchusa', 'yongchu', 'byeoryu', 'samhwasa'];
const NP = Object.fromEntries(NEWIDS.map((id) => [id, D.places.find((p) => p.id === id)]));
const newP = NEWIDS.map((id) => NP[id]);
ok(newP.every(Boolean) && D.places.length === 22, '장소 8곳 + 14곳 = ' + D.places.length + '곳');
ok(newP.every((p) => p.contentid && p.tourapi && p.출처 === '한국관광공사 관광정보' && p.원문.length > 40 && p.좌표확인필요 === false && p.addr && /동해시/.test(p.addr)), '14곳 모두 관광공사 contentid · 출처 · 개요 원문 · 실제 좌표 · 주소');
ok(newP.every((p) => !!p.photo === !!p.photoType) && newP.filter((p) => p.photo).length >= 10, '새 14곳: 사진은 공공누리 유형이 있는 곳에만(' + newP.filter((p) => p.photo).length + '곳), 나머지는 그림');
const REG = { 묵호: ['suibyeon', 'jeonmangdae'], '망상·대진': ['daejin', 'nobong', 'mangsang'], '추암·북평': ['chuambeach', 'chuamsculpt', 'bukpyeong'], 천곡: ['hanseom', 'cheongokpark', 'gamchusa'], 삼화: ['yongchu', 'byeoryu', 'samhwasa'] };
ok(Object.keys(REG).every((r) => REG[r].every((id) => NP[id].region === r)) && D.places.every((p) => p.region) && D.places.find((p) => p.id === 'chuam').region === '추암·북평' && D.places.find((p) => p.id === 'cheongok').region === '천곡', '권역 5개(묵호 · 망상·대진 · 추암·북평 · 천곡 · 삼화) 표시: ' + D.places.map((p) => p.short + ':' + p.region).join(' '));
ok(['daejin', 'nobong', 'mangsang', 'hanseom', 'chuambeach'].every((id) => NP[id].visit >= 30 && NP[id].visit <= 40) && NP.yongchu.visit >= 90 && NP.yongchu.visit <= 120 && NP.byeoryu.visit >= 60 && NP.byeoryu.visit <= 90 && NP.bukpyeong.visit >= 40 && NP.bukpyeong.visit <= 60 && NP.chuamsculpt.visit >= 20 && NP.chuamsculpt.visit <= 30, '머무는 시간: 해변 30~40 · 용추폭포 90~120(매표소 왕복) · 별유천지 60~90 · 북평장 40~60 · 조각공원 20~30');
ok(!NP.cheongokpark.indoor && !NP.gamchusa.indoor && NP.gamchusa.stairs === true && !NP.yongchu.indoor && NP.yongchu.slope && NP.yongchu.trail && !NP.byeoryu.indoor && !NP.hanseom.indoor, '천곡공원 야외 · 감추사 야외+계단 · 용추폭포 야외+오르막·걷는 길 · 별유천지 야외');
ok(newP.filter((p) => p.확인필요).map((p) => p.id).sort().join() === 'bukpyeong,jeonmangdae', '운영시간이 자료에 없어 대략값(확인필요)인 곳은 북평장·묵호항전망대 둘뿐');
ok(NP.byeoryu.open[0] === 570 && NP.byeoryu.open[1] === 1050 && NP.yongchu.open[1] === 1080 && NP.byeoryu.closedDow.join() === '1' && /월요일/.test(NP.byeoryu.restText), '운영시간·쉬는 날은 자료에서: 별유천지 09:30~17:30 · 월요일 휴관 / 용추폭포 09:00~18:00');
ok(D.places.find((p) => p.id === 'skyvalley').closedDow.join() === '1', '스카이밸리도 자료의 쉬는 날(월요일)을 따름');
ok(NP.bukpyeong.dayRule.lastDigit.join() === '3,8' && NP.bukpyeong.tourapi.type === 38, '북평장: 관광공사 38(쇼핑) 분류 · 끝자리 3·8일 규칙');
const hadWin = 'window' in globalThis; globalThis.window = globalThis; require('./art.js'); const ART = globalThis.TourArt; if (!hadWin) delete globalThis.window;
ok(D.places.every((p) => ART.has(p.id) && ART.svg(p.id).indexOf('<svg') === 0) && new Set(newP.map((p) => ART.svg(p.id).replace(/tad+_/g, ''))).size === 14, '22곳 모두 그림이 있고(새 14곳은 서로 다른 그림)');

console.log('[15] 장날 규칙 (북평민속오일장은 끝자리 3·8일만)');
const dayO = { ...base, now: T('10:00'), train: T('19:40'), slow: false, avoidStairs: false, soft: false };
const pd = (d) => '2026-10-' + String(d).padStart(2, '0');
let mIn = 0, mOut = 0, nIn = 0, nOut = 0;
for (let d = 1; d <= 31; d++) { const has = ids(P.plan(D, { ...dayO, date: pd(d) })).includes('bukpyeong'); if (d % 10 === 3 || d % 10 === 8) { has ? mIn++ : mOut++; } else { has ? nIn++ : nOut++; } }
ok(mIn === 6 && mOut === 0, '10월 장날(3·8·13·18·23·28일) 6일 모두 북평장이 코스에 들어감');
ok(nIn === 0 && nOut === 25, '장날이 아닌 25일은 한 번도 안 들어감');
ok(!ids(P.plan(D, dayO)).includes('bukpyeong') && P.plan(D, dayO).skipped.some((x) => x.id === 'bukpyeong'), '날짜를 모르면 장날 전용 곳은 뺌');
ok(P.nextMarketDay('2026-10-19') === '2026-10-23' && P.nextMarketDay('2026-10-18') === '2026-10-18' && P.nextMarketDay('2026-10-29') === '2026-11-03' && P.nextMarketDay('2026-12-29') === '2027-01-03' && P.nextMarketDay('아무말') === null, '다음 장날 계산(월·해 넘김 포함)');
ok(P.dateLabel('2026-10-18') === '10월 18일(일)' && P.dateInfo('2026-02-30') === null, '날짜 이름 · 없는 날짜는 거부');
const monP = P.plan(D, { ...dayO, date: '2026-10-19' }), tueP = P.plan(D, { ...dayO, date: '2026-10-20' });
ok(!ids(monP).includes('byeoryu') && !ids(monP).includes('skyvalley') && monP.skipped.filter((x) => x.why === '쉬는 요일').length === 2, '월요일(10/19)은 별유천지·스카이밸리가 쉬어서 뺌');
ok(!tueP.skipped.some((x) => x.why === '쉬는 요일'), '화요일은 쉬는 요일 때문에 빠지는 곳이 없음');
const AIp = AI.aiParseRequest;
ok(AIp('내일 6시 10분 기차', 780, '2026-10-17').date === '2026-10-18' && AIp('모레 가요', 780, '2026-10-17').date === '2026-10-19' && AIp('오늘 6시 기차', 780, '2026-10-17').date === '2026-10-17', '말 읽기: 오늘·내일·모레');
ok(AIp('23일에 가요 7시 기차', 780, '2026-10-17').date === '2026-10-23' && AIp('10월 28일 19:40', 780, '2026-10-17').date === '2026-10-28' && AIp('13일 7시 기차', 780, '2026-10-17').date === '2026-11-13', '말 읽기: "23일" · "10월 28일" · 지난 날짜는 다음 달');
ok(AIp('1박 2일 6시 기차', 780, '2026-10-17').date === null && AIp('3일간 쉬어요', 780, '2026-10-17').date === null && AIp('6시 10분 기차', 780, '2026-10-17').date === null && AIp('내일', 780).date === null, '말 읽기: "1박 2일"·"3일간"·날짜 없음·오늘 모름 → 날짜 없음');
ok(AI.aiClassifyReport('북평장 붐벼요', null, '').placeId === 'bukpyeong' && AI.aiClassifyReport('묵호항전망대 줄 20분', null, '').placeId === 'jeonmangdae' && AI.aiClassifyReport('추암해변 줄 길어요', null, '').placeId === 'chuambeach' && AI.aiClassifyReport('추암 촛대바위 줄', null, '').placeId === 'chuam' && AI.aiClassifyReport('용추폭포 줄 20분', null, '').placeId === 'yongchu' && AI.aiClassifyReport('천곡 자연학습체험공원', 'view', '').placeId === 'cheongokpark' && AI.aiClassifyReport('천곡동굴 휴무', null, '').placeId === 'cheongok' && AI.aiClassifyReport('무릉별유천지 줄', null, '').placeId === 'byeoryu' && AI.aiClassifyReport('도째비골 줄 20분', null, '').placeId === 'skyvalley' && AI.aiClassifyReport('수변공원 줄', null, '').placeId === 'suibyeon', '제보 글에서 새 장소를 찾음(전망대·추암해변·천곡 …은 더 구체적인 쪽으로)');

console.log('[16] 걷기 기준 (보통 30분 · 부모님/무릎 15분)');
const lgN = P.leg(PT.mukho, PT.nolgol, false, RP), lgNs = P.leg(PT.mukho, PT.nolgol, true, RP);
ok(lgN.mode === 'walk' && lgN.min > 20 && lgN.min <= 30 && lgN.real, '묵호역→논골담길 ' + lgN.min + '분(20분 넘음): 보통 여행자는 걸어서 (' + lgN.text + ')');
ok(lgNs.mode === 'taxi' && lgNs.walk > 15, '같은 길을 부모님·무릎은 ' + lgNs.walk + '분 걸려서(15분 넘음) 차: ' + lgNs.text);
const mkW = (sec, secA) => ({ 'mukho|mukhoport': { walk: { sec: sec, m: 900, path: [[1, 1], [2, 2]] }, walkAccessible: { sec: secA, m: 900, path: [[1, 1], [2, 2]] } } });
ok(P.leg(PT.mukho, PT.mukhoport, false, mkW(1800, 1800)).mode === 'walk' && P.leg(PT.mukho, PT.mukhoport, false, mkW(1801, 1801)).mode === 'taxi', '보통: 걷기 30분까지 걸어서, 31분이면 차');
ok(P.leg(PT.mukho, PT.mukhoport, true, mkW(600, 660)).mode === 'walk' && P.leg(PT.mukho, PT.mukhoport, true, mkW(600, 660)).min === 15 && P.leg(PT.mukho, PT.mukhoport, true, mkW(600, 690)).mode === 'taxi', '부모님·무릎: ACCESSIBLE x 4/3 = 15분까지 걸어서(11분 x 4/3 = 15), 16분이면 차');
ok(P.WALK_MAX === 30 && P.WALK_MAX_SLOW === 15, '기준값 상수: 30분 / 15분');
const chL = P.leg(PT.chuam, PT.chuambeach, false, RP);
ok(chL.mode === 'walk' && chL.min <= 3, '붙어 있는 추암 촛대바위→추암해변 ' + chL.min + '분은 먼 권역이어도 걸어서');

console.log('[17] 카카오 길찾기 — 새 점 · 택시(자동차) 시간');
const nDrive = Object.values(RP).filter((r) => r.drive).length, nTr = Object.values(RP).filter((r) => r.transit).length;
ok(nDrive >= 150 && nTr >= 150 && Object.keys(RP).length >= 250, '길 ' + Object.keys(RP).length + '쌍 · 자동차 ' + nDrive + ' · 대중교통 ' + nTr);
ok(['byeoryu', 'samhwasa', 'yongchu', 'mangsang', 'bukpyeong', 'chuam', 'chuambeach'].every((id) => { const r = RP['mukho|' + id]; return r && r.drive && r.transit; }), '묵호역→삼화·망상·북평·추암 모두 자동차·대중교통 값이 있음');
const txB = P.leg(PT.mukho, PT.byeoryu, false, RP);
ok(txB.mode === 'taxi' && txB.real && /실제 길/.test(txB.text) && txB.min === Math.ceil(5 + RP['mukho|byeoryu'].drive.sec / 60) && txB.path && txB.path.length >= 2, '택시 = 카카오 자동차 길찾기 시간 + 호출 5분, 길 선도 있음: ' + txB.text);
ok(P.leg(PT.byeoryu, PT.mukho, false, RP).min === txB.min, '반대 방향도 같은 시간');
ok(P.leg(PT.mukho, PT.yongchu, false, RP).real && RP['mukho|yongchu'].drive, '용추폭포(걷는 길 끝)는 입구(삼화사 앞)까지 길찾기');

console.log('[18] 비 오는 날 — 해변·계곡 빼고 실내 우선');
const BAD = ['daejin', 'nobong', 'mangsang', 'hanseom', 'chuambeach', 'eodal', 'yongchu', 'byeoryu'];
const rainDay = P.plan(D, { ...dayO, date: pd(18), rain: true });
ok(!ids(rainDay).some((id) => BAD.includes(id)) && BAD.every((id) => rainDay.skipped.some((x) => x.id === id)), '해변 6곳 · 용추폭포 · 별유천지는 비 오면 후보에서 빠짐: ' + ids(rainDay).join('>'));
ok(rainDay.stops[0].place.indoor && ids(rainDay).includes('cheongok'), '비 오는 하루: 첫 장이 실내이고 천곡황금박쥐동굴이 들어감');
const rainShort = P.plan(D, { ...base, rain: true });
ok(rainShort.stops[0].id === 'cheongok' || rainShort.stops[0].place.indoor, '13시 비: 첫 장이 실내: ' + ids(rainShort).join('>'));

console.log('[19] #demo-day — 하루 꽉 채운 예시 (10:00 출발 · 19:40 기차 · 친구 · 장날)');
const ddate = P.nextMarketDay('2026-10-17');
const dd = P.plan(D, { ...dayO, date: ddate });
const farStops = dd.stops.filter((s) => s.kind !== 'meal' && s.place.region !== '묵호' && s.place.region !== '천곡');
ok(ddate === '2026-10-18' && ids(dd).includes('bukpyeong') && farStops.length >= 2, '장날(' + ddate + ')에 먼 권역까지: ' + dd.stops.map((s) => P.fmt(s.arrive) + ' ' + (s.place.short || s.place.name) + (s.place.region ? '[' + s.place.region + ']' : '') + '(' + s.moveText + ')').join(' > '));
ok(new Set(dd.stops.map((s) => s.place.region).filter(Boolean)).size >= 3, '권역 ' + new Set(dd.stops.map((s) => s.place.region).filter(Boolean)).size + '곳을 지남');
const ddNon = dd.stops.filter((s) => s.kind !== 'meal');
ok(ddNon.length >= 4 && ddNon.length <= 6 && meals(dd).length === 1, '볼거리 ' + ddNon.length + '장(4~6장) + 한 끼 1장');
ok(meals(dd)[0].startVisit >= 660 && meals(dd)[0].startVisit <= 810, '하루가 길면 한 끼는 점심 때: ' + P.fmt(meals(dd)[0].startVisit));
ok(dd.back.arrive <= T('19:40') - 15, '19:40 기차 15분 전 도착: ' + P.fmt(dd.back.arrive));
ok(P.plan(D, { ...dayO, date: pd(17) }).stops.some((s) => s.place.region === '삼화'), '장날이 아닌 날(10/17)에도 삼화까지 감(북평장만 빠짐): ' + ids(P.plan(D, { ...dayO, date: pd(17) })).join('>'));
const shortP = P.plan(D, { ...base, slow: false, avoidStairs: false, date: pd(18) });
ok(shortP.stops.every((s) => !['망상·대진', '추암·북평', '삼화'].includes(s.place.region)) && shortP.skipped.some((x) => x.id === 'byeoryu' && /먼 곳/.test(x.why)), '13시~18:10(시간이 짧음)에는 먼 권역(망상·추암·북평·삼화)을 안 넣음');
const nearPar = P.plan(D, base);
ok(nearPar.stops.every((s) => ['묵호', '천곡'].includes(s.place.region) || s.kind === 'meal') && !ids(nearPar).includes('yongchu'), '#demo(부모님 13시)는 묵호 둘레: ' + ids(nearPar).join('>'));
ok(P.plan(D, { ...dayO, date: pd(18), slow: true, avoidStairs: true, soft: true }).skipped.some((x) => x.id === 'yongchu' && /걷는 길/.test(x.why)) && P.plan(D, { ...dayO, date: pd(18), slow: true, avoidStairs: true }).skipped.some((x) => x.id === 'gamchusa'), '부모님·무릎은 용추폭포(긴 걷는 길)·감추사(계단)를 뺌');
const gp = P.plan(D, { ...dayO, date: pd(18) });
ok(gp.stops.filter((s) => s.place.group === 'mangsang').length <= 2 && gp.stops.filter((s) => s.place.group === 'chuam').length <= 2, '붙어 있는 곳(해변 셋·추암 셋)을 다 돌지 않음');

console.log('[20] 도착 보장 · 운영시간 · 조건 — 새 장소까지 포함한 훑기');
let nS = 0, badS = 0, badWhy = [];
for (const train of ['15:10', '18:10', '19:40']) for (const now of [600, 780, 900]) for (const slow of [true, false]) for (const rain of [true, false]) for (const date of [pd(17), pd(18), pd(19)]) for (const mode of ['normal', 'late']) {
  const tr = mode === 'late' ? T(D.trains.last.mukho) : T(train);
  const pl = P.plan(D, { ...base, train: tr, now, slow, avoidStairs: slow, rain, date, mode });
  nS++;
  const fail = (m) => { badS++; if (badWhy.length < 5) badWhy.push(m + ' ' + JSON.stringify({ train, now, slow, rain, date, mode })); };
  if (pl.feasible && pl.back.arrive > tr - 15) fail('도착');
  let t = now;
  pl.stops.forEach((s) => {
    if (s.arrive < t || s.leave <= s.arrive) fail('시간순');
    if (s.startVisit < s.place.open[0] || s.leave > s.place.open[1]) fail('운영시간 ' + s.id);
    if (s.place.dayRule && !P.lastDigitDay(date, s.place.dayRule.lastDigit)) fail('장날 아님');
    if (s.place.closedDow && s.place.closedDow.includes(P.dateInfo(date).dow)) fail('쉬는 요일 ' + s.id);
    if (rain && s.place.rainAvoid) fail('비 ' + s.id);
    if (slow && (s.place.stairs || s.place.trail)) fail('계단/긴 길 ' + s.id);
    t = s.leave;
  });
  if (pl.stops.filter((s) => s.kind !== 'meal').length > (mode === 'late' ? 7 : 6) || meals(pl).length > 1) fail('곳 수');
}
ok(badS === 0, nS + '가지 조합(새 장소·날짜·비·막차 포함): 위반 ' + badS + '건 ' + badWhy.join(' / '));

console.log('[21] 제보 단추 "다음 장소 줄 20분" — 겨냥한 장 때문에 코스가 늘 바뀜');
const stepRep = (o, doneIdx) => {
  let cur = o, pl0 = P.plan(D, o);
  if (doneIdx >= 0) { cur = { ...o, now: pl0.stops[doneIdx].arrive, fixed: pl0.stops.slice(0, doneIdx + 1) }; pl0 = P.plan(D, cur); }
  const tg = P.reportTarget(pl0.stops, doneIdx);
  if (!tg) return { tg: null };
  const simTs = Math.max(cur.now, tg.stop.arrive - 20); // 앱이 보내는 제보 시각(현장 도착 20분 전)
  const fx = P.effectsFromReports([{ type: 'crowd', placeId: tg.stop.id, minutes: 20, simTs }], cur.now, true);
  const after = P.plan(D, { ...cur, fx });
  return { tg, before: pl0, after, changed: ids(pl0).join() !== ids(after).join(), delayed: (after.stops.find((s) => s.id === tg.stop.id) || {}).delay > 0 };
};
const SC = [['#demo 처음', base, -1], ['#demo 1장 도착', base, 0], ['#demo 2장 도착', base, 1], ['일반 처음', { ...base, slow: false, avoidStairs: false }, -1], ['#demo-day 처음', { ...dayO, date: pd(18) }, -1], ['#demo-day 2장 도착', { ...dayO, date: pd(18) }, 1]];
SC.forEach(([nm, o, di]) => {
  const r = stepRep(o, di);
  ok(r.tg && r.tg.index >= di + 2 && r.tg.index === (di < 0 ? 2 : di + 2) && r.tg.stop.kind !== 'meal' && r.changed && r.after.back.arrive <= o.train - 15, nm + ': ' + (r.tg ? (r.tg.index + 1) + '장 ' + r.tg.stop.id + ' 줄 20분 → ' + ids(r.before).join('>') + '  →  ' + ids(r.after).join('>') : '대상 없음'));
});
ok(P.reportTarget([{ id: 'a' }, { id: 'b' }], -1) === null && P.reportTarget([{ id: 'a' }, { id: 'b' }, { id: 'c', kind: 'meal' }], -1) === null && P.reportTarget([{ id: 'a' }, { id: 'b' }, { id: 'c', kind: 'meal' }, { id: 'd' }], -1).stop.id === 'd', '대상: 3번째 장부터(한 끼 장은 건너뜀), 코스가 짧으면 없음');

console.log('[22] 사진 공공누리 규칙 (2026-10-17) — 제3유형은 자르지 않고 그대로, 사진 위에 아무것도 얹지 않음');
{
  const css = fs.readFileSync(require('path').join(__dirname, 'style.css'), 'utf8'), js = fs.readFileSync(require('path').join(__dirname, 'app.js'), 'utf8');
  const all = [...D.places, ...D.eateries], withPh = all.filter((p) => p.photo);
  ok(withPh.length >= 15 && withPh.every((p) => p.photoType === 'Type1' || p.photoType === 'Type3'), '사진이 있는 곳 ' + withPh.length + '곳 (제1유형 ' + withPh.filter((p) => p.photoType === 'Type1').length + ' · 제3유형 ' + withPh.filter((p) => p.photoType === 'Type3').length + ')');
  const noLic = all.filter((p) => p.contentid && !p.photo);
  ok(noLic.every((p) => !p.photoType), '유형이 없거나 다른 유형인 곳은 사진이 없음(그림): ' + noLic.map((p) => p.id).join(', '));
  ok(/img\.ph\.t3[^{]*\{[^}]*object-fit:\s*contain/.test(css) && !/img\.ph\.t3[^{]*\{[^}]*(cover|filter:\s*(?!none)[a-z])/.test(css), 'CSS: 제3유형 사진은 object-fit:contain · 필터 없음');
  ok(/\.sv-art\.t3\.ph-ok::after\s*\{\s*display:\s*none/.test(css), '이야기 보기: 제3유형 사진 위 그라데이션 없음');
  ok(/function artFig/.test(js) && /p-credit/.test(js) && /공공누리 제/.test(js) && /\.art-tag/.test(js) && /tag\.hidden = true/.test(js), '앱: 사진 불러오면 사진 위 배지를 숨기고 사진 밖 줄에 출처 표시');
  ok(!/drawMealSlot|rc-meal/.test(js) && !/rc-meal/.test(css), '기록 카드·저장 그림에는 식당 칸이 없음(코스에 식당이 없어서)');
  ok(withPh.every((p) => /^사진캐시\//.test(p.photo)) && !/https?:\/\/tong\.visitkorea/.test(JSON.stringify(D)), '데이터에 바깥 사진 주소가 없음(사진캐시/ 만)');
}

console.log('[23] 편의 시설 (화장실·관광안내소·숙박·식당, 2026-10-17) — 거르기·가장 가까운 곳·글');
{
  const FU = require('./fac.js'), FAC = require('./facilities.js'), path = require('path');
  const js = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8'), css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8'), html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
  const pts = [...Object.values(D.stations), ...D.places, ...D.eateries];
  // 거리 계산
  const m1 = D.stations.mukho, m2 = D.stations.donghae, dd = FU.dist(m1.lat, m1.lng, m2.lat, m2.lng);
  ok(dd > 5000 && dd < 6000 && FU.dist(m1.lat, m1.lng, m1.lat, m1.lng) === 0, `묵호역-동해역 직선 ${Math.round(dd)}m (5~6km)`);
  // 가장 가까운 곳·거르기 (작은 예)
  const toy = [{ id: 'a', lat: 37.5500, lng: 129.1100 }, { id: 'b', lat: 37.5510, lng: 129.1100 }, { id: 'c', lat: 37.5600, lng: 129.1100 }];
  const nb = FU.nearest(toy, 37.5509, 129.1100, 300);
  ok(nb && nb.item.id === 'b' && nb.m < 20, '가장 가까운 것 = b (' + Math.round(nb.m) + 'm)');
  ok(FU.nearest(toy, 37.5700, 129.1100, 300) === null && FU.nearest([], 37.55, 129.11, 300) === null, '300m 안에 없으면 null, 빈 목록도 null');
  ok(FU.nearestN(toy, 37.5509, 129.1100, 2, null).map((x) => x.item.id).join() === 'b,a', '가까운 순 2개 = b,a');
  ok(FU.filterNear(toy, [{ lat: 37.5505, lng: 129.1100 }], 100).map((x) => x.id).join() === 'a,b' && FU.filterNear(toy, [{ lat: 37.5505, lng: 129.1100 }], 10).length === 0, '코스 점 100m 안 거르기 = a,b · 10m = 없음');
  ok(FU.round10(114) === 110 && FU.round10(116) === 120 && FU.round10(3) === 10, '거리는 10m 단위 어림');
  // 글: 자료에 있는 것만
  const t0 = { name: '시험화장실', h24: true, hours: '00:00~24:00', acc: true, diaper: '', bell: '' };
  const t1 = { name: '시험화장실', h24: true, hours: '00:00~24:00', acc: true, diaper: '여자화장실', bell: 'Y' };
  const t2 = { name: '해변', h24: false, hours: '00:00~24:00(해수욕장개장기간만 개방)', acc: false, diaper: '', bell: '' };
  ok(FU.wcLine({ item: t0, m: 123 }) === '가까운 화장실 시험화장실 120m (24시간 · 장애인 화장실)', '자료가 비면 기저귀·비상벨은 적지 않음: ' + FU.wcLine({ item: t0, m: 123 }));
  ok(FU.wcLine({ item: t1, m: 123 }) === '가까운 화장실 시험화장실 120m (24시간 · 장애인 화장실 · 기저귀 교환대 · 비상벨)', '자료에 있으면 기저귀 교환대·비상벨도 적음');
  ok(/해수욕장개장기간만/.test(FU.wcLine({ item: t2, m: 50 })) && FU.wcLine(null) === '', '개장기간만 여는 곳은 그 조건을 그대로 적음 · 없으면 빈 글');
  // 만들어진 자료
  ok(FAC.toilets.length >= 20 && FAC.toilets.every((t) => t.name && t.lat > 37 && t.lat < 38 && t.lng > 128.5 && t.lng < 129.5), `화장실 ${FAC.toilets.length}곳, 모두 동해 안 좌표·이름 있음`);
  ok(FAC.toilets.every((t) => pts.some((p) => FU.dist(p.lat, p.lng, t.lat, t.lng) <= FAC.radius)), `화장실은 모두 코스 점 ${FAC.radius}m 안`);
  ok(FAC.infos.length >= 3 && FAC.infos.every((t) => /^\d\d:\d\d~\d\d:\d\d$|^하절기/.test(t.hours) && t.lat > 37 && pts.some((p) => FU.dist(p.lat, p.lng, t.lat, t.lng) <= FAC.radius)), `관광안내소 ${FAC.infos.length}곳(${FAC.infos.map((i) => i.name).join(', ')}) — 시간이 정상이고 코스 둘레`);
  ok(/1500|1.5/.test(String(FAC.radius)) && /2020-03-19/.test(FAC.source.toilet) && /기준일/.test(FAC.source.toilet) && /기준일/.test(FAC.source.info), '출처 글에 자료 이름·기준일(화장실 2020-03-19) 있음');
  // 게시물 줄
  const hit = (id) => FU.nearest(FAC.toilets, D.places.find((p) => p.id === id).lat, D.places.find((p) => p.id === id).lng, 300);
  const withWc = D.places.filter((p) => FU.nearest(FAC.toilets, p.lat, p.lng, 300)).length;
  ok(withWc >= 5 && withWc < D.places.length, `300m 안 화장실이 있는 장소 ${withWc}/${D.places.length} (없는 곳은 줄을 안 그림)`);
  const mp = hit('mukhoport');
  ok(mp && FU.wcLine(mp).startsWith('가까운 화장실 ') && /\d+m \(24시간/.test(FU.wcLine(mp)), '묵호항: ' + FU.wcLine(mp));
  ok(!JSON.stringify(FAC).includes('기저귀 교환대') && FAC.toilets.every((t) => !t.diaper && !t.bell), '자료가 비어 있는 기저귀 교환대·비상벨을 있다고 적지 않음');
  // 숙박·식당
  ok(FAC.lodging.length >= 3 && FAC.lodging.every((l) => FU.dist(m1.lat, m1.lng, l.lat, l.lng) <= 3000), `숙박 ${FAC.lodging.length}곳(묵호역 3km 안만 보관)`);
  const l3 = FU.nearestN(FAC.lodging, m1.lat, m1.lng, 3, null), in1 = FU.nearestN(FAC.lodging, m1.lat, m1.lng, 99, 1000);
  ok(l3.length === 3 && l3[0].m <= l3[1].m && l3[1].m <= l3[2].m && in1.every((x) => x.m <= 1000), `묵호역 가까운 숙박 3곳 ${l3.map((x) => x.item.name + ' ' + Math.round(x.m) + 'm').join(' · ')} (1km 안 ${in1.length}곳)`);
  ok(FAC.eats.length >= 10 && FAC.eats.every((e) => e.name && e.kind && !e.rating && !e.menu && D.eateries.some((q) => FU.dist(q.lat, q.lng, e.lat, e.lng) <= 700)) && !FAC.eats.some((e) => D.eateries.some((q) => q.name === e.name)), `다른 식당 ${FAC.eats.length}곳(이름·업태·주소만, 한 끼 4곳 700m 안, 한 끼 가게와 겹치지 않음)`);
  // 키·코드
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', '설정', '공공데이터.json'), 'utf8'));
  const fjs = fs.readFileSync(path.join(__dirname, 'facilities.js'), 'utf8');
  ok(Object.entries(cfg).every(([k, v]) => !(/key|token/i.test(k) && typeof v === 'string' && v.length >= 8 && fjs.includes(v))), 'facilities.js 안에 키 값이 없음');
  ok(/id="facWc"/.test(html) && /id="facInfo"/.test(html) && /id="facList"/.test(html) && /facilities\.js[\s\S]*fac\.js[\s\S]*app\.js/.test(html), '지도 화면: 화장실·관광안내소 칩과 목록 자리, 스크립트 순서');
  ok(/aria-pressed="false" id="facWc"|id="facWc" aria-pressed="false"/.test(html) && /id="facInfo" aria-pressed="false"/.test(html), '관광안내소 칩은 처음에 꺼짐');
  ok(/companions\.indexOf\('부모님'\)[^;]*companions\.indexOf\('아이'\)/.test(js) && /S\.fac\.wc === null/.test(js), '부모님·아이와 함께면 화장실 표시가 기본으로 켜짐(누르면 그 값을 따름)');
  ok((js.match(/wcLineHtml\(p\)/g) || []).length === 2 && /FU\.nearest\(FAC\.toilets, p\.lat, p\.lng, 300\)/.test(js), '볼거리 게시물에 300m 안 가장 가까운 화장실 줄(끼니 시간 줄에는 없음)');
  ok(/mapApi\.set\(pts, segs, facs, pois, focus, keep\)/.test(js) && /staticMapHtml\(pts, segs, facs, false, pois, focus\)/.test(js) && /\.kfac\.wc/.test(css), '카카오 지도와 지도 그림 대체 모두 편의 시설·식당·숙소 표시');
  ok(/묵호역 1km 안 숙박업소/.test(js) && /별점·광고 없음/.test(js) && !/otherEatsHtml|근처 다른 식당/.test(js), '하룻밤 숙박 줄(출처·별점 없음 문구) · 식당 추천 블록(근처 다른 식당)은 없음');
}

console.log('[24] 새 시작 화면 (2026-10-17) — 버스·자가용·아이·연인·날씨·기차 시간표');
{
  const path = require('path'), cp = require('child_process');
  const js = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8'), html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8'), css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
  const PTS = Object.fromEntries([...Object.values(D.stations), ...D.places, ...D.eateries].map((p) => [p.id, p]));
  // 점 자료
  ok(D.stations.bus && /버스터미널/.test(D.stations.bus.name) && D.stations.bus.lat > 37.5 && D.stations.bus.lat < 37.56 && /카카오/.test(D.stations.bus.출처), '버스터미널 좌표(카카오 로컬)가 데이터에 있음: ' + D.stations.bus.name);
  ok(D.stations.park && /주차/.test(D.stations.park.name) && D.stations.park.확인필요 === true && /305면/.test(D.stations.park.메모) && /무료/.test(D.stations.park.메모), '주차장 좌표(카카오 로컬) + 305면·무료 시범은 확인필요로 표시');
  // 버스
  const bus = P.plan(D, { how: 'bus', now: T('10:00'), train: T('18:00'), date: '2026-10-18' });
  ok(bus.feasible && bus.startStation.id === 'bus' && bus.endStation.id === 'bus' && bus.stops.length >= 4, '버스: 터미널에서 출발·도착, ' + bus.stops.length + '곳 ' + ids(bus).join('>'));
  ok(bus.back.arrive <= T('18:00') - 15 && bus.deadline === T('18:00') - 15, '버스: 출발 15분 전(17:45) 안에 터미널로 돌아옴 ' + P.fmt(bus.back.arrive));
  ok(bus.stops.every((x) => x.mode === 'walk' || x.mode === 'bus' || x.mode === 'taxi'), '버스: 이동은 걷기·버스·택시');
  const busTight = P.plan(D, { how: 'bus', now: T('17:00'), train: T('17:30') });
  ok(!busTight.feasible || busTight.stops.length === 0, '버스: 돌아갈 시간이 너무 가까우면 코스 없음');
  // 자가용
  const car = P.plan(D, { how: 'car', now: T('10:00'), train: T('18:00'), date: '2026-10-18' });
  ok(car.feasible && car.startStation.id === 'park' && car.endStation.id === 'park' && car.deadline === T('18:00') && car.back.arrive <= T('18:00'), '자가용: 주차장에서 출발·정한 시각(18:00, 여유 0분) 안에 주차장으로 ' + P.fmt(car.back.arrive));
  ok(car.stops.every((x) => x.mode === 'walk' || x.mode === 'car') && car.stops.some((x) => x.mode === 'car'), '자가용: 이동은 걷기 또는 자가용(택시·버스 없음)');
  ok(car.stops.every((x) => x.mode !== 'walk' || x.legMin <= 10), '자가용: 걷는 구간은 모두 10분 이하');
  const carFar = car.stops.filter((x) => x.mode === 'car');
  ok(carFar.length > 0 && carFar.every((x) => /주차 5분 포함/.test(x.moveText)), '자가용: 차 이동 글에 주차 5분 포함 표시: ' + carFar[0].moveText);
  const carDay = P.plan(D, { how: 'car', now: T('10:00'), train: T('18:00'), date: '2026-10-18' });
  ok(carDay.stops.some((x) => x.place.region === '삼화') && carDay.stops.some((x) => x.place.region === '추암·북평'), '자가용 하루: 삼화와 추암·북평까지 갈 수 있음: ' + ids(carDay).join('>'));
  const drv = RP['park|byeoryu'] ? RP['park|byeoryu'].drive : RP['byeoryu|park'].drive;
  const lgC = P.leg(PTS.park, PTS.byeoryu, false, RP, { car: true });
  ok(lgC.mode === 'car' && lgC.real && lgC.min === Math.ceil(drv.sec / 60) + 5, '자가용 이동 시간 = 카카오 자동차 시간 + 주차 5분: ' + lgC.text);
  ok(P.leg(PTS.park, PTS.nolgol, false, RP, { car: true }).mode === 'walk', '가까운 곳(걸어서 10분 안)은 자가용도 걸어서');
  // 기차는 예전 그대로
  const trn = P.plan(D, { now: T('13:00'), train: T('18:10') });
  ok(trn.how === 'train' && trn.startStation.id === 'mukho' && trn.endStation.id === 'mukho', '기차: 예전처럼 묵호역 출발·도착');
  // 아이
  const kid = P.plan(D, { now: T('10:00'), train: T('18:10'), kid: true, avoidStairs: true, date: '2026-10-18' });
  ok(kid.stops.every((x) => x.mode !== 'walk' || x.legMin <= 20) && kid.stops.every((x) => !x.place.stairs), '아이: 걷기 20분 이하 · 계단 있는 곳(묵호등대·감추사) 없음: ' + ids(kid).join('>'));
  const kw = P.leg(PTS.mukho, PTS.nolgol, false, RP, { walkMax: 20 }), pw = P.leg(PTS.mukho, PTS.nolgol, false, RP);
  ok(kw.walk === pw.walk && (kw.walk <= 20 ? kw.mode === 'walk' : kw.mode !== 'walk') && (pw.walk <= 30 ? pw.mode === 'walk' : true), '아이 걷기 한도 20분(일반 30분): 묵호역→논골담길 걷기 ' + kw.walk + '분 → ' + kw.mode);
  const farWalk = P.leg(PTS.mukho, PTS.skyvalley, false, RP, { walkMax: 20 });
  ok(P.leg(PTS.mukho, PTS.skyvalley, false, RP).walk > 20 ? farWalk.mode !== 'walk' : true, '아이: 걷기 20분이 넘는 곳은 걷지 않고 차·버스로');
  ok(/function wcOn[\s\S]{0,200}companions\.indexOf\('아이'\)/.test(js), '아이: 화장실이 지도·게시물에 기본으로 켜짐');
  // 연인
  const cp1 = P.plan(D, { how: 'car', now: T('15:00'), train: T('21:00'), couple: true, date: '2026-10-18' });
  ok(ids(cp1).includes('nightmarket') && ['skyvalley', 'lighthouse', 'jeonmangdae'].some((id) => ids(cp1).includes(id)), '연인 저녁(15~21시): 전망(도째비골·등대·전망대)과 야시장이 함께 들어감: ' + ids(cp1).join('>'));
  // 비
  const wetCar = P.plan(D, { how: 'car', now: T('10:00'), train: T('18:00'), rain: true, date: '2026-10-18' });
  ok(wetCar.stops[0].place.indoor && wetCar.stops.every((x) => !x.place.rainAvoid), '비(날씨에서 옴): 실내 먼저 · 비 오는 날 피할 야외 곳 없음: ' + ids(wetCar).join('>'));
  ok(/w\.pty > 0/.test(js) && /S\.cond\.rain = true/.test(js) && /wxApplied/.test(js), '앱: 기상청 강수 형태가 있으면 "비" 조건을 자동으로 켬(끌 수 있음)');
  ok(/mock-weather/.test(js) && /rain:/.test(js), '시험용: ?mock-weather=rain 으로 가짜 날씨');
  // 화면 규칙
  ok(/id="wx"/.test(html) && /id="howSeg"/.test(html) && /data-how="train"/.test(html) && /data-how="bus"/.test(html) && /data-how="car"/.test(html) && /id="chipComp"/.test(html) && /id="makeCourse"/.test(html) && !/s-cond/.test(html), '새 시작 화면: 날씨 · 날짜·시각 · 이동수단 3개 · 함께 가는 사람 · 코스 단추 (옛 조건 화면은 없음)');
  ok(/COMPS = \['친구', '연인', '혼자', '아이', '부모님'\]/.test(js), '함께 가는 사람 5가지: 친구·연인·혼자·아이·부모님');
  ok(/fetch\('\/api\/weather'/.test(js) && !/apis\.data\.go\.kr/.test(js + html) && !/datagokr/.test(js + html), '날씨는 서버(/api/weather)에서만 · 브라우저 코드에 기상청 주소·키 이름 없음');
  ok(/fetch\('\/api\/trains/.test(js) && /TRAIN_SNAPSHOT/.test(js), '기차 시간표는 서버(/api/trains) · 묶음에는 시간표 사진');
  ok(/날씨를 불러오지 못했어요/.test(js), '날씨를 못 받으면 가짜 숫자 없이 안내 글');
  ok(/\.dt\{/.test(css) && /\.cta\{[^}]*min-height:\s*6\d/.test(css), 'CSS: 날짜·시각 칸 · 큰 코스 단추(64px)');
  // 서버 코드 시험(가짜 응답, 인터넷 없음)
  const r = cp.spawnSync(process.execPath, [path.join(__dirname, '..', '..', 'run', 'test-api.mjs')], { encoding: 'utf8' });
  (r.stdout || '').split('\n').forEach((ln) => { if (/^  ok /.test(ln)) { pass++; console.log(ln); } else if (/^  FAIL/.test(ln)) { fail++; console.log(ln); } });
  ok(r.status === 0, '서버 시험(run/test-api.mjs) 통과');
}

console.log('[25] 동해시티투어버스 (2026-10-17) — 운행일·다음 출발·막차·마감·1일권·#demo-tour (인터넷 안 씀)');
{
  const path = require('path');
  require('./citytour.js'); const CT = globalThis.CITYTOUR;
  const js = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8'), html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8'), css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
  // 자료
  ok(CT.stops.length === 12 && CT.stops.every((s) => s.times.length === 7 && s.lat > 37.4 && s.lat < 37.6), '정류장 12곳 · 각 7회차 칸 · 좌표 동해 안');
  ok(CT.stops[0].times[0] === '09:40' && CT.stops[11].times[0] === '11:34' && CT.endTimes[0] === '11:40' && CT.endTimes[5] === '18:00', '1회차 09:40 묵호역 출발 → 11:34 감추사 → 11:40 묵호역 도착, 6회차 18:00 도착');
  ok(CT.stops[6].times[6] === '18:43' && CT.stops.slice(7).every((s) => s.times[6] === null) && CT.endTimes[6] === null, '7회차는 천곡로터리 18:43 에서 끝남(천곡동굴 이후·묵호역 도착 없음)');
  ok(CT.fares.adult === 5000 && CT.fares.child === 3000 && CT.phone === '033-532-1945' && CT.checked === '2026-10-17' && /dcitybus\.com\/citybus\.php\?pnum=c3/.test(CT.source.timetable) && CT.period.from === '2026-02-07' && CT.period.to === '2026-12-20', '요금 5,000/3,000원 · 전화 · 출처 주소 · 확인일 · 기간');
  ok(CT.holidays.confirmed === false && /확인필요/.test(CT.holidays.source) && CT.holidays.list.some((h) => h.date === '2026-10-09'), '공휴일은 손으로 적은 목록(확인필요) — 한글날 포함: ' + CT.holidays.source);
  const linkIds = CT.stops.flatMap((s) => s.links.map((l) => [s, l])), allIds = new Set([...Object.keys(D.stations), ...D.places.map((p) => p.id)]);
  ok(linkIds.length >= 20 && linkIds.every(([s, l]) => allIds.has(l.place) && (l.m <= 400 || (l.extra && l.m <= 900)) && l.walk && l.walkAccessible), `정류장-장소 연결 ${linkIds.length}개: 400m 이내(또는 이름이 같은 몇 곳 900m 이내) · 걷기 길 모두 있음`);
  const keys = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', '설정', '공공데이터.json'), 'utf8'));
  const raw = fs.readFileSync(path.join(__dirname, 'citytour.js'), 'utf8');
  ok(![keys.kakao_rest_key, keys.datagokr_key, keys.kakao_js_key].some((k) => k && raw.includes(k)), 'citytour.js 에 키가 들어 있지 않음');
  // 운행일
  const dayOk = (d) => P.tourDay(CT, d).ok;
  ok(dayOk('2026-10-24') && dayOk('2026-10-25') && P.tourDay(CT, '2026-10-24').why === '토요일' && P.tourDay(CT, '2026-10-25').why === '일요일', '토요일·일요일은 운행');
  ok(dayOk('2026-10-09') && /한글날/.test(P.tourDay(CT, '2026-10-09').why) && dayOk('2026-10-05'), '평일 공휴일(한글날·개천절 대체)도 운행');
  ok(!dayOk('2026-10-20') && P.tourDay(CT, '2026-10-20').why === '평일', '평일(화)은 운행 안 함');
  ok(!dayOk('2026-01-31') && P.tourDay(CT, '2026-01-31').why === '아직 운행 전' && dayOk('2026-02-07') && dayOk('2026-12-20') && !dayOk('2026-12-26') && P.tourDay(CT, '2026-12-26').why === '운행 기간이 끝남', '기간 밖은 토·일이어도 안 함 (2/7·12/20 은 운행)');
  ok(!P.tourDay(CT, '').ok && !P.tourDay(CT, '엉터리').ok, '날짜를 모르면 운행 안 함');
  ok(P.tourNextDay(CT, '2026-10-20') === '2026-10-24' && P.tourNextDay(CT, '2026-10-24') === '2026-10-24' && P.tourNextDay(CT, '2026-01-01') === '2026-02-07' && P.tourNextDay(CT, '2026-12-21') === null, '다음 운행일: 화→토, 토→그날, 운행 전→2/7, 기간 끝→없음');
  // 다음 출발
  const PL = (id) => D.places.find((p) => p.id === id);
  let tl = P.tourLeg(CT, PL('eodal'), PL('mangsang'), T('10:00'), false);
  ok(tl && tl.run === 2 && tl.dep === T('10:54') && tl.arr === T('11:03') && tl.boardName === '어달해변' && tl.alightName === '망상해변', '10:00 어달해변 → 망상: 1회차(09:54)는 놓쳐서 2회차 10:54 탑승 → 11:03 하차: ' + (tl && tl.text));
  tl = P.tourLeg(CT, PL('eodal'), PL('mangsang'), T('09:50'), false);
  ok(tl && tl.run === 1 && tl.dep === T('09:54') && tl.wait === 3 && /시티투어 1회차 09:54 어달해변 탑승 → 10:03 망상해변 하차/.test(tl.text), '09:50 이면 1회차 09:54 를 탐(걷기 1분 · 기다림 3분)');
  tl = P.tourLeg(CT, PL('eodal'), PL('mangsang'), T('18:05'), false);
  ok(tl && tl.run === 7 && tl.dep === T('18:14') && tl.arr === T('18:23'), '18:05 → 막차(7회차 18:14)를 탐');
  ok(P.tourLeg(CT, PL('eodal'), PL('mangsang'), T('18:20'), false) === null, '18:20 은 막차를 놓쳐 탈 수 없음(null)');
  ok(P.tourLeg(CT, PL('eodal'), PL('cheongok'), T('17:55'), false) === null, '7회차는 천곡동굴에 안 서서 17:55 어달해변 → 천곡동굴은 탈 수 없음');
  ok(P.tourLeg(CT, PL('nolgol'), PL('suibyeon'), T('10:00'), false) === null, '같은 정류장에 붙은 곳끼리는 타지 않음');
  tl = P.tourLeg(CT, PL('chuambeach'), D.stations.mukho, T('11:00'), false);
  ok(tl && tl.run === 1 && tl.arr === T('11:40') && tl.alightName === '묵호역', '추암해변 → 묵호역은 1회차 11:20 탑승 → 11:40 묵호역 도착(묵호역은 도착 시각표를 씀): ' + (tl && tl.text));
  const fastTl = P.tourLeg(CT, PL('chuambeach'), D.stations.mukho, T('11:00'), false), slowTl = P.tourLeg(CT, PL('chuambeach'), D.stations.mukho, T('11:00'), true);
  ok(slowTl.dep === fastTl.dep && slowTl.walkA >= fastTl.walkA, '천천히 걷기(부모님)도 같은 계산 · 걷는 분은 같거나 더 김');
  // 계획: 비운행일 = 예전과 같음, 운행일 = 마감 지킴
  const baseT = { how: 'train', now: T('09:30'), train: T('19:40'), end: 'mukho', interests: [] };
  const wk = P.plan(D, { ...baseT, date: '2026-10-20', tour: true }), wk0 = P.plan(D, { ...baseT, date: '2026-10-20' });
  ok(wk.tour.enabled && !wk.tour.day.ok && wk.tour.rides === 0 && ids(wk).join() === ids(wk0).join() && wk.stops.every((x) => x.mode !== 'tour'), '평일: 시티투어 안 쓰고 코스는 예전과 같음');
  const nt = P.plan(D, { ...baseT, date: '2026-10-24' });
  ok(nt.tour.rides === 0 && !nt.tour.enabled, 'o.tour 를 안 켜면 운행일에도 예전 계산 그대로');
  let bad = 0, nTour = 0, nPlans = 0;
  const tlegs = (pl) => pl.stops.filter((x) => x.mode === 'tour' && x.tour).map((x) => x.tour).concat(pl.back && pl.back.mode === 'tour' && pl.back.tour ? [pl.back.tour] : []);
  for (const train of ['16:40', '18:10', '19:40']) for (const now of [T('09:30'), T('11:00'), T('13:00')]) for (const slow of [true, false]) for (const prefer of [true, false]) for (const end of ['mukho', 'donghae']) {
    const pl = P.plan(D, { ...baseT, train: T(train), now, slow, avoidStairs: slow, tourPrefer: prefer, end, date: '2026-10-24', tour: true }); nPlans++;
    if (pl.feasible && pl.back.arrive > T(train) - 15) bad++;
    let t = now; pl.stops.forEach((s) => { if (s.arrive < t || s.leave <= s.arrive) bad++; t = s.leave; });
    tlegs(pl).forEach((x) => { nTour++; const row = CT.stops[x.boardIdx].times, hasDep = row.includes(P.fmt(x.dep)), arrRow = x.alightIdx === 12 ? CT.endTimes : CT.stops[x.alightIdx].times; if (!hasDep || !arrRow.includes(P.fmt(x.arr)) || x.arr <= x.dep) bad++; });
  }
  ok(bad === 0 && nTour > 0, `${nPlans}가지 조합: 기차 15분 전 도착 · 시간순 · 탄 시각은 모두 시간표에 있는 출발/도착(마감·막차 지킴), 시티투어 ${nTour}구간`);
  // #demo-tour (친구, 기차, 가장 가까운 운행 토요일, 09:30 도착 · 19:40 기차)
  const t0 = Date.now();
  const dt = P.plan(D, { ...baseT, date: '2026-10-24', tour: true, tourPrefer: true });
  const farTour = new Set(dt.stops.filter((x) => x.mode === 'tour' && x.place.region !== '묵호').map((x) => x.place.region));
  ok(dt.feasible && farTour.size >= 2, '#demo-tour: 시티투어로 묵호 밖 권역 ' + farTour.size + '곳(' + [...farTour].join('·') + ') ' + ids(dt).join('>') + ' (' + (Date.now() - t0) + 'ms)');
  ok(dt.tour.used && dt.tour.rides >= 2 && dt.tour.fareText === '시티투어 1일권 5,000원(소인 3,000원)', '1일권은 탄 횟수(' + dt.tour.rides + '번)와 관계없이 한 번만 적힘: ' + dt.tour.fareText);
  ok((js.match(/pl\.tour\.fareText/g) || []).length === 1, '화면 코드도 1일권 요금 줄은 한 곳에서만 만듦');
  ok(dt.stops.filter((x) => x.mode === 'tour').every((x) => /^시티투어 \d회차 \d\d:\d\d .+ 탑승 → \d\d:\d\d .+ 하차/.test(x.moveText)), '이동 글: "시티투어 N회차 hh:mm ○○ 탑승 → hh:mm ○○ 하차" 모양');
  const carP = P.plan(D, { how: 'car', now: T('10:00'), train: T('18:00'), date: '2026-10-24', tour: true });
  ok(carP.stops.every((x) => x.mode !== 'tour') && carP.tour.rides === 0, '자가용은 시티투어 안 씀');
  // 날씨 주의
  ok(P.tourWxCaution({ pty: 1, rain1h: 18, wind: 5 }) === '악천후엔 운행이 멈출 수 있어요 — 재단 033-532-1945 확인' && P.tourWxCaution({ pty: 0, rain1h: 0, wind: 14 }) !== '' && P.tourWxCaution({ pty: 1, rain1h: 2.5, wind: 5 }) === '' && P.tourWxCaution({ pty: 0, wind: 13.9 }) === '' && P.tourWxCaution({ error: 'x' }) === '' && P.tourWxCaution(null) === '', '악천후 주의: 센 비(시간당 10mm↑)·바람 초속 14m↑ 에만, 약한 비·값 없음은 조용');
  // 화면 연결
  ok(/'demo-tour'/.test(js) && /id="runDemoTour"/.test(html) && /시티투어버스로 돌기 예시/.test(html) && /src="citytour\.js"/.test(html) && /다음 운행: /.test(js) && /토·일·공휴일만 다녀요/.test(js), '화면: #demo-tour · 시작 화면 링크 · 평일 안내(토·일·공휴일만, 다음 운행) · citytour.js 연결');
  ok(/\.kfac\.tour/.test(css) && /label: '투'/.test(js) && /#0b3d91/.test(js) && /진한 파랑 = 시티투어버스/.test(html), '지도: 시티투어 구간 진한 파랑 · 정류장 "투" 표시 · 범례');
}

console.log('[26] 올 때 / 돌아갈 때 분리 · 섞어 타기 · 가까운 기차 줄 · 1박 2일·2박 3일 (2026-10-17)');
{
  const path = require('path');
  const js = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8'), html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8'), css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
  const CT = globalThis.CITYTOUR;
  // 가까운 기차 (고르는 목록이 아니라 작은 도움 줄)
  const tl = [{ dep: '06:10' }, { dep: '15:48', grade: 'KTX-이음' }, { dep: '18:52', grade: 'KTX-이음' }];
  ok(P.nearestDeparture(tl, T('18:00')).dep === '18:52' && P.nearestDeparture(tl, T('15:48')).dep === '15:48' && P.nearestDeparture(tl, T('19:00')) === null, '가까운 기차: 고른 시각 이후 첫 기차(같은 때 포함), 마지막 뒤에는 없음');
  let early = 0; for (let m = 0; m < 1440; m += 7) { const h = P.nearestDeparture(tl, m); if (h && h.min < m) early++; }
  ok(early === 0, '가까운 기차: 고른 시각보다 앞선 기차는 절대 안 나옴(같은 날 도착보다 이른 기차도 안 보임)');
  ok(P.nearestDeparture(['06:10', '18:52'], T('07:00')).dep === '18:52', '문자열 시간표도 같은 규칙');
  ok(P.dayCount('2026-10-24', '2026-10-24') === 1 && P.dayCount('2026-10-24', '2026-10-25') === 2 && P.dayCount('2026-10-24', '2026-10-26') === 3 && P.dayCount('2026-10-24', '2026-11-30') === 3 && P.dayCount('2026-10-24', '2026-10-20') === 1, '일수: 당일 1 · 1박 2일 2 · 2박 3일 3 · 최대 3 · 가는 날이 앞이면 1');
  ok(P.tripLabel(1) === '당일치기' && P.tripLabel(2) === '1박 2일' && P.tripLabel(3) === '2박 3일', '자동 이름: 당일치기 / 1박 2일 / 2박 3일');
  ok(P.sunriseApprox('2026-10-17') >= 6 * 60 && P.sunriseApprox('2026-10-17') <= 6 * 60 + 45 && P.sunriseApprox('2026-12-21') > P.sunriseApprox('2026-10-17') && P.sunriseApprox('2026-06-21') < 5 * 60 + 30, '일출 어림(날짜별 계산): 10월 중순 06시 전후 · 12월 늦고 · 6월 이름: ' + P.fmt(P.sunriseApprox('2026-10-17')) + ' / ' + P.fmt(P.sunriseApprox('2026-12-21')));
  // 섞어 타기
  const mixA = P.plan(D, { how: 'train', backHow: 'bus', now: T('10:00'), train: T('18:00'), date: '2026-10-24', start: 'mukho', end: 'bus' });
  ok(mixA.startStation.id === 'mukho' && mixA.endStation.id === 'bus' && mixA.deadline === T('18:00') - 15 && mixA.back.arrive <= T('17:45') && mixA.feasible, '기차로 와서 버스로: 묵호역 출발 · 터미널 도착 · 버스 15분 전 ' + P.fmt(mixA.back.arrive));
  const mixB = P.plan(D, { how: 'car', backHow: 'train', now: T('10:00'), train: T('18:10'), date: '2026-10-24', start: 'park', end: 'mukho' });
  ok(mixB.startStation.id === 'park' && mixB.endStation.id === 'mukho' && mixB.deadline === T('18:10') - 15 && mixB.stops.every((x) => x.mode !== 'car') && mixB.back.mode !== 'car', '차로 와서 기차로: 자동차 이동 없음(걷기·버스·택시) · 기차 15분 전');
  const mixC = P.plan(D, { how: 'train', backHow: 'car', now: T('10:00'), train: T('18:00'), date: '2026-10-24', start: 'mukho', end: 'park' });
  ok(mixC.deadline === T('18:00') && mixC.back.arrive <= T('18:00') && mixC.stops.every((x) => x.mode !== 'car'), '기차로 와서 차로 돌아가기: 정한 시각(여유 0분)까지 주차장 · 자동차 이동 없음');
  const both = P.plan(D, { how: 'car', backHow: 'car', now: T('10:00'), train: T('18:00'), date: '2026-10-24' });
  ok(both.how === 'car' && both.stops.some((x) => x.mode === 'car'), '오고 갈 때 모두 자가용이면 자동차 이동(주차 포함)');
  // 추암 세 곳은 한 번만 (#demo-tour 포함)
  const chuamCount = (pl) => pl.stops.filter((x) => x.place.group === 'chuam').length;
  const dt2 = P.plan(D, { now: T('09:30'), train: T('19:40'), end: 'mukho', slow: false, avoidStairs: false, interests: [], date: '2026-10-24', tour: true, tourPrefer: true });
  ok(chuamCount(dt2) <= 1, '#demo-tour: 추암(촛대바위·해변·조각공원)은 한 번만: ' + ids(dt2).join('>'));
  let multiC = 0, badC = 0;
  for (const train of ['15:10', '18:10', '19:40']) for (const now of [T('09:30'), T('11:00')]) for (const tour of [true, false]) for (const prefer of [true, false]) { const pl = P.plan(D, { ...base, slow: false, avoidStairs: false, now, train: T(train), date: '2026-10-24', tour, tourPrefer: tour && prefer }); multiC++; if (chuamCount(pl) > 1) badC++; }
  ok(badC === 0, `${multiC}가지 하루 코스에서 추암 권역 두 번 방문 ${badC}건`);
  // 여러 날
  const MD = { date: '2026-10-24', now: T('10:00'), how: 'train', backHow: 'train', start: 'mukho', end: 'mukho', interests: [], couple: true, tour: true, sunrise: true };
  let nPl = 0, bad = 0, badDup = 0, badSun = 0, badStay = 0;
  const fails = [];
  for (const bk of ['2026-10-25', '2026-10-26']) for (const train of ['13:40', '18:52']) for (const backHow of ['train', 'bus', 'car']) for (const [slow, sunrise] of [[false, true], [true, true], [false, false]]) {
    const pl = P.planDays(D, { ...MD, backDate: bk, backHow, train: T(train), slow, avoidStairs: slow, sunrise, couple: !slow });
    nPl++;
    if (!pl.multi || pl.days.length !== P.dayCount(MD.date, bk)) { bad++; fails.push('days ' + bk); continue; }
    const last = pl.days[pl.days.length - 1].plan, dl = backHow === 'car' ? T(train) : T(train) - 15;
    if (last.feasible && last.back.arrive > dl) { bad++; fails.push('deadline ' + bk + train + backHow + ' ' + P.fmt(last.back.arrive)); }
    // 날마다: 시간순, 첫날·가운데 날은 20:30 안에 숙소 앞
    pl.days.forEach((d, k) => {
      let t = d.plan.start; d.plan.stops.forEach((s) => { if (s.arrive < t - 0 || s.leave <= s.arrive) bad++; t = s.leave; });
      if (k < pl.days.length - 1) { if (d.plan.back && d.plan.back.arrive > T('20:30')) badStay++; if (d.plan.endStation.id !== 'stay') badStay++; }
      if (k > 0 && d.plan.startStation.id !== 'stay') badStay++;
    });
    // 같은 곳 두 번 없음 · 추암 권역은 전체에서 한 번
    const all = pl.stops.map((s) => s.id);
    if (new Set(all).size !== all.length) { badDup++; fails.push('dup ' + all.join('>')); }
    if (pl.stops.filter((x) => x.place.group === 'chuam').length > 1) { badDup++; fails.push('chuam x2'); }
    // 둘째 날 일출
    if (sunrise) {
      const d2 = pl.days[1], f = d2.plan.stops[0];
      if (!d2.sunrise || !f || f.id !== 'chuam' || f.arrive !== P.sunriseApprox(d2.date) - 30 || d2.plan.start > T('06:30') || d2.plan.start < T('04:30')) { badSun++; fails.push('sun ' + bk + train + backHow + ' ' + (d2.sunrise ? 'yes' : 'no') + ' ' + (f && f.id) + ' ' + (f && P.fmt(f.arrive)) + ' start ' + P.fmt(d2.plan.start)); }
    } else if (pl.days[1].sunrise) badSun++;
  }
  ok(bad === 0, `여러 날 ${nPl}가지 조합: 마지막 날 마감(기차·버스 15분 전, 자가용 정한 시각) · 시간순 · 날 수 맞음 ${bad}건 위반 ${fails.slice(0, 2).join(',')}`);
  ok(badDup === 0, '여러 날: 같은 곳(한 끼 가게 포함)을 두 번 가지 않고, 추암 권역은 전체에서 한 번 ' + badDup + '건');
  ok(badSun === 0, '여러 날: 둘째 날 새벽 06시 안팎에 숙소에서 출발해 일출 30분 전 추암 도착(일출 켠 조합만), 끄면(비·아이·부모님) 일출 없음 ' + fails.filter((x) => /^sun/.test(x)).slice(0, 3).join(' | '));
  ok(badStay === 0, '여러 날: 첫날·가운데 날은 20:30 안에 숙소 앞에서 마침 · 다음 날은 숙소에서 출발');
  const o2 = P.planDays(D, { ...MD, backDate: '2026-10-26', train: T('15:48'), stay: { id: 'stay', name: '시험 숙소', lat: 37.5468, lng: 129.1077 } });
  ok(o2.nDays === 3 && o2.days[0].stay && o2.days[0].stay.name === '시험 숙소' && o2.days[1].stay && !o2.days[2].stay, '숙소는 마지막 날만 빼고 날마다 붙음');
  const g1 = o2.days[2].plan; ok(g1.start >= T('09:00') && !o2.days[2].sunrise, '셋째 날은 09:00 이후 시작 · 일출은 둘째 날 아침 한 번만');
  const b1 = o2.days[1].breakfast; ok(!b1 || (b1.arrive >= 7 * 60 && b1.leave <= b1.place.open[1] && b1.kind === 'meal'), '둘째 날 일출 뒤 아침 한 끼(있으면 영업시간 안): ' + (b1 ? b1.id + ' ' + P.fmt(b1.arrive) : '(가게 없음)'));
  ok(o2.stops.every((s, i, a) => i === 0 || a[i - 1].day <= s.day) && o2.stops.some((s) => s.day === 2), '합친 stops 에 날(day) 표시, 날 순서대로');
  // 비 오는 날은 일출 없이 09:00
  const wetM = P.planDays(D, { ...MD, backDate: '2026-10-25', train: T('15:48'), rain: true, sunrise: false });
  ok(!wetM.days[1].sunrise && wetM.days[1].plan.start >= T('08:59'), '비 오는 날(일출 끔): 둘째 날 09:00 시작');
  // 장날 · 쉬는 요일은 날마다
  const mk = P.planDays(D, { ...MD, date: '2026-10-22', backDate: '2026-10-24', train: T('16:00'), sunrise: false });
  ok(mk.days.every((d) => d.plan.date === d.date) && mk.days[2].plan.date === '2026-10-24', '날마다 그 날짜로 장날·쉬는 요일을 따짐');
  // 무릉별유천지 좌표
  const by = D.places.find((p) => p.id === 'byeoryu'), stop8 = CT.stops.find((s) => s.i === 8), link = stop8.links.find((l) => l.place === 'byeoryu');
  ok(P.hav(by, stop8) < 0.2 && link.walk && link.walk.sec / 60 < 10, `무릉별유천지: 정문(카카오 로컬)과 시티투어 정류장 ${Math.round(P.hav(by, stop8) * 1000)}m · 걸어서 ${Math.round(link.walk.sec / 60)}분 (예전 28분은 좌표 800m 어긋남)`);
  // 화면 연결
  ok(/id="sDate"/.test(html) && /id="sTime"/.test(html) && /id="bDate"/.test(html) && /id="bTime"/.test(html) && /id="howSeg"/.test(html) && /id="bhowSeg"/.test(html) && />올 때</.test(html) && />돌아가는 날</.test(html) && html.indexOf('id="qIn"') < html.indexOf('id="qOut"') && html.indexOf('id="qOut"') < html.indexOf('id="chipComp"'), '시작 화면: 올 때(날짜·시각·이동수단) → 돌아갈 때(같은 모양) → 누구와 → 단추');
  ok(!/rt\.list\.map\(function \(t\) \{ return '<button/.test(js) && /이 시간 가까운 기차/.test(js) && /P\.nearestDeparture/.test(js) && /코레일 시간표/.test(js), '기차 목록 고르기 없음 · 대신 "이 시간 가까운 기차" 작은 줄');
  ok(/backHowTouched/.test(js) && /c\.backHow = c\.how/.test(js) && /backDateTouched/.test(js) && /P\.addDays\(c\.date, 2\)/.test(js) && /\.max = /.test(js), '돌아갈 때 기본값: 같은 날 · 18:00 · 올 때와 같은 수단(직접 고치면 유지) · 가는 날은 +2일까지');
  ok(/차는 한쪽만 쓰는 여행이라 주차 위치를 한 번 확인해 주세요/.test(js), '차를 한쪽에만 타면 부드러운 안내');
  ok(/장날/.test(js) && /시티투어 평일 미운행/.test(js) && /시티투어 운행/.test(js) && /class="badges"/.test(html), '날짜 밑 작은 배지: 장날 · 시티투어 운행/평일 미운행(다음 날짜)');
  ok(/'demo-1bak'/.test(js) && /'1bak':/.test(js) && /nextSaturday/.test(js), '#demo-1bak: 다음 토요일 10:00 기차 · 일요일 15:48 · 연인');
  ok(/dayHeadHtml/.test(js) && /일차 · /.test(js) && /오늘은 .* 근처에서 묵어요/.test(js) && /숙소 예: /.test(js) && /rows\.push\(\{ head: true/.test(js), '피드 머리글 "1일차 · 11월 14일(토)" · 숙소 안내 · 기록 카드에 날별 묶음');
  ok(/--safe-t/.test(css) && /--safe-b/.test(css) && /min-height:100dvh/.test(css) && /-webkit-tap-highlight-color/.test(css) && /:active/.test(css) && /font-variant-numeric:tabular-nums/.test(css) && /input\[type=date\],input\[type=time\]\{ -webkit-appearance:none/.test(css), 'CSS: 안전 영역 · 100dvh · 눌림 표시 · 숫자 폭 고정 · 날짜 칸 모양');
  const keyfiles = ['routes.js', 'citytour.js', 'places.js', 'app.js', 'planner.js'].map((f) => fs.readFileSync(path.join(__dirname, f), 'utf8')).join('');
  ok(!/KakaoAK|kakao_rest|datagokr_key/.test(keyfiles), '키 이름·값이 코드·자료 파일에 없음');
}

console.log('[27] 코스 직접 고치기 (editor.js · ai.js aiEditIntent) — 순서·시간·빼기·넣기·마감 경고와 고치는 방법·고정 유지 다시 짜기·되돌리기·말로 고치기·여러 날·저장');
{
  const path = require('path'), E = require('./editor.js');
  const OD = { now: T('13:00'), train: T('18:10'), how: 'train', backHow: 'train', start: 'mukho', end: 'mukho', slow: false, avoidStairs: false, interests: [], date: '2026-10-24', rain: false };
  const mk = (o) => { const fr = P.plan(D, o); return { o, fr, env: { D, o, frame: fr }, spec: E.fromPlan(fr) }; };
  const SC = [OD, { ...OD, rain: true }, { ...OD, slow: true, avoidStairs: true }, { ...OD, now: T('10:00'), train: T('19:40') }, { ...OD, now: T('09:30'), train: T('19:40'), food: true }, { ...OD, mode: 'late', train: T('19:40') }].map(mk);
  const cons = (rt) => { // 시각이 서로 맞물리고 시간순인가
    let prev = rt.start; for (const s of rt.stops) {
      if (s.arrive !== prev + s.legMin || s.startVisit !== s.arrive + s.wait || s.leave !== s.startVisit + s.delay + s.visit || s.leave <= s.arrive || s.arrive < prev) return false; prev = s.leave; }
    return rt.back.arrive === prev + rt.back.min;
  };
  // 1) 고치기 전 = 자동 코스
  ok(SC.every((c) => { const r = E.retime(c.env, c.spec); return ids(r).join() === ids(c.fr).join() && r.stops.every((s, i) => s.arrive === c.fr.stops[i].arrive && s.leave === c.fr.stops[i].leave && s.mode === c.fr.stops[i].mode) && r.back.arrive === c.fr.back.arrive && E.blocks(r).length === 0; }), `고치기 전 코스를 다시 계산하면 자동 코스와 순서·시각·이동이 똑같고 문제 없음 (${SC.length}가지 조건)`);
  // 2) 순서 바꾸기: 시각이 맞물리고 시간순, 사용자 순서 그대로
  let nMove = 0, badMove = 0;
  SC.forEach((c) => { const n = c.spec.days[0].items.length; for (let i = 0; i < n; i++) for (const d of [-1, 1]) { const s2 = E.moveItem(c.spec, 0, i, d); if (!s2) continue; nMove++; const r = E.retime(c.env, s2); const want = s2.days[0].items.map((x) => x.id).join(); if (ids(r).join() !== want || !cons(r)) badMove++; }
    const s3 = E.moveTo(c.spec, 0, n - 1, 0); if (s3) { nMove++; const r = E.retime(c.env, s3); if (ids(r).join() !== s3.days[0].items.map((x) => x.id).join() || !cons(r)) badMove++; } });
  ok(nMove > 30 && badMove === 0, `순서 바꾸기 ${nMove}가지: 순서는 사용자가 정한 그대로 · 도착=앞 장 떠남+이동 · 시각 거꾸로 안 감 · 위반 ${badMove}`);
  const A = SC[0], baseRt = E.retime(A.env, A.spec);
  ok(E.moveItem(A.spec, 0, 0, -1) === null && E.moveItem(A.spec, 0, A.spec.days[0].items.length - 1, 1) === null, '맨 앞에서 위로·맨 뒤에서 아래로는 못 움직임');
  // 3) 빼기·넣기
  let badRem = 0, nRem = 0, badAdd = 0, nAdd = 0;
  SC.forEach((c) => { c.spec.days[0].items.forEach((it) => { const s2 = E.removeItem(c.spec, it.id); nRem++; const r = E.retime(c.env, s2); if (ids(r).indexOf(it.id) >= 0 || r.stops.length !== c.spec.days[0].items.length - 1 || !cons(r) || s2.excl.indexOf(it.id) < 0) badRem++; });
    const have = E.allIds(c.spec); D.places.concat(D.eateries).filter((p) => !have[p.id]).slice(0, 6).forEach((p) => { for (let at = 0; at <= c.spec.days[0].items.length; at += 2) { const s2 = E.addItem(c.env, c.spec, 0, at, p.id); nAdd++; const r = E.retime(c.env, s2); if (ids(r)[at] !== p.id || r.stops.length !== c.spec.days[0].items.length + 1 || !cons(r) || new Set(ids(r)).size !== ids(r).length) badAdd++; } }); });
  ok(nRem > 20 && badRem === 0, `빼기 ${nRem}가지: 그 곳이 빠지고 나머지 시각을 다시 계산 · 빼 둔 곳 기록 ${badRem}`);
  ok(nAdd > 30 && badAdd === 0, `넣기 ${nAdd}가지: 고른 자리에 들어가고 시각을 다시 계산 · 같은 곳 두 번 없음 ${badAdd}`);
  ok(E.addItem(A.env, A.spec, 0, 0, A.spec.days[0].items[0].id) === null, '이미 코스에 있는 곳은 또 넣을 수 없음');
  const mealRm = SC[4].spec.days[0].items.find((x) => x.kind === 'meal');
  ok(!mealRm || (E.removeItem(SC[4].spec, mealRm.id).noMeal === true), '한 끼를 빼면 "식사 안 넣음" 표시(다시 짜도 안 돌아옴)');
  // 4) 머무는 시간 ±
  const st0 = baseRt.stops[1], sMore = E.adjustVisit(A.env, A.spec, st0.id, 10), rMore = E.retime(A.env, sMore);
  ok(rMore.stops[1].leave === st0.leave + 10 && rMore.back.arrive === baseRt.back.arrive + 10 && cons(rMore), '머무는 시간 +10분 → 그 장 떠나는 시각과 돌아오는 시각이 10분 밀림');
  const sLess = E.adjustVisit(A.env, A.spec, st0.id, -10), rLess = E.retime(A.env, sLess);
  ok(rLess.stops[1].leave === st0.leave - 10 && rLess.back.arrive === baseRt.back.arrive - 10, '머무는 시간 −10분 → 10분 당겨짐');
  let sv = A.spec, guard = 0; while (guard++ < 40) { const n2 = E.adjustVisit(A.env, sv, st0.id, -10); if (!n2) break; sv = n2; }
  ok(E.visitOf(A.env, E.findItem(sv, st0.id).it) === 10 && E.adjustVisit(A.env, sv, st0.id, -10) === null, '머무는 시간은 10분 밑으로 안 내려감');
  let sv2 = A.spec; guard = 0; while (guard++ < 60) { const n2 = E.adjustVisit(A.env, sv2, st0.id, 10); if (!n2) break; sv2 = n2; }
  ok(E.visitOf(A.env, E.findItem(sv2, st0.id).it) === E.VISIT_MAX, `머무는 시간은 ${E.VISIT_MAX}분을 안 넘음`);
  // 5) 마감을 넘으면 알려 주고, 고치는 방법은 실제로 풀리는 것만
  let nViol = 0, badViol = 0, badFix = 0, nFix = 0, noFix = 0; const kinds = {};
  [OD, { ...OD, now: T('10:00'), train: T('19:40') }, { ...OD, slow: true, avoidStairs: true }, { ...OD, now: T('09:30'), train: T('17:40') }].forEach((o) => {
    const c = mk(o);
    [15, 25, 40].forEach((inc) => {
      const sp = E.clone(c.spec); sp.days[0].items.forEach((it) => { it.visit += inc; });
      const rt = E.retime(c.env, sp), dl = rt.issues.filter((x) => x.kind === 'deadline')[0];
      if (!dl) return; nViol++;
      if (dl.minutes !== rt.back.arrive - rt.deadline || !/(기차|버스).*(놓쳐요|못 닿아요).*분 늦음/.test(dl.text) || rt.late !== dl.minutes) badViol++;
      const f = E.fixes(c.env, sp);
      if (!f.fixes.length) noFix++;
      if (f.fixes.length > 3) badFix++;
      f.fixes.forEach((fx) => { nFix++; kinds[fx.kind] = (kinds[fx.kind] || 0) + 1; const r2 = E.retime(c.env, fx.spec); if (E.blocks(r2).length !== 0 || fx.partial) badFix++; });
    });
  });
  ok(nViol >= 8 && badViol === 0, `마감 넘김 ${nViol}가지: 문제 글("이대로면 ○○ 기차를 놓쳐요 (○분 늦음)")과 늦은 분이 계산과 같음 ${badViol}`);
  ok(nFix >= 10 && badFix === 0 && noFix === 0, `고치는 방법 ${nFix}개(종류 ${Object.keys(kinds).join('·')}): 방법마다 실제로 적용해 다시 계산하면 문제가 0건이고, 방법은 최대 3개 ${badFix} (방법 없는 경우 ${noFix})`);
  // 택시로 바꾸기: 걷기가 긴 구간(노봉해변→망상해변 29분 vs 택시 8분)
  { const o = { ...OD, now: T('10:00'), train: T('19:40') }, fr0 = P.plan(D, o);
    const sp = { v: 1, days: [{ items: ['nobong', 'mangsang'].map((id) => ({ id, visit: D.places.find((x) => x.id === id).visit })) }], excl: [], noMeal: false };
    const r0 = E.retime({ D, o, frame: fr0 }, sp), o2 = { ...o, train: r0.back.arrive + 15 - 4 }, fr2 = P.plan(D, o2), env2 = { D, o: o2, frame: fr2 };
    const f = E.fixes(env2, sp), tx = f.fixes.find((x) => x.kind === 'taxi');
    ok(!!tx && E.blocks(E.retime(env2, tx.spec)).length === 0 && /택시/.test(tx.label) && /분 줄어요/.test(tx.detail) && E.findItem(tx.spec, 'mangsang').it.taxi === true, '"택시로 바꾸기": 가장 긴 구간(' + (tx ? tx.detail : '-') + ')을 택시로 바꾸면 마감이 풀림');
    ok(f.fixes.some((x) => x.kind === 'shorten') && f.fixes.some((x) => x.kind === 'replan'), '"머무는 시간 줄이기"와 "나머지 다시 짜기"도 함께 제안'); }
  // 휴무·문 닫는 시각
  { const c = SC[3], sp = E.clone(c.spec); sp.days[0].items.unshift({ id: 'lighthouse', visit: 35 }); sp.days[0].items = sp.days[0].items.filter((x, i, a) => a.findIndex((y) => y.id === x.id) === i);
    const late = E.clone(sp); late.days[0].items.forEach((it) => { it.visit += 120; });
    const rt = E.retime(c.env, late); ok(rt.issues.some((x) => x.kind === 'closed' && /문 닫는 시각/.test(x.text)), '문 닫는 시각을 넘기면 "문 닫는 시각 뒤에 끝나요" 경고');
    const f = E.fixes(c.env, late); ok(f.fixes.length > 0 && f.fixes.every((x) => E.blocks(E.retime(c.env, x.spec)).length === 0 || x.partial), '문 닫는 시각 문제도 고치는 방법 제안(풀리는 것만)');
    const fxs = P.effectsFromReports([{ type: 'closed', placeId: c.fr.stops[0].id, simTs: 780 }], 780, true), env3 = { D, o: { ...c.o, fx: fxs }, frame: c.fr };
    const r3 = E.retime(env3, c.spec), f3 = E.fixes(env3, c.spec);
    ok(r3.issues.some((x) => x.kind === 'fxclosed') && ids(r3).join() === ids(c.fr).join() && f3.fixes.some((x) => x.kind === 'remove') , '휴무 제보가 와도 고친 순서는 그대로, 경고와 고치는 방법("빼기")만 올림'); }
  // 6) 나머지 다시 짜기(고정 유지)
  { const c = mk({ ...OD, now: T('10:00'), train: T('19:40') }), sp = E.clone(c.spec), it = sp.days[0].items;
    const keep = [it[0].id, it[2].id]; sp.days[0].items = [it[0], it[2]]; sp.days[0].items.forEach((x) => { x.pin = true; }); sp.days[0].items[1].visit += 10; sp.excl = [it[1].id, it[3].id];
    const rp = E.replan(c.env, sp, 0), rt = rp.ok && E.retime(c.env, rp.spec), got = rp.ok ? rp.spec.days[0].items.map((x) => x.id) : [];
    ok(rp.ok && got.indexOf(keep[0]) >= 0 && got.indexOf(keep[1]) >= 0 && got.indexOf(keep[0]) < got.indexOf(keep[1]) && E.blocks(rt).length === 0 && new Set(got).size === got.length, '다시 짜기: 고정한 두 곳이 그대로 들어 있고 앞뒤 순서 유지 · 마감 지킴 · 같은 곳 없음: ' + got.join('>'));
    ok(rp.ok && got.length > 2 && !got.includes(it[1].id) && !got.includes(it[3].id), '다시 짜기: 사용자가 뺀 곳은 다시 안 들어오고 빈틈은 다른 곳으로 채움');
    ok(rp.ok && rp.spec.days[0].items.filter((x) => x.pin).length === 2 && rt.stops.find((s) => s.id === keep[1]).visit === D.places.find((p) => p.id === keep[1]).visit + 10, '다시 짜도 📌 표시와 고정한 곳의 머무는 시간은 그대로');
    const sp2 = E.clone(c.spec); const m = sp2.days[0].items.find((x) => x.kind === 'meal'); if (m) { m.pin = true; const rp2 = E.replan(c.env, sp2, 0); ok(rp2.ok && rp2.spec.days[0].items.filter((x) => x.kind === 'meal').length === 1 && rp2.spec.days[0].items.some((x) => x.id === m.id), '고정한 한 끼 가게도 다시 짜도 그대로(식사는 한 번만)'); } else ok(true, '(한 끼 없는 조건 — 건너뜀)');
    const sp3 = E.clone(c.spec); sp3.days[0].items[2].pin = true; sp3.days[0].items[0].pin = true; const rp3 = E.replan(c.env, sp3, 0); const g3 = rp3.ok ? rp3.spec.days[0].items.map((x) => x.id) : [];
    ok(rp3.ok && g3.indexOf(c.spec.days[0].items[0].id) < g3.indexOf(c.spec.days[0].items[2].id) && g3.indexOf(c.spec.days[0].items[2].id) >= 0, '고정 순서(첫 곳 → 셋째 곳)가 다시 짠 뒤에도 같음');
    // 고정 때문에 불가능하면 정직하게 못 짠다고
    const sp4 = E.clone(c.spec); sp4.days[0].items = ['yongchu', 'byeoryu', 'chuam', 'mangsang', 'bukpyeong', 'skyvalley'].map((id) => ({ id, pin: true, visit: 100 })); const rp4 = E.replan(c.env, sp4, 0);
    ok(!rp4.ok && !!rp4.why, '고정한 곳이 시간 안에 다 안 들어가면 억지로 짜지 않고 못 짠다고 알림'); }
  // 7) 되돌리기 / 다시하기
  { const c = SC[0], h = new E.History(c.spec, 50), snaps = [JSON.stringify(h.cur)];
    let cur = c.spec, steps = 0;
    for (let i = 0; i < 25; i++) { let n = E.moveItem(cur, 0, i % 3, (i % 2) ? 1 : 1); if (!n) n = E.adjustVisit(c.env, cur, cur.days[0].items[0].id, 10); cur = n; h.push(cur); snaps.push(JSON.stringify(cur)); steps++; }
    ok(steps === 25 && h.undoS.length === 25 && h.canUndo() && !h.canRedo(), '고친 기록 25단계가 쌓임(20단계 이상)');
    let u = 0; while (h.canUndo()) { h.undo(); u++; }
    ok(u === 25 && JSON.stringify(h.cur) === snaps[0], '되돌리기를 25번 하면 처음 코스로');
    let r = 0; while (h.canRedo()) { h.redo(); r++; }
    ok(r === 25 && JSON.stringify(h.cur) === snaps[25], '다시하기를 25번 하면 마지막 고친 코스로');
    h.undo(); h.undo(); const keepCur = JSON.stringify(h.cur); h.push(E.moveItem(h.cur, 0, 0, 1) || E.adjustVisit(c.env, h.cur, h.cur.days[0].items[0].id, 10));
    ok(!h.canRedo() && JSON.stringify(h.cur) !== keepCur, '되돌린 뒤 새로 고치면 "다시하기" 기록은 지워짐');
    const hb = new E.History(c.spec, 50); let cc = c.spec; for (let i = 0; i < 70; i++) { cc = E.adjustVisit(c.env, cc, cc.days[0].items[i % 4].id, i % 2 ? -10 : 10) || E.adjustVisit(c.env, cc, cc.days[0].items[i % 4].id, 10) || cc; hb.push(E.clone(cc)); }
    ok(hb.undoS.length <= 50 && hb.undoS.length >= 20, '기록이 너무 길어지면 오래된 것부터 지움(최대 50단계): ' + hb.undoS.length); }
  // 8) 말로 고치기
  { const AIc = { places: D.places.concat(D.eateries).map((p) => ({ id: p.id, name: p.name, short: p.short })) }, I = (t) => AI.aiEditIntent(t, AIc).intents;
    const t1 = I('무릉계곡 빼줘'), t2 = I('점심 빼줘'), t3 = I('점심 넣어줘'), t4 = I('물회 넣어줘'), t5 = I('바다 하나 더'), t6 = I('실내로'), t7 = I('더 천천히'), t8 = I('등대 먼저'), t9 = I('시간 늘려줘'), t10 = I('논골담길이랑 등대 빼줘'), t11 = I('무릉계곡 빼고 점심 넣어줘'), t12 = I('여유있게 다녀요'), t13 = I('안녕하세요');
    ok(t1[0].type === 'remove' && t1[0].ids.join() === 'yongchu', '"무릉계곡 빼줘" → 용추폭포(무릉계곡) 빼기');
    ok(t2[0].type === 'removeMeal' && t2[0].when === 'lunch' && t3[0].type === 'addMeal' && t3[0].when === 'lunch', '"점심 빼줘" · "점심 넣어줘" → 점심 빼기·넣기');
    ok(t4[0].type === 'add' && t4[0].ids.join() === 'eat_obuja', '"물회 넣어줘" → 오부자냄비물회 넣기');
    ok(t5[0].type === 'addTheme' && t5[0].theme === 'sea', '"바다 하나 더" → 바다 쪽 한 곳 더');
    ok(t6[0].type === 'indoor' && t7[0].type === 'slower' && t12[0].type === 'slower', '"실내로" · "더 천천히" · "여유있게" 알아들음');
    ok(t8[0].type === 'first' && t8[0].ids.join() === 'lighthouse', '"등대 먼저" → 묵호등대를 맨 앞으로');
    ok(t9[0].type === 'longer' && t9[0].ids.length === 0, '"시간 늘려줘" → 머무는 시간 늘리기');
    ok(t10[0].type === 'remove' && t10[0].ids.sort().join() === 'lighthouse,nolgol', '한 번에 두 곳 빼기("논골담길이랑 등대 빼줘")');
    ok(t11.length === 2 && t11[0].type === 'remove' && t11[1].type === 'addMeal', '한 문장에 부탁 두 개("빼고 … 넣어줘")를 나눠 읽음');
    ok(t13[0].type === 'unknown' && AI.EDIT_HELP.length > 20, '못 알아들으면 "모르겠다"고 하고 말하는 법을 알려 줌');
    // 적용: 제안(diff) 만들기
    const c = mk({ ...OD, now: T('10:00'), train: T('19:40'), food: true }), have = ids(c.fr), meal = c.fr.meal && c.fr.meal.id, E1 = (t) => E.applyIntents(c.env, c.spec, AI.aiEditIntent(t, AIc).intents);
    const victim = c.fr.stops.find((s) => s.kind !== 'meal').id, vShort = D.places.find((p) => p.id === victim).short;
    const rA = E1(vShort + ' 빼줘'); ok(rA.ok && rA.diff.removed.indexOf(vShort) >= 0 && !E.allIds(rA.spec)[victim] && rA.diff.added.length === 0, `"${vShort} 빼줘" → 빠짐: ${rA.diff.removed.join(',')}`);
    const rB = E1('점심 빼줘'); ok(!meal || (rB.ok && !E.allIds(rB.spec)[meal] && rB.spec.noMeal === true && rB.diff.removed.length === 1), '"점심 빼줘" → 한 끼 빠짐(코스에 한 끼가 있을 때)');
    const rC = E1('바다 하나 더'); ok(rC.ok && rC.diff.added.length === 1 && /해변|수변|묵호항|해수욕장/.test(D.places.find((p) => p.id === rC.diff.addedIds[0]).name) && new Set(ids(E.retime(c.env, rC.spec))).size === E.retime(c.env, rC.spec).stops.length, '"바다 하나 더" → 바다 쪽 한 곳이 들어감: ' + rC.diff.added.join(','));
    const rD = E1('등대 먼저'); ok(rD.ok ? E.retime(c.env, rD.spec).stops[0].id === 'lighthouse' : have[0] === 'lighthouse', '"등대 먼저" → 첫 장이 묵호등대');
    const rE = E1('더 천천히'); ok(rE.ok && rE.diff.stay.length > 0 && E.retime(c.env, rE.spec).issues.filter((x) => x.kind === 'deadline').length === 0, '"더 천천히" → 머무는 시간이 늘고, 마감을 넘으면 덜 아까운 곳을 빼서 맞춤');
    const rF = E1('실내로'); ok(rF.ok ? E.retime(c.env, rF.spec).stops.filter((s) => !s.place.indoor).length <= c.fr.stops.filter((s) => !s.place.indoor).length : rF.msgs.length > 0, '"실내로" → 야외 곳이 늘지 않음');
    const rG = E1('시간 늘려줘'); ok(rG.ok && rG.diff.stay.length > 0, '"시간 늘려줘" → 머무는 시간 늘어남: ' + rG.diff.stay.slice(0, 2).join(','));
    const rH = E1('점심 넣어줘'); ok(rH.ok || rH.msgs.length > 0, '"점심 넣어줘" → 한 끼를 넣거나(이미 있으면) 이유를 말함');
    const spNo = E.removeItem(c.spec, meal || c.fr.stops[0].id), rI = E.applyIntents(c.env, spNo, AI.aiEditIntent('점심 넣어줘', AIc).intents);
    ok(rI.ok && rI.spec.noMeal === false && rI.spec.days[0].items.some((x) => x.kind === 'meal'), '한 끼를 뺀 뒤 "점심 넣어줘" → 다시 들어옴');
    const rJ = E1('이상한말'); ok(!rJ.ok && rJ.msgs.length > 0 && rJ.spec === undefined || JSON.stringify(rJ.spec) === JSON.stringify(c.spec), '못 알아들은 말은 코스를 바꾸지 않음'); }
  // 9) 여러 날: 자기 날 안에서만, 같은 곳 두 번 없음
  { const MO = { now: T('10:00'), train: T('15:48'), how: 'train', backHow: 'train', start: 'mukho', end: 'mukho', slow: false, avoidStairs: false, interests: [], date: '2026-10-24', backDate: '2026-10-25', rain: false, sunrise: false, tour: true, stay: { id: 'stay', name: '시험 숙소', lat: 37.5468, lng: 129.1077 } };
    const frM = P.planDays(D, MO), envM = { D, o: MO, frame: frM }, spM = E.fromPlan(frM), rtM = E.retime(envM, spM);
    const dayIds = (rt, d) => rt.days[d].plan.stops.map((s) => s.id);
    ok(spM.days.length === 2 && rtM.multi && rtM.days.every((d, i) => d.plan.stops.every((s) => s.day === i)) && ids(rtM).join() === ids(frM).join() && rtM.back.arrive === frM.back.arrive, '여러 날: 고치기 전 다시 계산하면 날마다 자동 코스와 같음');
    const mv = E.moveItem(spM, 0, 0, 1) || E.moveItem(spM, 1, 0, 1), r1 = E.retime(envM, mv);
    ok(r1.days.every((d, i) => d.plan.stops.every((s) => s.day === i)) && new Set(ids(r1)).size === ids(r1).length && r1.days.every((d) => cons(d.plan)), '여러 날: 순서를 바꿔도 장은 자기 날 안에서만 움직이고 시각이 맞물림');
    const other = dayIds(rtM, 1)[0], tryDup = E.addItem(envM, spM, 0, 0, other);
    ok(tryDup === null, '여러 날: 다른 날에 이미 있는 곳은 넣을 수 없음(같은 곳 두 번 방지)');
    const have = E.allIds(spM), fresh = D.places.concat(D.eateries).map((p) => p.id).find((id) => !have[id]), sa = E.addItem(envM, spM, 1, 0, fresh), ra = E.retime(envM, sa);
    ok(ra.days[1].plan.stops[0].id === fresh && !dayIds(ra, 0).includes(fresh) && dayIds(ra, 0).join() === dayIds(rtM, 0).join() && new Set(ids(ra)).size === ids(ra).length, '여러 날: 둘째 날에 넣으면 둘째 날에만 들어가고 첫날은 그대로(시각도 영향 없음)');
    const rm = E.removeItem(spM, dayIds(rtM, 0)[0]), rr = E.retime(envM, rm);
    ok(dayIds(rr, 1).join() === dayIds(rtM, 1).join() && rr.days[1].plan.stops.every((s, i) => s.arrive === rtM.days[1].plan.stops[i].arrive), '여러 날: 첫날에서 빼도 둘째 날 시각은 그대로');
    const inf = E.clone(spM); inf.days[0].items.forEach((it) => { it.visit += 90; });
    const ri = E.retime(envM, inf), dl = ri.issues.filter((x) => x.kind === 'deadline' && x.day === 0)[0];
    ok(!!dl && /1일차 밤/.test(dl.text) && ri.days[0].plan.late === dl.minutes, '여러 날: 첫날 밤 20:30 숙소 도착이 늦으면 "1일차 밤 … 숙소에 못 가요 (○분 늦음)" 경고: ' + (dl && dl.text));
    const fm = E.fixes(envM, inf);
    ok(fm.fixes.length > 0 && fm.fixes.every((x) => E.blocks(E.retime(envM, x.spec), 0).length === 0 || x.partial) && fm.fixes.every((x) => x.spec.days.length === 2), '여러 날: 첫날 경고의 고치는 방법도 실제로 풀리는 것만, 날 수는 그대로');
    const sp6 = E.clone(spM); sp6.days[0].items[0].pin = true; const rp = E.replan(envM, sp6, 0), gn = rp.ok ? rp.spec.days[0].items.map((x) => x.id) : [];
    ok(rp.ok && gn[0] === spM.days[0].items[0].id && gn.every((id) => !dayIds(rtM, 1).includes(id)) && E.blocks(E.retime(envM, rp.spec), 0).length === 0, '여러 날: 첫날만 다시 짜도 고정 유지 · 둘째 날 곳은 안 가져옴: ' + gn.join('>')); }
  // 9b) 둘째 날 새벽 추암 일출·아침 한 끼가 든 코스: 고치기 전 그대로 재현 · 다시 짜도 앞의 두 곳은 그대로
  for (const slowS of [false, true]) {
    const SO = { now: T('10:00'), train: T('15:48'), how: 'train', backHow: 'train', start: 'mukho', end: 'mukho', slow: slowS, avoidStairs: slowS, interests: [], date: '2026-10-24', backDate: '2026-10-25', rain: false, sunrise: true, tour: true, stay: { id: 'stay', name: '시험 숙소', lat: 37.5468, lng: 129.1077 } };
    const frS = P.planDays(D, SO), envS = { D, o: SO, frame: frS }, spS = E.fromPlan(frS), rtS = E.retime(envS, spS);
    ok(!!frS.days[1].sunrise && rtS.stops.every((s, i) => s.id === frS.stops[i].id && s.arrive === frS.stops[i].arrive && s.leave === frS.stops[i].leave) && E.blocks(rtS).length === 0, '일출 코스(' + (slowS ? '천천히' : '보통') + '): 고치기 전에 다시 계산해도 새벽 추암·아침 한 끼 시각까지 자동 코스와 똑같고 경고 없음');
    const rpS = E.replan(envS, spS, 1), gS = rpS.ok ? rpS.spec.days[1].items : [];
    ok(rpS.ok && gS[0].id === spS.days[1].items[0].id && gS[1].id === spS.days[1].items[1].id && gS[0].pre && E.blocks(E.retime(envS, rpS.spec), 1).length === 0, '일출 코스(' + (slowS ? '천천히' : '보통') + '): 둘째 날을 다시 짜도 새벽 추암 → 아침 한 끼가 맨 앞에 그대로');
  }
  // 10) 새로 고쳐도 유지 (localStorage 흉내)
  { const mem = new Map(), store = { get: (k) => (mem.has(k) ? mem.get(k) : null), set: (k, v) => mem.set(k, v), del: (k) => mem.delete(k) };
    const c = SC[3], key = 'tour.edit.v1.' + E.sigOf({ date: '2026-10-24', arrive: 600 }), h = new E.History(c.spec, 50);
    h.push(E.removeItem(h.cur, c.spec.days[0].items[1].id)); h.push(E.setPin(h.cur, c.spec.days[0].items[0].id, true)); h.push(E.adjustVisit(c.env, h.cur, c.spec.days[0].items[0].id, 10));
    E.save(store, key, h);
    const h2 = E.load(store, key, 50), a = E.retime(c.env, h.cur), b = E.retime(c.env, h2.cur);
    ok(!!h2 && JSON.stringify(h2.cur) === JSON.stringify(h.cur) && ids(a).join() === ids(b).join() && a.back.arrive === b.back.arrive && b.stops[0].pin === true && b.stops[0].visit === a.stops[0].visit, '새로 고친 뒤(저장소에서 다시 읽기): 고친 순서·📌 고정·머무는 시간이 그대로');
    ok(h2.undoS.length === 3 && h2.undo() && h2.undo() && h2.undo() && JSON.stringify(h2.cur) === JSON.stringify(c.spec), '새로 고친 뒤에도 되돌리기 기록이 살아 있어 처음 코스까지 되돌릴 수 있음');
    ok(E.load(store, 'tour.edit.v1.없는키') === null && E.load({ get: () => '깨진 글', set() {}, del() {} }, key) === null, '저장된 게 없거나 깨졌으면 조용히 무시(자동 코스로)');
    ok(E.sigOf({ a: 1, b: 2 }) === E.sigOf({ a: 1, b: 2 }) && E.sigOf({ a: 1, b: 2 }) !== E.sigOf({ a: 1, b: 3 }), '여행 조건이 같으면 같은 저장 칸, 다르면 다른 칸'); }
  // 11) 화면·접근성·본선 교체 주석 (코드 검사)
  { const html2 = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8'), js2 = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8'), css2 = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8'), ai2 = fs.readFileSync(path.join(__dirname, 'ai.js'), 'utf8'), ed2 = fs.readFileSync(path.join(__dirname, 'editor.js'), 'utf8');
    ok(/id="editBtn"[^>]*>코스 고치기/.test(html2) && /id="edWarn"/.test(html2) && /id="addSheet"[^>]*role="dialog"[^>]*aria-modal="true"/.test(html2) && /id="edUndo"/.test(html2) && /id="edRedo"/.test(html2) && /id="edReset"[^>]*>처음 코스로/.test(html2) && /id="edReplan"/.test(html2) && /도째비에게 말로 부탁하기/.test(html2) && html2.indexOf('editor.js') < html2.indexOf('app.js') && html2.indexOf('planner.js') < html2.indexOf('editor.js'), '화면: 코스 고치기 단추 · 경고 칸 · 되돌리기/다시하기/처음 코스로 · 나머지 다시 짜기 · 말로 부탁하기 · 장소 넣기 창(dialog) · 스크립트 순서');
    ok(['위로 올리기', '아래로 내리기', '코스에서 빼기', '머무는 시간 10분 줄이기', '머무는 시간 10분 늘리기', '자리 고정'].every((t) => js2.indexOf(t) > 0) && /여기에 장소 넣기/.test(js2) && /＋/.test(js2) && /aria-pressed="' \+ \(s\.pin/.test(js2) && /<span aria-hidden="true">↑<\/span> 위로/.test(js2), '접근성: 줄마다 이름이 들어간 단추 이름(aria-label) + 눈에 보이는 글자(위로·아래로·빼기·−10분·+10분·고정) + 고정은 aria-pressed');
    ok(/\.eb\{[^}]*min-height:48px[^}]*min-width:48px/.test(css2) && /\.ew-b\{[^}]*min-height:56px/.test(css2) && /\.sh-item\{[^}]*min-height:64px/.test(css2) && /\.eb\.add\{[^}]*min-height:48px/.test(css2) && /\.sh-card\{[^}]*max-height:min\(88dvh/.test(css2) && /--safe-b/.test(css2.slice(css2.indexOf('.sh-card{'), css2.indexOf('.sh-card{') + 400)), 'CSS: 고치기 단추 48px↑ · 경고 단추 56px↑ · 장소 넣기 항목 64px↑ · 창은 화면 88% 안 · 아래 안전 영역');
    ok(/font-size:max\(16px,1em\)/.test(css2) && /K_EDLAST|tour\.edit\.last\.v1/.test(js2) && /tour\.edit\.v1\./.test(js2) && /ED\.save\(EDSTORE/.test(js2) && /edBootRestore/.test(js2) && /edRestore\(\)/.test(js2), '저장: 여행 조건별 칸(tour.edit.v1.…)에 쓰고, 새로 열면 불러옴(makeCourse·시작할 때)');
    ok(/if \(S\.ed && edDirty\(\)\) \{ \/\/ 직접 고친 코스: 📌 고정은 그대로/.test(js2) && /ED\.replan\(env, spec, di\)/.test(js2.slice(js2.indexOf('function repApply'))) && /S\.ed = \{ frame: S\.plan/.test(js2), '제보: 직접 고친 코스에서 [코스 다시 짜기]는 📌 고정은 그대로 두고 나머지만 다시 짬(자동으로는 안 바뀜)');
    ok(/Claude API/.test(ai2) && /tool use/.test(ai2) && /remove_places/.test(ai2) && /본선 교체 지점/.test(ai2.slice(ai2.indexOf('aiEditIntent') - 1500, ai2.indexOf('aiEditIntent') + 200)), '말로 고치기: 본선에서 Claude API(도구 쓰기)로 바꿀 자리를 주석으로 표시');
    ok(/declutterPts/.test(js2) && /P\.hav\(q, p\) < 0\.4/.test(js2) && /near\.label \+= '·'/.test(js2) && /p\.dy/.test(js2), '지도: 가까이 겹치는 출발·숙소·도착 표시는 하나로 합치고(출발·도착) 다른 점과 겹치면 위·아래로 띄움');
    ok(!/KakaoAK|kakao_rest|datagokr_key/.test(ed2 + ai2), '새 코드에 키 이름·값 없음'); }
}

console.log('[28] 실시간 여행 안내 (live.js) — 도착 감지·남은 시간·마감까지·늦음과 고치기·길 벗어남·가상 이동·걷기 안내·카카오맵 주소·고친 코스·여러 날');
{
  const path = require('path'), E = require('./editor.js'), L = require('./live.js');
  const OD = { now: T('13:00'), train: T('18:10'), how: 'train', backHow: 'train', start: 'mukho', end: 'mukho', slow: false, avoidStairs: false, interests: [], date: '2026-10-24', rain: false };
  const mkTrip = (o, di) => { const fr = P.plan(D, o); return { o, fr, trip: L.buildTrips(fr, { slow: !!o.slow })[di || 0], env: { D, o, frame: fr }, spec: E.fromPlan(fr) }; };
  const A = mkTrip(OD);
  const ME = (n) => ({ lat: n.place.lat, lng: n.place.lng });
  const off = (n, m) => ({ lat: n.place.lat + m / 110574, lng: n.place.lng }); // 북쪽으로 m 미터
  // 1) node 줄
  ok(A.trip.nodes.length === A.fr.stops.length + 2 && A.trip.nodes[0].kind === 'start' && A.trip.nodes[A.trip.nodes.length - 1].kind === 'end' && A.trip.nodes.every((n, i) => n.i === i), '코스 → 출발 · 장 · 도착 node 줄 (' + A.trip.nodes.length + '개)');
  // 2) 도착 감지: 50m · 10초
  { const s = new L.Session(mkTrip(OD).trip); s.start(780, 0); const n1 = s.nodes[1], c = ME(n1);
    let ev = s.setPosition(off(n1, 40).lat, c.lng, 10, 0, 780); ev = ev.concat(s.setPosition(off(n1, 40).lat, c.lng, 10, 9000, 780.1));
    ok(s.phase === 'travel' && !ev.length, '50m 안에 9초만 있으면 아직 도착 아님');
    ev = s.setPosition(off(n1, 40).lat, c.lng, 10, 10000, 780.2);
    ok(s.phase === 'visit' && ev.some((e) => e.type === 'arrive' && e.k === 1), '50m 안에 10초 이상 있으면 도착 (여기 왔어요와 같은 표시)');
    const s2 = new L.Session(mkTrip(OD).trip); s2.start(780, 0);
    s2.setPosition(off(n1, 60).lat, c.lng, 10, 0, 780); s2.setPosition(off(n1, 60).lat, c.lng, 10, 30000, 780.5);
    ok(s2.phase === 'travel', '60m(위치 오차 10m)에서는 30초 있어도 도착 아님');
    const s3 = new L.Session(mkTrip(OD).trip); s3.start(780, 0);
    s3.setPosition(off(n1, 75).lat, c.lng, 80, 0, 780); s3.setPosition(off(n1, 75).lat, c.lng, 80, 11000, 780.2);
    ok(s3.phase === 'visit', '위치 오차 80m 면 75m 에서도 도착으로 침(오차만큼 넓힘, 최대 80m)');
    const s4 = new L.Session(mkTrip(OD).trip); s4.start(780, 0);
    s4.setPosition(off(n1, 90).lat, c.lng, 500, 0, 780); s4.setPosition(off(n1, 90).lat, c.lng, 500, 60000, 781);
    ok(s4.phase === 'travel', '오차가 아무리 커도 반지름은 80m 까지 — 90m 는 도착 아님');
    const s5 = new L.Session(mkTrip(OD).trip); s5.start(780, 0);
    s5.setPosition(off(n1, 20).lat, c.lng, 10, 0, 780); s5.setPosition(off(n1, 200).lat, c.lng, 10, 6000, 780.1); s5.setPosition(off(n1, 20).lat, c.lng, 10, 12000, 780.2);
    ok(s5.phase === 'travel', '중간에 50m 밖으로 나갔다 오면 10초를 처음부터 다시 셈');
    const v = s.setPosition(off(n1, 150).lat, c.lng, 10, 20000, 790);
    ok(s.phase === 'travel' && s.k === 2 && v.some((e) => e.type === 'leave'), '머물던 곳에서 120m 넘게 떠나면 다음 장으로 넘어감');
    const s6 = new L.Session(mkTrip(OD).trip); s6.start(780, 0); const e1 = s6.arriveNow(790, 1), e2 = s6.leaveNow(800);
    ok(e1[0].type === 'arrive' && e1[0].manual && e2[0].type === 'leave' && s6.k === 2 && s6.skipNow(801).length === 1 && s6.k === 3, '"여기 왔어요" · "다음 장소로" · "건너뛰기" 단추도 같은 상태로 움직임'); }
  // 3) 다음 장 안내 글 · 남은 거리·분
  { const s = new L.Session(mkTrip(OD).trip); s.start(780, 0); const sn0 = s.snapshot(780), n1 = s.nodes[1];
    ok(/^다음: .+ · (\d+m|[\d.]+km) · 약 \d+분 \((걸어서|버스|택시|자가용|시티투어)\)$/.test(sn0.next.text) && sn0.next.min >= 1, '다음 장 글 모양: ' + sn0.next.text);
    const half = L.pointAt(s.legPath(1), L.pathLen(s.legPath(1)) / 2); s.setPosition(half.lat, half.lng, 10, 1000, 780 + n1.leg.min / 2);
    const sn1 = s.snapshot(780 + n1.leg.min / 2);
    ok(Math.abs(sn1.next.distM - L.pathLen(s.legPath(1)) / 2) < 30 && Math.abs(sn1.next.min - Math.ceil(n1.leg.min / 2)) <= 1, `길 절반에서 남은 거리 ${sn1.next.distM}m ≈ 절반, 남은 시간 ${sn1.next.min}분 ≈ 이동 ${n1.leg.min}분의 절반`);
    ok(sn1.late.behind === 0 && !sn1.late.warn, '정시에 가면 늦음 0'); }
  // 4) 마감까지 (수단별 · 여러 날)
  { const t1 = mkTrip(OD).trip, s1 = new L.Session(t1); s1.start(780, 0);
    ok(s1.countdown(780).text === '기차까지 ' + L.hm(T('18:10') - 780), '기차까지 남은 시간: ' + s1.countdown(780).text);
    const bus = mkTrip({ ...OD, how: 'bus', backHow: 'bus', start: 'bus', end: 'bus' }).trip, sb = new L.Session(bus); sb.start(780, 0);
    ok(/^버스까지 /.test(sb.countdown(780).text), '버스: ' + sb.countdown(780).text);
    const car = mkTrip({ ...OD, how: 'car', backHow: 'car', start: 'park', end: 'park' }).trip, sc = new L.Session(car); sc.start(780, 0);
    ok(/^정한 시각까지 /.test(sc.countdown(780).text) && sc.countdown(T('18:10') + 5).text === '정한 시각이 지났어요', '자가용: ' + sc.countdown(780).text);
    ok(s1.countdown(T('18:10') + 1).min === -1 && /지났어요/.test(s1.countdown(T('18:10') + 1).text), '시각이 지나면 "지났어요"');
    const MD = { ...OD, now: T('10:00'), train: T('15:48'), backDate: '2026-10-25', slow: false };
    const mf = P.planDays(D, MD), tr = L.buildTrips(mf, { slow: false });
    ok(tr.length === 2 && tr[0].meta.lastDay === false && tr[1].meta.lastDay === true && tr[0].meta.date === mf.days[0].date, '1박 2일 → 날마다 따로 안내(둘째 날이 마지막 날)');
    const m0 = new L.Session(tr[0]); m0.start(T('10:00'), 0); const m1 = new L.Session(tr[1]); m1.start(T('09:00'), 0);
    ok(/^오늘 숙소 도착까지 /.test(m0.countdown(T('10:00')).text) && m0.countdown(T('10:00')).min === mf.days[0].plan.deadline - T('10:00') && /^기차까지 /.test(m1.countdown(T('09:00')).text), '여러 날: 첫날은 "오늘 숙소 도착까지"(' + m0.countdown(T('10:00')).text + '), 마지막 날은 "기차까지"');
    const nodesN = tr[0].nodes; ok(nodesN[nodesN.length - 1].place.id === 'stay' || /숙소|묵호/.test(nodesN[nodesN.length - 1].place.name), '첫날 도착 지점은 숙소 자리'); }
  // 5) 늦음 감지 + 고치는 방법이 실제로 풀림
  { const c = mkTrip({ ...OD, now: T('10:00'), train: T('19:40') }), s = new L.Session(c.trip); s.start(600, 0); const n1 = s.nodes[1];
    s.arriveNow(n1.arrive, 1); const pr0 = s.late(n1.arrive + 1);
    ok(!pr0.warn, '정시 도착이면 늦음 알림 없음');
    const late = 200, now = n1.arrive + late, lt = s.late(now);
    ok(lt.warn && lt.behind >= 15 && lt.deadline > 0, `한 곳에서 ${late}분 늦게까지 머물면 알림이 켜짐(예정보다 ${lt.behind}분 · 마감 ${lt.deadline}분 넘김)`);
    const fx = L.remainderFixes({ ED: E, env: c.env, spec: c.spec, di: 0, session: s, now });
    ok(fx.fixes.length >= 1 && fx.fixes.length <= 4, '고치는 방법 ' + fx.fixes.length + '개: ' + fx.fixes.map((f) => f.label).join(' · '));
    ok(fx.fixes.every((f) => f.sub && (f.partial || E.blocks(f.sub).length === 0)), '각 방법은 적용하면 마감 문제가 풀림 (남은 코스를 다시 계산해 확인)');
    ok(fx.fixes.every((f) => f.spec.days[0].items.slice(0, 1).map((x) => x.id).join() === n1.id), '이미 다녀온 장은 그대로 두고 남은 곳만 고침 (코스 전체 spec 에 되돌려 끼움)');
    const f0 = fx.fixes[0], before = s.nodes.length; s.rebuild(f0.sub, fx.base, { slow: false });
    const l2 = s.late(now);
    ok(s.nodes[0].kind === 'start' && s.nodes[s.nodes.length - 1].kind === 'end' && s.nodes.every((n, i) => n.i === i) && (l2.deadline < lt.deadline || l2.deadline === 0), `고친 뒤 남은 장을 다시 놓으면 마감 넘김이 ${lt.deadline}분 → ${l2.deadline}분 (${f0.label}, node ${before} → ${s.nodes.length})`);
    ok(JSON.stringify(c.spec) === JSON.stringify(E.fromPlan(c.fr)), '원래 코스(spec)는 눌러 고치기 전에는 바뀌지 않음');
    const c2 = mkTrip({ ...OD, now: T('09:30'), train: T('19:40') }), s2 = new L.Session(c2.trip); s2.start(570, 0); s2.arriveNow(c2.trip.nodes[1].arrive + 25, 1);
    const nw = c2.trip.nodes[1].arrive + 26, l3 = s2.late(nw), f3 = L.remainderFixes({ ED: E, env: c2.env, spec: c2.spec, di: 0, session: s2, now: nw });
    ok(l3.behind >= 15 && l3.warn && f3.fixes.length >= 1, `25분 늦음(마감은 ${l3.deadline > 0 ? '넘김' : '맞음'}) → 알림 + 방법 ${f3.fixes.length}개`); }
  // 6) 길 벗어남
  { const c = mkTrip({ ...OD, slow: false }), s = new L.Session(c.trip); s.start(780, 0);
    const path = s.legPath(1), mid = L.pointAt(path, L.pathLen(path) / 2), far = { lat: mid.lat + 400 / 110574, lng: mid.lng };
    let ev = [], t = 0; for (; t <= 50000; t += 5000) ev = ev.concat(s.setPosition(far.lat, far.lng, 10, t, 781));
    ok(!ev.some((e) => e.type === 'offroute'), '길에서 400m 벗어나도 50초 동안은 알리지 않음');
    ev = s.setPosition(far.lat, far.lng, 10, 61000, 782); ok(ev.some((e) => e.type === 'offroute') && s.offFlag, '150m 넘게 60초 벗어나면 "길에서 벗어난 것 같아요"');
    ev = s.setPosition(mid.lat, mid.lng, 10, 70000, 783); ok(ev.some((e) => e.type === 'backonroute') && !s.offFlag, '길로 돌아오면 알림이 사라짐');
    const s2 = new L.Session(mkTrip(OD).trip); s2.start(780, 0); let e2 = []; const near = { lat: mid.lat + 100 / 110574, lng: mid.lng };
    for (let t2 = 0; t2 <= 120000; t2 += 10000) e2 = e2.concat(s2.setPosition(near.lat, near.lng, 10, t2, 781));
    ok(!e2.some((e) => e.type === 'offroute'), '100m 떨어진 것은 오래 있어도 벗어남이 아님'); }
  // 7) 가상 이동: 길 위 위치 · 시간표대로
  { const cases = [A, mkTrip({ ...OD, now: T('10:00'), train: T('19:40'), food: true }), mkTrip({ ...OD, slow: true, avoidStairs: true, rain: true })]; let bad = 0, nDone = 0, worst = 0, offp = 0;
    cases.forEach((c) => {
      const s = new L.Session(c.trip), sim = new L.Sim(s); s.start(sim.clock(), sim.tms());
      ok(Math.abs(sim.end - (c.fr.back.arrive - c.fr.start)) < 1e-6, '가상 이동 전체 시간 = 코스 시간 (' + sim.end + '분 = ' + (c.fr.back.arrive - c.fr.start) + '분)');
      const order = []; let guard = 0;
      while (s.phase !== 'done' && guard++ < 200000) {
        sim.step(0.1); const p = sim.pos(), ev = s.setPosition(p.lat, p.lng, 10, sim.tms(), sim.clock());
        ev.forEach((e) => { if (e.type === 'arrive') order.push(e.k); });
        const l = s.late(sim.clock()); worst = Math.max(worst, Math.abs(l.behind));
        if (s.phase === 'travel') { const pl = L.locate(s.legPath(s.k), p.lat, p.lng); if (pl.dist > 2) offp++; }
      }
      if (s.phase === 'done' && order.join() === c.trip.nodes.map((n, i) => i).slice(1).join() && Math.abs(sim.clock() - c.fr.back.arrive) < 2) nDone++; else bad++;
    });
    ok(bad === 0 && nDone === cases.length, `가상 이동 ${cases.length}코스: 장을 차례대로 다 도착하고 끝 시각이 코스와 ±2분`);
    ok(worst <= 8, `가상 이동 중 "예정보다 늦음" 어림이 정시 흐름에서 ${worst}분 이하로 어긋남(알림 기준 15분 아래)`);
    ok(offp === 0, '가상 이동 위치가 늘 그 구간의 길 위(2m 안)'); }
  // 8) 가상 이동 보간 + 시간
  { const s = new L.Session(A.trip), sim = new L.Sim(s), g = sim.segs.filter((x) => x.type === 'leg')[0];
    sim.prog = g.t0 + g.dur / 2; const p = sim.pos(), half = L.pointAt(g.path, g.len / 2);
    ok(L.mDist(p.lat, p.lng, half.lat, half.lng) < 1, '구간 절반 시각에는 길 절반 지점');
    sim.prog = 0; sim.step(1.5); ok(Math.abs(sim.prog - 1.5) < 1e-9 && Math.abs(sim.clock() - (A.fr.start + 1.5)) < 1e-9, 'step 이 가상 시간을 그대로 흘림');
    sim.delay(25); ok(Math.abs(sim.clock() - (A.fr.start + 1.5 + 25)) < 1e-9 && sim.prog === 1.5, '늦어짐 +25분은 시계만 앞서고 위치는 그대로');
    const s2 = new L.Session(mkTrip(OD).trip), sm2 = new L.Sim(s2); s2.start(sm2.clock(), sm2.tms());
    let g2 = 0; while (s2.phase !== 'visit' && g2++ < 100000) { sm2.step(0.1); const p2 = sm2.pos(); s2.setPosition(p2.lat, p2.lng, 10, sm2.tms(), sm2.clock()); }
    sm2.delay(25); s2.addDelay(25); const w = s2.late(sm2.clock());
    ok(s2.phase === 'visit' && w.behind >= 15 && w.warn, `가상 "늦어짐"(+25분) → 예정보다 ${w.behind}분 늦음 알림이 켜짐`);
    const fx = L.remainderFixes({ ED: E, env: A.env, spec: A.spec, di: 0, session: s2, now: sm2.clock() });
    ok(fx.fixes.length > 0, '가상 늦어짐에도 고치는 방법이 나옴 (' + fx.fixes.map((f) => f.label).join(' · ') + ')');
    s2.rebuild(fx.fixes[0].sub, fx.base, { slow: false }); sm2.rebuild(); let g3 = 0; const arr = [];
    while (s2.phase !== 'done' && g3++ < 200000) { sm2.step(0.1); const p3 = sm2.pos(); s2.setPosition(p3.lat, p3.lng, 10, sm2.tms(), sm2.clock()).forEach((e) => { if (e.type === 'arrive') arr.push(e.k); }); }
    ok(s2.phase === 'done' && arr[arr.length - 1] === s2.last(), '고친 뒤 가상 이동이 새 시간표로 끝까지 이어져 도착함'); }
  // 9) 걷기 안내(steps)
  { const rp = RP; let found = null;
    const find = (id) => D.stations[id] || D.places.find((p) => p.id === id) || (D.eateries || []).find((p) => p.id === id);
    for (const k of Object.keys(rp)) { const w = rp[k].walk; if (w && w.steps && w.steps.length >= 3 && w.m >= 250) { const [a, b] = k.split('|'); if (find(a) && find(b)) { found = { a: find(a), b: find(b), w, k }; break; } } }
    ok(!!found, '미리 받은 길에 걷기 안내 토막이 있음(길수집.mjs 가 받아 둔 응답에서 뽑음)');
    const st = L.stepsFor(found.a, found.b, false, rp, { mode: 'walk', real: true }), rev = L.stepsFor(found.b, found.a, false, rp, { mode: 'walk', real: true });
    ok(st && st.length === found.w.steps.length && st[0].text && st.every((x) => isFinite(x.x) && isFinite(x.y)) && rev === null, '걷기 안내는 받아 둔 한 방향에만 붙고 반대 방향에는 안 붙음(왼쪽·오른쪽이 거꾸로라서)');
    ok(L.stepsFor(found.a, found.b, false, rp, { mode: 'bus', real: true }) === null && L.stepsFor(found.a, found.b, false, null, { mode: 'walk', real: true }) === null, '걷지 않는 구간·길 값 없음에는 안 붙음');
    const trip = { di: 0, nodes: [{ i: 0, kind: 'start', place: found.a, arrive: 600, leave: 600, visit: 0, leg: null }, { i: 1, kind: 'stop', place: found.b, arrive: 650, startVisit: 650, leave: 680, visit: 30, leg: { mode: 'walk', min: 50, path: found.w.path, real: true, steps: st } }, { i: 2, kind: 'end', place: found.a, arrive: 700, leave: null, leg: { mode: 'walk', min: 20, path: null } }], meta: { di: 0, lastDay: true, deadline: 800, train: 815, howOut: 'train' } };
    const s = new L.Session(trip); s.start(600, 0); const got = [];
    let ev = s.setPosition(st[0].y, st[0].x, 5, 1000, 600); ev.forEach((e) => { if (e.type === 'step') got.push(e.j); });
    ok(got[0] === 0 && ev[0].text === st[0].text, '떠나자마자 첫 안내를 읽어 줌(' + st[0].text + ')');
    ok(s.snapshot(600).step.j >= 1, '그 다음 안내가 "곧"에 보임');
    ev = s.setPosition(st[1].y + 20 / 110574, st[1].x, 5, 5000, 601); ok(ev.some((e) => e.type === 'step' && e.j === 1) || s.stepI > 1, '안내 지점 30m 안에 들면 그 안내를 읽어 줌');
    ev = s.setPosition(st[1].y + 25 / 110574, st[1].x, 5, 9000, 602); ok(!ev.some((e) => e.type === 'step' && e.j === 1), '같은 안내는 한 번만');
    const s9 = new L.Session(trip); s9.start(600, 0); s9.stepI = 1; ev = s9.setPosition(st[1].y + 80 / 110574, st[1].x, 5, 12000, 603); ok(!ev.some((e) => e.type === 'step' && e.j === 1), '30m 밖에서는 안 읽음'); }
  // 10) 카카오맵 주소
  { const f = { name: '묵호역', lat: 37.54682, lng: 129.10769 }, t = { name: '논골담길', lat: 37.5516, lng: 129.1172 };
    const w = L.kakaoLink('walk', f, t), tr = L.kakaoLink('traffic', f, t), cr = L.kakaoLink('car', f, t);
    ok(w === 'https://map.kakao.com/link/by/walk/' + encodeURIComponent('묵호역') + ',37.54682,129.10769/' + encodeURIComponent('논골담길') + ',37.5516,129.1172', '걷기 주소: ' + w);
    ok(tr.startsWith('https://map.kakao.com/link/by/traffic/') && cr.startsWith('https://map.kakao.com/link/by/car/'), '대중교통(by/traffic) · 자동차(by/car) 주소');
    ok(/^https:\/\/map\.kakao\.com\/link\/by\/walk\/%[0-9A-F]{2}[^/]*,\d+\.\d+,\d+\.\d+\/%[0-9A-F]{2}[^/]*,\d+\.\d+,\d+\.\d+$/.test(w), '공식 길찾기 landingUrl(…/link/by/walk/%EC%B6%9C%EB%B0%9C,위도,경도/%EB%8F%84%EC%B0%A9,위도,경도)과 같은 짜임');
    ok(L.kakaoLink('walk', { name: 'a,b/c?d', lat: 1, lng: 2 }, t).split('/').length === 8, '이름에 쉼표·슬래시가 있어도 주소 짜임이 안 깨짐');
    const lg = (mode, tour) => L.legLink(f, { place: { name: '논골담길', lat: 37.5516, lng: 129.1172 }, leg: { mode, tour } }, null).url;
    ok(/by\/walk\//.test(lg('walk')) && /by\/traffic\//.test(lg('bus')) && /by\/car\//.test(lg('taxi')) && /by\/car\//.test(lg('car')), '이동 수단별 주소: 걷기→walk · 버스→traffic · 택시·자가용→car');
    const lt = L.legLink(f, { place: t, leg: { mode: 'tour', tour: { stopsUsed: [{ name: '어달해변', lat: 37.5, lng: 129.1 }] } } }, null);
    ok(/by\/walk\//.test(lt.url) && decodeURIComponent(lt.url).indexOf('어달해변 정류장') > 0 && /정류장/.test(lt.label), '시티투어는 타는 정류장까지 걷기 길안내');
    ok(decodeURIComponent(L.legLink(f, { place: t, leg: { mode: 'walk' } }, { lat: 37.5, lng: 129.1 }).url).indexOf('내 위치,37.5,129.1') > 0, '지금 가는 중이면 출발이 "내 위치"'); }
  // 11) 시티투어 탑승 안내 · 가상 이동 시티투어 구간
  { const T0 = { ...OD, now: T('09:30'), train: T('19:40'), date: '2026-10-24', tour: true, tourPrefer: true }, c = mkTrip(T0), tl = c.trip.nodes.filter((n) => n.leg && n.leg.mode === 'tour');
    ok(tl.length > 0, '시티투어 예시 코스에 시티투어 구간이 있음(' + tl.length + '곳)');
    if (tl.length) { const s = new L.Session(c.trip); s.start(c.fr.start, 0); s.k = tl[0].i; s.phase = 'travel'; s.leftAt[s.k - 1] = tl[0].arrive - tl[0].leg.min; const sn = s.snapshot(tl[0].arrive - tl[0].leg.min);
      ok(sn.next.tourBoard && /정류장에서 \d\d:\d\d 시티투어 탑승$/.test(sn.next.tourBoard.text) && sn.next.modeName === '시티투어', '시티투어 구간: "' + sn.next.tourBoard.text + '"');
      const sim = new L.Sim(new L.Session(c.trip)), kinds = sim.segs.map((g) => g.type + ':' + (g.mode || '')).join(' ');
      ok(/leg:tour/.test(kinds) && /dwell:/.test(kinds) && Math.abs(sim.end - (c.fr.back.arrive - c.fr.start)) < 1e-6, '가상 이동이 시티투어 구간을 걷기·기다림·버스·걷기로 나눠 같은 시간에 끝남'); } }
  // 12) 직접 고친 코스에서도 동작
  { const c = mkTrip({ ...OD, now: T('10:00'), train: T('19:40') }); let sp = E.removeItem(c.spec, c.spec.days[0].items[1].id); sp = E.moveItem(sp, 0, 0, 1) || sp; sp = E.adjustVisit(c.env, sp, sp.days[0].items[0].id, 20) || sp;
    const rt = E.retime(c.env, sp), trip = L.buildTrips(rt, { slow: false })[0], s = new L.Session(trip), sim = new L.Sim(s); s.start(sim.clock(), sim.tms());
    const order = []; let g = 0; while (s.phase !== 'done' && g++ < 200000) { sim.step(0.1); const p = sim.pos(); s.setPosition(p.lat, p.lng, 10, sim.tms(), sim.clock()).forEach((e) => { if (e.type === 'arrive') order.push(s.nodes[e.k].id); }); }
    const rtIds = rt.stops.filter((x) => !(x.place && x.place.slot)).map((x) => x.id);
    ok(trip.nodes.slice(1, -1).map((n) => n.id).join() === rtIds.join() && order.slice(0, -1).join() === rtIds.join() && s.phase === 'done', '고친 코스(빼기·순서·머무는 시간)도 고친 순서 그대로 안내하고 끝까지 도착: ' + order.join('>'));
    ok(Math.abs(sim.clock() - rt.back.arrive) < 2, '고친 코스의 도착 시각과 가상 이동 끝 시각이 같음(±2분)');
    const s3 = new L.Session(trip); s3.start(600, 0); const fx = L.remainderFixes({ ED: E, env: c.env, spec: sp, di: 0, session: s3, now: 600 + 150 });
    ok(fx.base === null || fx.fixes.every((f) => f.spec.excl.indexOf(c.spec.days[0].items[1].id) >= 0), '고친 코스에서 늦어도 이미 뺀 곳은 다시 안 들어옴'); }
  // 13) 여러 날 + 늦음
  { const MD = { ...OD, now: T('10:00'), train: T('15:48'), backDate: '2026-10-25' }, mf = P.planDays(D, MD), tr = L.buildTrips(mf, { slow: false });
    const env = { D, o: MD, frame: mf }, spec = E.fromPlan(mf), s = new L.Session(tr[1]); s.start(tr[1].nodes[0].arrive, 0); s.arriveNow(tr[1].nodes[1].arrive, 1);
    const now = tr[1].nodes[1].arrive + 180, lt = s.late(now), fx = L.remainderFixes({ ED: E, env, spec, di: 1, session: s, now });
    ok(lt.warn && fx.base && fx.fixes.every((f) => f.spec.days.length === 2 && JSON.stringify(f.spec.days[0]) === JSON.stringify(spec.days[0])), '둘째 날에 늦어도 첫째 날 코스는 그대로, 둘째 날 남은 곳만 고침 (고치는 방법 ' + fx.fixes.length + '개)'); }
  // 14) 개인정보 · 화면 · 접근성 (코드 검사)
  { const lj = fs.readFileSync(path.join(__dirname, 'live.js'), 'utf8'), aj = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8'), hh = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8'), cc = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8'), bj = fs.readFileSync(path.join(__dirname, '묶음.mjs'), 'utf8');
    const lvBlock = aj.slice(aj.indexOf('실시간 여행 안내 (2026-10-17)'), aj.indexOf('3. 현장 제보'));
    ok(lvBlock.length > 5000 && !/fetch\(|XMLHttpRequest|sendBeacon|WebSocket|new Image\(|BroadcastChannel/.test(lj) && !/fetch\(|XMLHttpRequest|sendBeacon|WebSocket|broadcast\(/.test(lvBlock), '내 위치를 어디로도 보내는 코드가 없음(fetch·XHR·sendBeacon·소켓·브로드캐스트 없음)');
    ok(/lsSet\(K_LV/.test(lvBlock) && !/lsSet\([^)]*(lat|lng|myPos)/.test(lvBlock) && !/"lat"/.test(JSON.stringify(new L.Session(A.trip).save())), '저장은 진행 상황(몇 번째 장·도착 시각)뿐, 위치 좌표는 저장 안 함');
    ok(/watchPosition/.test(lvBlock) && /enableHighAccuracy: true/.test(lvBlock) && /maximumAge: 2000/.test(lvBlock) && /clearWatch/.test(lvBlock) && /wakeLock\.request\('screen'\)/.test(lvBlock) && /'wakeLock' in navigator/.test(lvBlock) && /visibilitychange/.test(lvBlock), '위치(고정밀·최근 값) 감시 · 화면 켜 두기(없으면 안내) · 끝낼 때 해제');
    ok(/id="lvAsk"/.test(hh) && /이 폰 안에서만/.test(hh) && /어디로도 보내지 않아요/.test(hh) && /몇 번째 장까지 갔는지/.test(hh) && /id="lvAskSim"/.test(hh) && /실제 위치 안내는 공개 주소에서/.test(hh), '위치 허락 전 안내 창: 이 폰 안에서만 · 보내지 않음 · 저장은 진행뿐 · 가상 이동 · 묶음 안내 글');
    ok(/window\.TOUR_BUNDLE=true/.test(bj) && /lvGpsOk\(\) \{ return !BUNDLE/.test(lvBlock) && /\$\('lvAskGps'\)\.hidden = !lvGpsOk\(\)/.test(lvBlock), '폰 한 파일(묶음)에서는 실제 위치 시작을 숨기고 가상 이동만');
    ok(/speechSynthesis/.test(lvBlock) && /not-allowed/.test(lvBlock) && /소리가 안 나면 아래 단추를 눌러 주세요/.test(lvBlock) && /data-lv="listen"/.test(lvBlock), '소리 자동 재생이 막히면 "이야기 듣기" 단추로 안내');
    ok(/\.lv-btn\{[^}]*min-height:56px/.test(cc) && /\.lv-fix\{[^}]*min-height:56px/.test(cc) && /\.lv-pill\{[^}]*min-height:48px/.test(cc) && /\.lv-handle\{[^}]*min-height:44px/.test(cc) && /\.kmap\{[^}]*min-height:48px/.test(cc), '큰 단추: 길안내·고치기 56px · 위 알약 48px · 손잡이 44px · 게시물 길안내 48px');
    ok(/safe-b/.test(cc.slice(cc.indexOf('.lv-sheet{'), cc.indexOf('.lv-sheet.full'))) && /safe-t/.test(cc.slice(cc.indexOf('.lv-top{'), cc.indexOf('.lv-pill{'))), '아래 창은 홈 표시줄(safe-b) 위로, 위 단추는 노치(safe-t) 아래로');
    ok(/id="liveBtn"/.test(hh) && /data-live="'/.test(aj) && /이 날 여행 길안내/.test(aj) && /카카오맵으로 길안내/.test(lj) && /kmapHtml\(s\)/.test(aj), '코스 위 "여행 길안내" · 날마다 "이 날 여행 길안내" · 게시물마다 카카오맵 길안내');
    ok(!/KakaoAK|kakao_rest|datagokr_key/.test(lj + lvBlock), '새 코드에 키 이름·값 없음'); }
}

console.log('\n[29] 시작 화면 단계 마법사 (2026-10-17) — 인사(사진) · 올 때 · 돌아갈 때 · 누구와');
{ const hh = fs.readFileSync(require('path').join(__dirname, 'index.html'), 'utf8'), aj = fs.readFileSync(require('path').join(__dirname, 'app.js'), 'utf8'), cc = fs.readFileSync(require('path').join(__dirname, 'style.css'), 'utf8'), bj = fs.readFileSync(require('path').join(__dirname, '묶음.mjs'), 'utf8');
  const sky = D.places.find((p) => p.id === 'skyvalley');
  ok(sky && sky.photoType === 'Type1' && /\.jpg$/.test(sky.photo) && /licNo\(p\) === 1/.test(aj.slice(aj.indexOf('function initHero'))), '첫 화면 대표 사진 = 공공누리 제1유형만 쓰고(자르기 가능) 아니면 슬라이드에서 뺌(그림 바탕)');
  ok(/id="heroCredit"/.test(hh) && /creditText\(p\)/.test(aj) && /object-fit:cover/.test(cc.slice(cc.indexOf('.hs img{'), cc.indexOf('.hs img{') + 200)), '사진마다 출처(제1유형) 줄 · 꽉 채워 보이기');
  ['st0', 'st1', 'st2', 'st3'].forEach((id) => ok(new RegExp('id="' + id + '" data-st="' + id[2] + '"').test(hh), '단계 칸 ' + id));
  ok(hh.indexOf('id="st1"') < hh.indexOf('id="st2"') && hh.indexOf('id="st2"') < hh.indexOf('id="st3"'), '순서: 올 때 → 돌아갈 때 → 누구와');
  ['wx', 'wxIc', 'wxMain', 'wxSub', 'wxHint', 'wxSrc', 'sDate', 'sTime', 'bDate', 'bTime', 'bTimeLb', 'howSeg', 'bhowSeg', 'outBody', 'inBadges', 'outBadges', 'inNote', 'chipComp', 'moreBox', 'chipMore', 'startNote', 'goVoice', 'ticketFile', 'makeCourse', 'runDemo', 'runDemoMeal', 'runDemoDay', 'runDemoTour', 'runDemo1bak', 'stepMsg', 'stBack1', 'stBack2', 'stBack3', 'goStart', 'stNext1', 'stNext2'].forEach((id) => { if (!new RegExp('id="' + id + '"').test(hh)) ok(false, 'id 없음: ' + id); });
  ok(true, '기존 id(날씨·날짜·시각·이동수단·동행·더 고르기·말로/사진·예시·코스 짜기) 모두 그대로');
  ok(hh.indexOf('id="makeCourse"') > hh.indexOf('id="st3"') && /data-how="train"/.test(hh) && /data-bhow="car"/.test(hh) && !/id="demoBox"/.test(hh), '코스 짜기 단추는 마지막 단계 · 예시 줄글 목록(demoBox)은 사진 카드로 바뀜');
  ok(/class="st-bar"/.test(hh) && /aria-label="이전"/.test(hh) && /role="progressbar"/.test(hh) && /class="st-count"/.test(hh), '단계 위: ← 이전 단추 + 진행 막대 + 1/3');
  ok(/function setStep\(/.test(aj) && /S\.step = n/.test(aj) && /h\.focus\(\{ preventScroll: true \}\)/.test(aj) && /S\.nextStep = 3/.test(aj), '단계는 JS(S.step) · 단계 바뀌면 제목으로 초점 · 말로/기차표는 3단계로');
  ok(/function backEarly\(/.test(aj) && /function stepBlock\(/.test(aj) && /stNext2'\)\.addEventListener\('click', function \(\) \{ if \(stepBlock\(\)\)/.test(aj) && /role="alert"/.test(hh), '돌아갈 시각이 오는 시각보다 빠르면 3단계로 못 감 + 알림');
  ok(/\.st-foot\{[^}]*position:sticky;[^}]*bottom:0/.test(cc) && /safe-b/.test(cc.slice(cc.indexOf('.st-foot{'), cc.indexOf('.st-foot{') + 250)) && /#st1,#st2,#st3\{[^}]*--qa:var\(--wz\)/.test(cc) && !/#c4471d|#6b46c1/.test(cc), '아래 단추는 늘 보임(sticky·safe-b) · 세 단계가 같은 보라(--wz) 하나 — 단계마다 다른 경고색 없음');
  ok(/prefers-reduced-motion:reduce\)\{[^}]*\.st\.enter\{ animation:none/.test(cc) && /dvh/.test(cc.slice(cc.indexOf('.hero{'), cc.indexOf('.hero{') + 200)), '움직임 줄이기 설정 존중 · 사진 높이 dvh');
  ok(/#demo|'demo'/.test(aj) && /if \(h === 'demo'\) runDemo\('normal'\)/.test(aj), '#demo 주소 예시는 그대로 코스로 바로 감');
  ok(/사진캐시/.test(bj) && D.places.filter((p) => p.photo).every((p) => /^사진캐시\//.test(p.photo)), '묶음: 큰 사진도 places.js 의 사진 경로라서 data URI 로 들어감');
}

console.log('\n[30] 코스 한 그림 · 접힌 일정 · 동네 탭 · 시티투어 안내 (2026-10-17)');
{ const path = require('path'), OV = require('./ov.js'), TW = require('./town.js'), E = require('./editor.js'); require('./citytour.js'); const CT = globalThis.CITYTOUR;
  const rd = (f) => fs.readFileSync(path.join(__dirname, f), 'utf8'), aj = rd('app.js'), hh = rd('index.html'), cc = rd('style.css'), oj = rd('ov.js'), tj = rd('town.js');
  const OD = { now: T('13:00'), train: T('18:10'), how: 'train', backHow: 'train', start: 'mukho', end: 'mukho', slow: false, avoidStairs: false, interests: [], date: '2026-10-24', rain: false };
  const one = P.plan(D, OD), MD = { ...OD, now: T('10:00'), train: T('15:48'), backDate: '2026-10-25', slow: false }, multi = P.planDays(D, MD);
  // 1) 한 그림: 번호 · 날짜별 색 · 범례
  const m1 = OV.model(one), m2 = OV.model(multi);
  ok(m1.nDays === 1 && OV.stopCount(m1) === one.stops.length && m1.legs.length >= one.stops.length, `하루 코스: 번호 ${OV.stopCount(m1)}곳 · 선 ${m1.legs.length}개`);
  ok(m2.nDays === multi.days.length && m2.nDays > 1 && OV.stopCount(m2) >= multi.days.reduce((s, d) => s + d.plan.stops.length, 0), `여러 날: 번호가 날을 넘어 이어짐 (${OV.stopCount(m2)}곳)`);
  const colors = [0, 1, 2].map((d) => OV.dayColor(d, 3)); ok(new Set(colors).size === 3, '날 3개 색이 서로 다름: ' + colors.join(' '));
  ok(/1일/.test(OV.legendHtml(m2)) && /2일/.test(OV.legendHtml(m2)) && !/2일/.test(OV.legendHtml(m1)), '범례: 여러 날만 "1일 · 2일" 작게');
  const nums = m2.nodes.filter((n) => n.kind === 'stop').map((n) => n.n); ok(nums.every((n, i) => n === i + 1), '번호는 1부터 빈틈없이 순서대로');
  // 2) 구간 확대 경계 · 겹침 펼침
  const f2 = OV.frame(m2, (globalThis.ROUTES && globalThis.ROUTES.maps) || []);
  ok(m2.legs.length > 0 && m2.legs.every((l) => { const c = OV.legCam(l, f2), n0 = m2.nodes[l.from], n1 = m2.nodes[l.to]; return [n0, n1].every((n) => { const q = f2.proj(n.lat, n.lng); return q.x >= c.cx - c.w / 2 - 1 && q.x <= c.cx + c.w / 2 + 1 && q.y >= c.cy - c.h / 2 - 1 && q.y <= c.cy + c.h / 2 + 1; }); }), '구간 확대: 모든 구간의 시작·끝이 확대 화면 안에 들어옴');
  const fakeM = { marks: [0, 1, 2, 3, 4].map((i) => ({ kind: 'stop', label: String(i + 1), lat: 37.55 + i * 1e-6, lng: 129.11 + i * 1e-6 })).concat([{ kind: 'stop', label: '6', lat: 37.6, lng: 129.2 }]) };
  const lay = OV.layoutMarks(fakeM, f2, 28), shown = lay.filter((x) => !x.hidden);
  ok(shown.length === 2 && lay[0].merged && lay[0].label === '1 외 4' && lay.slice(1, 5).every((x) => x.hidden) && lay[5].moved === false && !lay[5].merged, `겹친 번호 5개는 한 표시("${lay[0].label}")로 합침 · 떨어진 건 그대로 (부채꼴로 펼치지 않음)`);
  const fake3 = { marks: [0, 1, 2].map((i) => ({ kind: 'stop', label: String(i + 5), lat: 37.55 + i * 1e-6, lng: 129.11 + i * 1e-6 })) }, l3 = OV.layoutMarks(fake3, f2, 28);
  ok(l3[0].merged && l3[0].label === '5·6·7' && l3[1].hidden && l3[2].hidden && l3[0].members.join() === '0,1,2', '3개 이상 겹치면 "5·6·7" 한 표시');
  const fake2 = { marks: [0, 1].map((i) => ({ kind: 'stop', label: String(i + 1), lat: 37.55 + i * 1e-6, lng: 129.11 + i * 1e-6 })) }, l2 = OV.layoutMarks(fake2, f2, 28), uu = 28 / 30;
  ok(l2.every((x) => !x.hidden && !x.merged && x.moved && Math.hypot(x.x - x.tx, x.y - x.ty) <= 24 * uu + 0.01) && Math.hypot(l2[0].x - l2[1].x, l2[0].y - l2[1].y) >= 33 * uu, `겹친 번호 2개는 살짝(최대 24px)만 비켜 서고 서로 ${Math.round(Math.hypot(l2[0].x - l2[1].x, l2[0].y - l2[1].y) / uu)}px 떨어짐`);
  // 3) 그날 주요사항
  const ctx = (date, o) => ({ P, CT, date, marketDigits: [3, 8], marketName: '북평장', rain: false, wx: null, isToday: false, sunrise: null, ...o });
  ok(OV.todayNotes(ctx('2026-10-23')).some((n) => n.k === 'market') && !OV.todayNotes(ctx('2026-10-24')).some((n) => n.k === 'market'), '3·8일 끝나는 날만 "북평장 장날"');
  ok(OV.todayNotes(ctx('2026-10-24')).some((n) => n.k === 'tour' && /다녀요/.test(n.text)) && OV.todayNotes(ctx('2026-10-21')).some((n) => n.k === 'tour' && /쉬어요/.test(n.text)), '시티투어: 토요일 운행 · 수요일 쉬어요');
  ok(OV.todayNotes(ctx('2026-10-24', { rain: true }))[0].k === 'rain' && OV.todayNotes(ctx('2026-10-24', { sunrise: { min: 6 * 60 + 40 } })).some((n) => n.k === 'sun' && /확인필요/.test(n.text)), '비 소식이 맨 앞 · 일출은 "어림값, 확인필요"');
  ok(OV.todayNotes(ctx('2026-10-24')).filter((n) => n.k === 'tour').every((n) => !/^시티투어는 미리 예약하세요/.test(n.text) && n.note === '시티투어는 미리 예약하세요' && /^시티투어 /.test(n.short)), '주요사항 줄은 그 날의 사실이 먼저("시티투어 운행"), 예약 안내는 작은 따로 줄(note)로');
  { const nn = OV.todayNotes(ctx('2026-10-23', { sunrise: { min: 6 * 60 + 41 } })); ok(nn.map((n) => n.short).join(' · ') === '북평장 장날 · 시티투어 쉬는 날 · 일출 06:41(어림)' || nn.map((n) => n.short).join(' · ') === '북평장 장날 · 시티투어 운행 · 일출 06:41(어림)', '한 줄: ' + nn.map((n) => n.short).join(' · ')); }
  // 4) 시티투어 예약 안내: 모든 곳에서 같은 말 + 있는 사실 + 공식 사이트 링크
  const rs = OV.reserveHtml(CT, true), tt = OV.ttHtml(CT, P, { date: '2026-10-24', today: false, run: 0, board: 0, alight: 3, dep: 600, arr: 640, boardName: '묵호역', alightName: '논골담길' }), tab = OV.ttTabHtml(CT, P, [], '2026-10-24');
  [['한 줄 안내', rs], ['시간표 창', tt], ['동네 시티투어', tab]].forEach(([n, h]) => ok(/시티투어는 미리 예약하세요/.test(h) && /만석이면/.test(h) && /href="https:\/\/dcitybus\.com\/?"[^>]*target="_blank"/.test(h) && /예약 안내 보기/.test(h), n + ': 예약 문구 + 만석 안내 + 예약 안내 보기(dcitybus.com, 새 탭)'));
  ok(/OV\.reserveHtml\(CT, true\)/.test(aj) && /OV\.reserveHtml\(CT, false\)/.test(aj) && /id="tourRsv"/.test(hh), '코스 줄·글 · 코스 위 안내에 모두 붙음');
  ok(!/tel:|0\d{1,2}-\d{3,4}-\d{4}/.test(rs), '예약 안내에 전화번호를 지어 넣지 않음');
  // 5) 시티투어 시간표 창
  const ttOff = OV.ttHtml(CT, P, { date: '2026-10-21', today: true, run: 0, board: 0, alight: 3, dep: 600, arr: 640, boardName: '묵호역', alightName: '논골담길' });
  ok(/오늘은 운행하지 않아요/.test(ttOff) && /다음 운행: \d+\/\d+\(토\)/.test(ttOff), '시간표 창: 쉬는 날은 "오늘은 운행하지 않아요 · 다음 운행: ○/○(토)"');
  // 6) 동네 탭
  const cnt = TW.counts();
  const TD = require('./town.data.js'), csvT = fs.readFileSync(path.join(__dirname, '..', '..', '자료', '공공데이터', '강원특별자치도_동해시_음식점현황_20260324_utf8.csv'), 'utf8'), csvRecs = csvT.match(/^[^,\r\n]+,\d{4}-\d{2}-\d{2},.*$/gm) || [], isBad = (t) => [...t].some((ch) => { const c = ch.codePointAt(0); return c === 0xFFFD || (c < 32 && c !== 9 && c !== 10 && c !== 13) || (c >= 127 && c <= 159) || (c >= 0x2500 && c <= 0x257F); }), csvBad = csvRecs.filter(isBad).length;
  ok(cnt.eats === TD.eats.length && cnt.lodging === TD.lodging.length && cnt.eats > 1000 && cnt.lodging === 19, `식당 ${cnt.eats}곳(자료 그대로) · 숙소 ${cnt.lodging}곳`);
  ok(TD.eats.length + csvBad === csvRecs.length, `CSV ${csvRecs.length}줄 = 화면 ${TD.eats.length}곳 + 깨진 글자로 뺀 ${csvBad}곳 (빠진 곳 없음)`);
  ok(['묵호', '발한', '천곡', '송정', '북평'].every((a) => TW.areas('eat').some((x) => x.area === a)) && TW.areas('lodge').some((x) => x.area === '망상'), '동네 묶음: 묵호·발한·천곡·송정·북평(식당) · 망상(숙소)');
  ok(TW.areas('eat').reduce((s, a) => s + a.n, 0) === cnt.eats && TW.areas('lodge').reduce((s, a) => s + a.n, 0) === cnt.lodging, '동네별 합이 전체와 같음(빠진 곳 없음)');
  const q1 = TW.query('eat', '', '물회'), q2 = TW.query('eat', '묵호', '물회');
  ok(q1.length > 0 && q2.length <= q1.length && q2.every((x) => x.area === '묵호' && /물회/.test(x.name + x.type + x.addr + x.dong)), `찾기: "물회" ${q1.length}곳 · 묵호만 ${q2.length}곳`);
  ok(TW.page(TW.list('eat'), 1).length === 30 && TW.page(TW.list('eat'), 2).length === 60 && TW.page([1, 2, 3], 1).length === 3, '30개씩 끊어 보기 + 더 보기');
  ok(/^https:\/\/map\.kakao\.com\/link\/search\//.test(TW.kakaoSearch('묵호 물회 집')) && !/appkey|KakaoAK|[?&]key=/i.test(tj + TW.kakaoSearch('가나다')), '카카오맵 찾기 링크(키 없음)');
  ok(/기준 2026-03-24/.test(TW.src.eats) && /기준 2025-11-04/.test(TW.src.lodging) && /id="townSrc"/.test(hh), '출처 · 기준일 줄');
  // 7) 코스에 넣기: 알맞으면 넣고 마감을 넘으면 이유를 말하고 안 바꿈
  const withPos = TW.list('eat').filter(TW.hasPos), noPos = TW.list('eat').filter((x) => !TW.hasPos(x));
  ok(withPos.length > 0 && noPos.length > 0 && noPos.length < withPos.length, `좌표가 있는 식당 ${withPos.length}곳만 넣을 수 있음 · 나머지 ${noPos.length}곳은 "위치 정보가 없어 넣을 수 없어요"`);
  ok(/위치 정보가 없어 넣을 수 없어요/.test(aj) && /class="tw-nopos">위치 정보 없음</.test(aj) && /noPos \? '<span class="tw-nopos">/.test(aj) && /\.tw-why\{[^}]*var\(--muted\)/.test(cc) && !/\.tw-why\{[^}]*var\(--warn\)/.test(cc), '좌표 없는 식당은 단추 대신 작은 "위치 정보 없음" 표시 · 이유 글은 흐린 색(주황 아님)');
  { const frame = P.plan(D, OD), env = { D, o: OD, frame }, spec = E.fromPlan(frame); let fit = 0, refused = 0, bad = 0, tried = 0;
    withPos.slice(0, 40).forEach((x) => { const p = { id: 'eat_t' + x.key.slice(1), short: x.name.slice(0, 8), name: x.name, lat: x.lat, lng: x.lng, visit: 50, indoor: true, stairs: false, slope: false, stairsKnown: false, kind: 'meal', tags: ['먹거리'], value: 0, openText: '', open: [0, 1440] }; D.places.push(p); tried++;
      let b = null; try { b = E.bestInsert(env, spec, 0, p.id, 12 * 60 + 30); } catch (e) { bad++; }
      D.places.pop(); if (!b || b.r.blocked) { refused++; return; }
      fit++; if (b.r.back && b.r.back.arrive > frame.train - 15) bad++; });
    ok(bad === 0 && fit + refused === tried && fit > 0, `넣기 시험 ${tried}곳: 들어감 ${fit} · 거절 ${refused} · 기차 15분 전을 어긴 코스 ${bad}건`); }
  // 8) 코드 검사: 머리글 소리 단추 · 이름 바꿈 · 아래 메뉴 · 접힌 일정
  ok(/id="muteBtn"[^>]*aria-pressed/.test(hh) && /자동 음성 (끄기|켜기)/.test(aj + hh) && hh.indexOf('id="muteBtn"') < hh.indexOf('id="s-start"') && hh.indexOf('id="muteBtn"') > hh.indexOf('<header') && !/id="muteBtn"/.test(hh.slice(hh.indexOf('id="s-course"'), hh.indexOf('id="s-map"'))), '자동 음성 단추: 맨 위 머리글 · aria-pressed · 끄기/켜기 이름');
  ok(!/여행 시작/.test(hh + aj) && !/비가 와요/.test(hh + aj + oj) && />여행 길안내</.test(hh) && />날씨가 안 좋아요</.test(hh) && />코스 고치기</.test(hh) && /이 날 여행 길안내/.test(aj) && /id="lvAskT">여행 길안내</.test(hh), '이름 바꿈: 여행 길안내 · 이 날 여행 길안내 · 날씨가 안 좋아요 (코스 고치기 그대로)');
  ok(!/머물기/.test(hh) && /<span>홈<\/span>/.test(hh) && /<span>지도<\/span>/.test(hh) && /<span>동네<\/span>/.test(hh) && /<span>기록<\/span>/.test(hh) && /data-tk="eat"/.test(hh) && /data-tk="lodge"/.test(hh) && /data-tk="tour"/.test(hh), '아래 메뉴: 홈 · 지도 · 제보 · 동네 · 기록 (머물기 없음) · 동네 안: 식당/숙소/시티투어');
  ok(/id="stayDet"/.test(hh) && /더 머물면\?/.test(hh) && /renderStay/.test(aj), '머물기의 막차·하룻밤 비교는 코스 고치기 안 "더 머물면?"으로 옮김');
  ok(/class="p-head p-tog"/.test(aj) && /aria-expanded="' \+ \(open \? 'true' : 'false'\) \+ '" aria-controls="pb-/.test(aj) && /class="p-body" id="pb-' \+ i \+ '"' \+ \(isOpen \? '' : ' hidden'\)/.test(aj) && /function foldOpen\(/.test(aj) && /foldOpen\(e\.node\.id/.test(aj), '일정 한 줄은 버튼(aria-expanded) · 본문은 처음엔 접힘(열림은 S.openFold 에서 되살림) · 길안내 도착 장은 열어 둠');
  ok(/\.p-tog\{[^}]*min-height:6\d?px/.test(cc), '접힌 줄 높이 60px 이상(터치)');
  ok(!/(KakaoAK|kakao_rest|datagokr|rest_api_key)/i.test(oj + tj + rd('town.data.js')) && !/fetch\(/.test(oj + tj), '새 파일에 키 이름·값·바깥 요청 없음');

  console.log('[31] 고침 2 (2026-10-17) — 하루 단위 전체 그림 · 합친 번호 · 날짜 탭 위치 · 깨진 글자 막이 · 동네 순서');
  // (a) 날마다 그림: 고른 날의 점·선만으로 맞춤
  { const maps = (globalThis.ROUTES && globalThis.ROUTES.maps) || [], vAll = OV.dayView(m2, -1), fAll = OV.frame(m2, maps, vAll), cAll = OV.homeCam(m2, fAll, vAll);
    const inCam = (f, c, lat, lng) => { const q = f.proj(lat, lng); return q.x >= c.cx - c.w / 2 - 1 && q.x <= c.cx + c.w / 2 + 1 && q.y >= c.cy - c.h / 2 - 1 && q.y <= c.cy + c.h / 2 + 1; };
    let allOk = true, narrower = 0, onlyDay = true, msg = [];
    for (let d = 0; d < m2.nDays; d++) {
      const v = OV.dayView(m2, d), f = OV.frame(m2, maps, v), c = OV.homeCam(m2, f, v);
      const dayStops = m2.marks.filter((mk, i) => mk.kind === 'stop' && v.vis[i]);
      if (!dayStops.length || dayStops.some((mk) => mk.day !== d)) onlyDay = false;
      if (!dayStops.every((mk) => inCam(f, c, mk.lat, mk.lng)) || !v.legs.every((l) => l.path.every((q) => inCam(f, c, q[1], q[0])))) allOk = false;
      if (c.w < f.W - 1) narrower++;
      msg.push(`${d + 1}일차 번호 ${dayStops.length}곳 · 확대 ${c.z.toFixed(1)}배`);
    }
    ok(onlyDay, '날마다 그림: 고른 날의 번호만 보임 (다른 날 번호 0개)');
    ok(allOk, '날마다 그림: 그 날의 모든 번호·선이 처음 카메라 안에 들어옴 — ' + msg.join(' · '));
    ok(narrower === m2.nDays && cAll.w <= fAll.W, `날마다 그림은 모두 그림 폭보다 좁게 꽉 차게 맞춤(${narrower}/${m2.nDays})`);
    const v0 = OV.dayView(m2, 0), f0 = OV.frame(m2, maps, v0), lay0 = OV.layoutMarks(m2, f0, 30, { visible: v0.vis, labels: v0.labels });
    ok(lay0.every((x, i) => x.hidden === !v0.vis[i] || x.mergedInto != null) && lay0.every((x) => x.hidden || Math.hypot(x.x - x.tx, x.y - x.ty) <= 64 + 0.01), '겹침 정리: 안 보이는 날은 그리지 않고, 어떤 표시도 진짜 자리에서 64px(알약) · 24px(번호) 넘게 안 옮김(고리·부채꼴 없음)');
    ok(lay0.filter((x) => x.moved && !x.hidden).every((x) => Math.hypot(x.x - x.tx, x.y - x.ty) <= 24 + 0.01 || m2.marks[x.i].kind === 'st'), '번호는 살짝(24px)만 비켜 섬');
    const tl = OV.timeline(m2, 14000, false, OV.dayView(m2, 1));
    ok(tl.segs.length > 0 && tl.segs.filter((s2) => s2.type === 'move').every((s2) => s2.leg.day === 1) && OV.dayView(m2, 1).nodes.every((nd) => nd.day === 1 || m2.legs.some((l) => l.day === 1 && l.from === nd.i)), '미리 보기는 고른 날(2일차)의 선만 따라감');
  }
  // (b) 화면 짜임: 날짜 탭이 지도 위 · 일정 줄 한 줄 · 3칸 줄
  ok(hh.indexOf('id="dayTabs"') > hh.indexOf('id="s-course"') && hh.indexOf('id="dayTabs"') < hh.indexOf('id="ov"'), '날짜 탭(1일차·2일차)이 코스 그림(지도) 위에 있음');
  ok(/\.quiet-row\{[^}]*grid-template-columns:1fr 1fr 1fr/.test(cc) && /\.quiet-row \.chip\{[^}]*font-size:\.88em[^}]*white-space:normal/.test(cc), '여행 길안내 · 코스 고치기 · 날씨가 안 좋아요: 같은 폭 3칸, 글자 .88em, 칸 안에서 줄바꿈');
  ok(/id="courseNote"/.test(hh) && /\.cn-b\{[^}]*font-size:\.82em[^}]*color:var\(--muted\)/.test(cc) && /\.cn-t\{[^}]*text-overflow:ellipsis/.test(cc) && /aria-controls="cnList"/.test(aj) && !/strip[^;]*notes\.concat/.test(aj), '코스 조건 안내는 작고 흐린 한 줄(.82em) · 눌러서 펼침 · 노란 상자 아님');
  ok(/class="ovn-t">' \+ esc\(notes\.map\(function \(n\) \{ return n\.short;/.test(aj) && /ovn-rsv/.test(aj), '주요사항 한 줄은 짧은 사실을 이어 붙임 · 펼치면 시티투어 항목 밑에 예약 안내가 작게');
  // (c) 깨진 글자 막이: 화면·묶음 어디에도 U+FFFD 없음
  { const BADC = String.fromCharCode(0xFFFD), srcs = fs.readdirSync(__dirname).filter((f) => /\.(js|html|css|mjs|json)$/.test(f)), hit = srcs.filter((f) => fs.readFileSync(path.join(__dirname, f), 'utf8').includes(BADC));
    ok(hit.length === 0, `데모 파일 ${srcs.length}개에 깨진 글자(U+FFFD) 0개` + (hit.length ? ': ' + hit.join(', ') : ''));
    ok(!TD.eats.some((r) => isBad(r.join('|'))) && !TD.lodging.some((r) => isBad(r.join('|'))), '동네 자료 줄에 깨진·제어·상자 글자 0줄');
    const out = path.join(require('os').tmpdir(), 'dokkaebi-fix2-test.html'), cp = require('child_process').spawnSync(process.execPath, [path.join(__dirname, '묶음.mjs'), out], { encoding: 'utf8', timeout: 120000 });
    let bundle = ''; try { bundle = fs.readFileSync(out, 'utf8'); } catch (e) { /* 없음 */ }
    ok(cp.status === 0 && bundle.length > 1e6 && !bundle.includes(BADC) && Buffer.byteLength(bundle) < 16e6, `묶음 만들기 통과 · 깨진 글자 0개 · ${(Buffer.byteLength(bundle) / 1e6).toFixed(1)}MB (<16MB)`);
    try { fs.unlinkSync(out); } catch (e) { /* 무시 */ }
    ok(/FFFD/.test(rd('묶음.mjs')) && /unlinkSync\(OUT\)/.test(rd('묶음.mjs').slice(rd('묶음.mjs').indexOf('FFFD'))), '묶음.mjs 가 깨진 글자를 발견하면 파일을 지우고 중단하게 되어 있음');
    ok(/깨진 글자 줄 제외/.test(rd('동네수집.mjs')) && /0xFFFD/.test(rd('동네수집.mjs')) && /0x2500/.test(rd('동네수집.mjs')), '동네수집.mjs 가 깨진·제어·상자 글자 줄을 빼고 개수를 찍음');
  }
  // (d) 동네 목록 순서: 좌표 있는 곳 먼저 → 한글 이름 → 숫자·영문
  { const L = TW.list('eat'), firstNo = L.findIndex((x) => !TW.hasPos(x)), noPosL = L.slice(firstNo), cls = (x) => TW.nameClass(x.name);
    ok(firstNo > 0 && L.slice(0, firstNo).every(TW.hasPos) && noPosL.every((x) => !TW.hasPos(x)), `좌표 있는 ${firstNo}곳이 맨 앞`);
    const sortedBy = (arr) => arr.every((x, i) => i === 0 || cls(arr[i - 1]) < cls(x) || (cls(arr[i - 1]) === cls(x) && arr[i - 1].name <= x.name));
    ok(sortedBy(L.slice(0, firstNo)) && sortedBy(noPosL), '각 무리 안에서 한글 이름 → 영문 → 숫자 순, 같은 무리는 가나다순');
    ok(cls(L[0]) === 0 && L.slice(0, 30).every((x) => cls(x) === 0), '첫 30곳은 모두 한글 이름');
    ok(!L.slice(0, 60).some((x) => /^[0-9]/.test(x.name)), '"8283" 같은 숫자 이름이 맨 앞에 안 나옴');
    ok(L.map((x) => x.key).sort().join() === TW.list('eat').map((x) => x.key).sort().join() && new Set(L.map((x) => x.key)).size === L.length, '줄 번호(key)는 그대로·중복 없음');
  }
}

// [32] 최종 점검 고침 (2026-10-18) — 서버 검증·허용 목록 · 자가용 둘째 날 · 동네 되돌림 · 공휴일 확인필요 · 출처 · 지난 날짜 · 공공누리 기록 카드
{
  console.log('\n[32] 최종 점검 고침 (2026-10-18)');
  const path = require('path'), cp = require('child_process'), rd = (f) => fs.readFileSync(path.join(__dirname, f), 'utf8'), RUN = path.join(__dirname, '..', '..', 'run');
  const app = rd('app.js'), css = rd('style.css'), html = rd('index.html'), readme = rd('README.md'), trainsSrc = fs.readFileSync(path.join(RUN, 'trains.mjs'), 'utf8'), serveSrc = fs.readFileSync(path.join(RUN, 'serve.mjs'), 'utf8');
  // (1)(10) /api/trains 검증 + 허용 목록 + 속도 제한 — 실제 서버를 다른 포트(8793)로 띄워 확인(상류 호출 없음)
  {
    const code = `
      import { getTrains, validDate } from ${JSON.stringify(require('url').pathToFileURL(path.join(RUN, 'trains.mjs')).href)};
      import { spawn } from 'node:child_process';
      const k = (d) => { const t = new Date(Date.now() + 9 * 3600e3 + d * 86400e3); return t.toISOString().slice(0, 10).replace(/-/g, ''); };
      const out = {};
      out.v = [validDate(k(0)), validDate(k(-1)), validDate(k(30)), validDate(k(-2)), validDate(k(31)), validDate('20261340'), validDate('20260230'), validDate('abc')];
      out.g = [];
      for (const [f, t] of [['constructor', '묵호'], ['묵호', '__proto__'], ['toString', 'hasOwnProperty'], ['묵호', 'valueOf']]) out.g.push((await getTrains(k(1), f, t)).error);
      out.g.push((await getTrains(k(40), '묵호', '청량리')).error);
      const sv = spawn(process.execPath, [${JSON.stringify(path.join(RUN, 'serve.mjs'))}, '8793'], { stdio: 'ignore' });
      await new Promise((r) => setTimeout(r, 900));
      const get = async (u) => (await fetch('http://127.0.0.1:8793' + u, { redirect: 'manual' }));
      const st = {};
      for (const u of ['/tour/', '/tour/app.js', '/tour/style.css', '/tour/README.md', '/tour/test.cjs', '/tour/app.before_fv.js', '/tour/묶음.mjs', '/tour/수집.mjs', '/tour/수집캐시/x.json', '/tour/길캐시/x.json', '/tour_백업_사진전/index.html', '/README.md', '/tour/사진캐시/125673.jpg', '/지도키.js', '/tour/지도그림/묵호.png']) st[u] = (await get(encodeURI(u))).status;
      out.st = st;
      const rr = await get(encodeURI('/tour_백업_사진전')); out.loc = rr.headers.get('location');
      out.c400 = (await get('/api/trains?from=constructor&to=%EB%AC%B5%ED%98%B8&date=' + k(1))).status;
      const codes = []; for (let i = 0; i < 34; i++) codes.push((await get('/api/trains?from=x&to=y&date=1')).status);
      out.limit = codes.filter((c) => c === 429).length;
      sv.kill(); console.log(JSON.stringify(out));`;
    const r = cp.spawnSync(process.execPath, ['--input-type=module', '-e', code], { encoding: 'utf8', timeout: 60000 });
    let o = {}; try { o = JSON.parse(r.stdout.trim().split('\n').pop()); } catch (e) { /* 아래에서 실패 */ }
    ok(JSON.stringify(o.v) === JSON.stringify([true, true, true, false, false, false, false, false]), '날짜: 한국시간 오늘-1 … 오늘+30 의 실제 날짜만 통과 ' + JSON.stringify(o.v));
    ok(o.g && o.g.length === 5 && o.g.every((e) => e === 'bad_request'), 'constructor/__proto__/toString/valueOf 역 이름 · 범위 밖 날짜는 상류 호출 없이 bad_request ' + JSON.stringify(o.g));
    ok(/hasOwnProperty\.call\(o, k\)/.test(trainsSrc) && /5 \* 60e3/.test(trainsSrc), 'trains.mjs: hasOwnProperty 검사 · 실패 5분 캐시');
    ok(o.c400 === 400 && /bad_request' \? 400/.test(serveSrc), '/api/trains 나쁜 요청은 HTTP 400');
    ok(o.limit >= 3 && o.limit <= 5, '/api/* 는 IP 당 분당 30회 넘으면 429 (34번 중 ' + o.limit + '번 거절)');
    const s = o.st || {};
    ok(s['/tour/'] === 200 && s['/tour/app.js'] === 200 && s['/tour/style.css'] === 200 && s['/tour/사진캐시/125673.jpg'] === 200 && s['/지도키.js'] === 200 && s['/tour/지도그림/묵호.png'] === 200, '화면이 쓰는 파일(html·js·css·사진·지도그림·지도키)은 그대로 열림');
    ok(['/tour/README.md', '/tour/test.cjs', '/tour/app.before_fv.js', '/tour/묶음.mjs', '/tour/수집.mjs', '/tour/수집캐시/x.json', '/tour/길캐시/x.json', '/tour_백업_사진전/index.html', '/README.md'].every((u) => s[u] === 404), '내부 자료(README·시험·백업·*.mjs·수집캐시·길캐시·사진전 백업)는 404');
    ok(/^\/tour_%EB%B0%B1/.test(o.loc || ''), '폴더 주소 뒤에 / 붙이는 이동(Location)은 퍼센트 인코딩 ' + o.loc);
    const refs = [...html.matchAll(/(?:src|href)="([^"#:]+\.[a-z0-9]+)"/gi)].map((m) => m[1]).filter((u) => !/^https?:|^data:/.test(u));
    ok(refs.length >= 10 && refs.every((u) => /\.(js|css|png|jpg|svg|ico)$/i.test(u)), 'index.html 이 부르는 파일 ' + refs.length + '개 모두 허용 확장자');
  }
  // (2) 자가용 오고 가고 + 일출: 둘째 날 새벽 이동(숙소→추암)과 아침 가게도 자가용
  {
    const M = { date: '2026-10-24', now: T('10:00'), how: 'car', backHow: 'car', start: 'park', end: 'park', interests: [], couple: true, tour: true, sunrise: true, backDate: '2026-10-25', train: T('15:00') };
    const pc = P.planDays(D, M), d2 = pc.days[1], pt = P.planDays(D, { ...M, how: 'train', backHow: 'train', start: 'mukho', end: 'mukho' }), t2 = pt.days[1];
    ok(d2.sunrise && !/택시/.test(d2.sunrise.moveText) && /자가용/.test(d2.sunrise.moveText), '자가용 1박2일: 숙소→추암 일출 이동은 자가용 · ' + (d2.sunrise && d2.sunrise.moveText));
    ok(!d2.breakfast || d2.breakfast.place.slot || (!/택시/.test(d2.breakfast.moveText) && /자가용|걸어서/.test(d2.breakfast.moveText)), '자가용 1박2일: 아침은 식당이 아니라 시간 슬롯(이동 없음) · ' + (d2.breakfast && d2.breakfast.id));
    ok(!d2.plan.stops.some((s) => /택시/.test(s.moveText || '')), '자가용 1박2일 둘째 날 어디에도 "택시" 글이 없음');
    ok(t2.sunrise && /택시/.test(t2.sunrise.moveText), '기차로 온 1박2일은 예전대로 택시(회귀 없음)');
  }
  // (3) 동네 "코스에 넣기" 거절: edStart 가 건드린 것을 모두 되돌림
  {
    const i0 = app.indexOf('function townAdd('), body = app.slice(i0, app.indexOf('function tripLate(', i0));
    ok(!/edStart\(|bestInsert|pickedFor/.test(body) && /townLodge\(x\)/.test(body) && /x\.kind !== 'lodge'/.test(app.slice(app.indexOf('function townAddState('), app.indexOf('function townSay('))), 'townAdd: 숙소만 — 식당을 한 끼로 끼워 넣는 코드(edStart·bestInsert)가 없고, 식당은 "코스에 넣기"가 꺼져 있음');
    ok(/S\.stayPick = prev; replan\(\{ noHighlight: true \}\); townSay\(/.test(app), '숙소를 쓰면 마감을 못 지킬 때 이전 숙소로 되돌리고 이유를 말함(코스는 그대로)');
  }
  // (4) 숙소 바꾸기: 곳 수·가능 여부 비교
  {
    const a = app.slice(app.indexOf('function tripStat('), app.indexOf('function townLodge(')), f = new Function(a + '; return { tripStat: tripStat, lodgeImpact: lodgeImpact };')();
    const st = (n, f2, late) => ({ n: n, f: f2, late: late || 0 });
    ok(f.lodgeImpact([st(5, true)], [st(5, true)]) === null, '숙소 영향 없음 → 알림 없음');
    const r1 = f.lodgeImpact([st(5, true), st(6, true)], [st(5, true), st(4, true)]);
    ok(r1 && !r1.revert && /2일차 코스가 6곳에서 4곳으로 줄었어요/.test(r1.msg), '곳이 줄면 알려 줌(적용은 유지) · ' + (r1 && r1.msg));
    const r2 = f.lodgeImpact([st(5, true)], [st(5, false)]);
    ok(r2 && r2.revert && /시간 안에 안 맞아요/.test(r2.msg), '가능하던 하루가 불가능해지면 되돌리고 알림 · ' + (r2 && r2.msg));
    const r3 = f.lodgeImpact([st(5, true), st(5, true)], [st(5, true), st(5, true, 12)]);
    ok(r3 && r3.revert && /2일차에 12분 더 늦어서/.test(r3.msg), '더 늦어지면 되돌리고 알림');
    ok(/var imp = lodgeImpact\(before, tripStat\(S\.plan\)\)/.test(app) && / · ' \+ imp\.msg/.test(app), 'townLodge 가 lodgeImpact 결과를 사용자에게 말함');
  }
  // (5) 공휴일 확인필요
  {
    require('./citytour.js'); const C = globalThis.CITYTOUR, OVx = require('./ov.js'), hol = C.holidays.list.find((h) => { const w = P.dateInfo(h.date).dow; return w >= 1 && w <= 5 && h.date >= C.period.from && h.date <= C.period.to; });
    const td = P.tourDay(C, hol.date);
    ok(C.holidays.confirmed === false && td.ok && td.unconfirmed && /확인필요/.test(td.why), '평일 공휴일(' + hol.date + ')의 운행 사유에 "확인필요": ' + td.why);
    const notes = OVx.todayNotes({ P: P, CT: C, date: hol.date, marketDigits: [3, 8], marketName: '', rain: false, wx: null, isToday: false, sunrise: null }), tn = notes.find((n) => n.k === 'tour');
    ok(tn && /확인필요/.test(tn.short) && /확인필요/.test(tn.text), '주요사항 한 줄·펼친 글에 공휴일 확인필요: ' + (tn && tn.short));
    const sat = P.tourDay(C, '2026-10-24');
    ok(sat.ok && !sat.unconfirmed && !/확인필요/.test(sat.why), '토요일 운행에는 확인필요가 붙지 않음');
    ok(/d\.unconfirmed \? ' \(공휴일 확인필요\)'/.test(app), '날짜 배지(app.js)에도 공휴일 확인필요');
    const C2 = JSON.parse(JSON.stringify(C)); C2.holidays.confirmed = true; ok(!/확인필요/.test(P.tourDay(C2, hol.date).why), '확인된 목록(confirmed:true)이면 붙지 않음');
  }
  // (6) 저장 그림 출처: 사진이 없으니 지도 출처만
  ok(/'지도: ' \+ \(f\.map \? '카카오' : '좌표만 그린 그림'\) \+ '', 48/.test(app), '코스 그림 PNG 출처는 "지도: 카카오" 만(사진 출처 없음)');
  ok(!/지도: 카카오 · 사진/.test(readme), 'README 도 같은 말');
  // (7) 지난 날짜
  ok(/\$\('sDate'\)\.min = todayIso\(\)/.test(app) && /function pastBlock\(\)/.test(app) && /c\.date < todayIso\(\)/.test(app) && /id="dateMsg"/.test(html), '시작 마법사: 도착 날짜 min=오늘 · 지난 날짜는 막고 안내 문구');
  ok(/\$\('stNext1'\)\.addEventListener\('click', function \(\) \{ if \(pastBlock\(\)\) return;/.test(app) && /function stepBlock\(\) \{[^]*?if \(pastBlock\(\)\) return true;/.test(app), '1단계 다음 · 3단계 가기 모두 지난 날짜 검사');
  ok(/지난 날짜는 고를 수 없어요/.test(app), '지난 날짜 안내 문구(쉬운 말)');
  // (8) 기차 시간표가 늦게 도착하면 코스 머리글 이름표를 고침
  ok(/function refreshLeadSrc\(\)/.test(app) && /S\.tr = r; r\.key = key; r\.date = date; r\.end = end;[^]{0,160}refreshLeadSrc\(\);/.test(app) && /\(예시 시간표\|직접 고른 시간\|코레일 시간표\)/.test(app), '시간표 도착 시 코스 머리글의 (예시/직접/코레일) 표시 갱신');
  // (9) 폴드 겉화면 동네 탭
  ok(/\.town-seg \.chip\{[^}]*white-space:nowrap/.test(css), '동네 탭 3분할 글씨 줄바꿈 없음(nowrap)');
  // (11) 기록 카드: 제3유형 사진 합성 금지
  ok(!/pl\.meal\.place/.test(app.slice(app.indexOf('function cardParts('), app.indexOf('function cardText('))), '기록 카드·저장 그림: 식당 칸·사진 없이 장 목록만(코스에 식당이 없음)');
  ok(/기록 카드와 저장 그림\(PNG\)에는 식당 칸이 없고/.test(readme), 'README 가 같은 결정');
}

console.log('\n[31] 2026-10-18 화면 손질 — 대표 사진 슬라이드 · 마법사 색 · 시각 입력 · 글씨 기본 · 열림 유지 · 지도 식당·숙소 · 끼니 시간');
{ const path = require('path'), rd = (f) => fs.readFileSync(path.join(__dirname, f), 'utf8'), aj = rd('app.js'), hh = rd('index.html'), cc = rd('style.css'), mj = rd('묶음.mjs'), rm = rd('README.md');
  ok((() => { for (const f of ['app.js', 'planner.js', 'editor.js', 'live.js', 'ai.js']) { try { new Function(rd(f)); } catch (e) { return false; } } return true; })(), '화면·계산 스크립트 문법 오류 없음(페이지가 열리자마자 멈추는 일 방지)');
  // (1) 대표 사진 슬라이드
  const heroIds = (aj.match(/var HERO_IDS = \[([^\]]+)\]/) || [, ''])[1].match(/'([a-z0-9_]+)'/g).map((s) => s.replace(/'/g, ''));
  const T1 = ['skyvalley', 'suibyeon', 'mangsang', 'gamchusa', 'byeoryu'];
  ok(T1.every((id) => heroIds.includes(id)) && heroIds.length >= 5 && heroIds.length <= 6, '대표 사진 슬라이드: 5곳(스카이밸리·수변·망상·감추사·별유천지) 이상 ' + heroIds.length + '장: ' + heroIds.join(','));
  ok(heroIds.every((id) => { const p = D.places.find((q) => q.id === id); return p && p.photoType === 'Type1' && /^사진캐시\/.+\.(jpg|png|webp)$/.test(p.photo) && fs.existsSync(path.join(__dirname, p.photo)); }), '슬라이드 사진은 모두 공공누리 제1유형(자르기 가능) · 파일이 있음');
  ok(/licNo\(p\) === 1/.test(aj.slice(aj.indexOf('function initHero'))) && /creditText\(p\)/.test(aj) && /id="heroName"/.test(hh) && /id="heroCredit"/.test(hh) && /id="heroDots"/.test(hh) && /id="heroCount"/.test(hh), '장마다 장소 이름 + "사진: 한국관광공사 · 공공누리 제1유형" · 점 · 1/n 칸');
  ok(/HERO_MS = 4500/.test(aj) && /setInterval\(heroTick, HERO_MS\)/.test(aj) && /document\.hidden/.test(aj.slice(aj.indexOf('function heroTick'), aj.indexOf('function heroTimer'))) && /HS\.touch/.test(aj.slice(aj.indexOf('function heroTick'), aj.indexOf('function heroTimer'))), '4.5초마다 자동 넘김 · 손대는 동안·탭이 가려지면 멈춤');
  ok(/reduceMotion\(\)/.test(aj.slice(aj.indexOf('function heroTick'), aj.indexOf('function initHero'))) && /prefers-reduced-motion:reduce\)\{[^}]*\.hs\{ transition:none/.test(cc), '움직임 줄이기: 자동 안 넘김(점·밀기만) + 전환 없음');
  ok(/pointerdown/.test(aj) && /Math\.abs\(dx\) > 40/.test(aj) && /touch-action:pan-y/.test(cc.slice(cc.indexOf('.hero-slides{'), cc.indexOf('.hero-slides{') + 120)) && /\.hero-dot\{ width:40px; height:44px/.test(cc), '좌우로 밀기 · 세로 스크롤은 그대로 · 점 누름 칸 40x44');
  ok(/EATPH/.test(mj) && /new Set\(EATPH\)/.test(mj), '묶음: 식당 사진은 빼서 대표 사진 자리를 더 확보(묵호항 포함)');
  // (2)(3) 마법사 색 · 말투
  { const a = cc.indexOf('/* ---------- 시작 화면: 한 번에 한 가지씩'), b = cc.indexOf('/* ===== 코스 한 그림 · 날짜 고르기'), wiz = cc.slice(a, b) + cc.slice(cc.indexOf('/* 마법사 위 그림 띠'), cc.indexOf('/* 지도 탭: 코스·식당·숙소 */'));
    const hexes = [...wiz.matchAll(/#([0-9a-fA-F]{6})\b/g)].map((m) => m[1]), isRed = (h) => { const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), bl = parseInt(h.slice(4, 6), 16); return r >= 150 && g <= 110 && bl <= 110; };
    ok(a > 0 && !/var\(--alert|var\(--like|var\(--warn/.test(wiz) && !hexes.some(isRed), '마법사 CSS 에 붉은 계열·경고 변수 없음 (색 ' + hexes.length + '개 검사)');
    ok(/#st1,#st2,#st3\{[^}]*--qa:var\(--wz\)/.test(wiz) && !/#st[123]\{[^}]*--qa:#/.test(wiz), '세 단계가 같은 강조색(--wz 보라) 하나');
    const lum = (h) => { const c = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255).map((v) => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }, cr = (x, y) => { const a1 = lum(x), b1 = lum(y); return (Math.max(a1, b1) + 0.05) / (Math.min(a1, b1) + 0.05); };
    const tok = (n) => (cc.match(new RegExp('--' + n + ':#([0-9a-fA-F]{6})')) || [])[1];
    ok(cr('ffffff', tok('wz')) >= 4.5 && cr(tok('wz-ink'), tok('wz-soft')) >= 4.5 && cr(tok('wz-lime-ink'), tok('wz-lime')) >= 4.5 && cr(tok('wz'), tok('wz-soft')) >= 4.5, '대비 AA(4.5:1↑): 흰 글씨/보라 ' + cr('ffffff', tok('wz')).toFixed(2) + ' · 보라/연보라 ' + cr(tok('wz'), tok('wz-soft')).toFixed(2) + ' · 연두 위 글 ' + cr(tok('wz-lime-ink'), tok('wz-lime')).toFixed(2)); }
  ok(/class="st-art"/.test(hh) && (hh.match(/class="st-art"/g) || []).length === 3, '단계마다 위쪽에 여행 그림 띠(내 그림, 사진 아님) 3개');
  ok(/언제까지 동해에 있을 수 있어요\?/.test(hh) && />돌아가는 날</.test(hh) && !/언제 돌아가요/.test(hh) && !/돌아가요\?/.test(hh.slice(hh.indexOf('id="st2"'), hh.indexOf('id="st3"'))), '2단계: 제목 "언제까지 동해에 있을 수 있어요?" · 겉말머리 "돌아가는 날" (돌아감을 앞세우지 않음)');
  { const wz = aj.slice(aj.indexOf('function nearestHelp'), aj.indexOf('function loadTrains')) + aj.slice(aj.indexOf('function renderStart'), aj.indexOf('function loadTrains'));
    ok(/출발 15분 전까지 와 있으면 돼요/.test(wz) && !/놓치|늦어|못 가요|안 돼요\. 코스가 짧거나/.test(wz), '가까운 기차 안내는 차분한 한 줄("…출발 15분 전까지 와 있으면 돼요") · 겁주는 말 없음'); }
  ok(/#s-start \.howbody \.warnline,#s-start #stepMsg,#s-start #dateMsg\{[^}]*var\(--wz-soft\)/.test(cc) && /role="status" hidden/.test(hh.slice(hh.indexOf('id="stepMsg"') - 40, hh.indexOf('id="stepMsg"') + 60)), '마법사 안내(되돌아감·지난 날짜)는 차분한 연보라 안내 상자 · alert 역할 아님');
  { const nonLive = cc.slice(0, cc.indexOf('.lv-alert{')) ; ok(/\.edwarn\{[^}]*var\(--info-soft\)/.test(cc) && /\.final\.late\{[^}]*var\(--info-soft\)/.test(cc) && !/\.edwarn\{[^}]*var\(--alert/.test(cc) && !/\.final\.late\{[^}]*var\(--alert/.test(cc) && /\.lv-alert\.bad\{[^}]*var\(--alert/.test(cc), '돌아가는 시각 경고(고치기·마감·늦음 줄)는 붉은색 대신 차분한 안내색 · 붉은색은 실시간 길안내의 진짜 늦음 알림에만'); }
  // (4) 시각 입력
  ok(/id="sTime"[^>]*class="t-src"/.test(hh) && /<input type="time" id="sTime"/.test(hh) && /<input type="time" id="bTime"/.test(hh) && /id="twS"/.test(hh) && /id="twB"/.test(hh), '숨은 type=time(#sTime·#bTime)은 그대로 + 보이는 오전/오후·시·분 입력(#twS·#twB)');
  ok((hh.match(/class="tmw-h" type="text" inputmode="numeric" pattern="\[0-9\]\*" maxlength="2"/g) || []).length === 2 && (hh.match(/class="tmw-m" type="text" inputmode="numeric" pattern="\[0-9\]\*" maxlength="2"/g) || []).length === 2 && (hh.match(/aria-label="시"/g) || []).length === 2 && (hh.match(/aria-label="분"/g) || []).length === 2, '시·분 칸: inputmode numeric · pattern · maxlength 2 · 라벨 "시"/"분"');
  ok(/role="radiogroup" aria-label="오전 오후"/.test(hh) && /\.tmw-b\{[^}]*min-height:48px/.test(cc) && /\.tmw input\{[^}]*min-height:56px/.test(cc) && /font-size:max\(20px/.test(cc.slice(cc.indexOf('.tmw input{'), cc.indexOf('.tmw input{') + 300)), '오전/오후 토글 48px↑ · 입력칸 56px↑ · 글자 20px(≥16 → 자동 확대 없음)');
  { const m = aj.match(/\/\*TW-BEGIN\*\/([^]*?)\/\*TW-END\*\//); const tw = new Function(m[1] + '; return { twToMin, twFromMin, twHour, twMinute, twAdvance };')();
    let rt = true; for (let k = 0; k < 1440; k++) { const p = tw.twFromMin(k); if (tw.twToMin(p.pm, p.h12, p.m) !== k || p.h12 < 1 || p.h12 > 12 || p.m < 0 || p.m > 59) rt = false; }
    ok(rt, '오전/오후·시·분 ↔ 24시간 분(0~1439) 1440개가 오차 없이 왕복');
    ok(tw.twToMin(false, 12, 0) === 0 && tw.twToMin(true, 12, 0) === 720 && tw.twToMin(true, 3, 30) === 930 && tw.twToMin(false, 11, 59) === 719, '오전 12시=0시 · 오후 12시=12시 · 오후 3:30=15:30');
    ok(tw.twHour('15').h12 === 3 && tw.twHour('15').pm === true && tw.twHour('0').h12 === 12 && tw.twHour('24').h12 === 12 && tw.twHour('7').pm === null && tw.twHour('') === null, '시 검사: 13~23 은 오후로 읽고 0·24 이상은 12 · 빈칸은 null');
    ok(tw.twMinute('75') === 59 && tw.twMinute('05') === 5 && tw.twMinute('') === null && tw.twMinute('0') === 0, '분 검사: 0~59 로 맞춤 · 빈칸은 null');
    ok(!tw.twAdvance('') && !tw.twAdvance('1') && !tw.twAdvance('2') && tw.twAdvance('3') && tw.twAdvance('9') && tw.twAdvance('12') && tw.twAdvance('10'), '자동으로 분 칸으로: 두 자리 또는 3~9 한 자리 (1·2 는 기다림)'); }
  ok(/src\.dispatchEvent\(new Event\('change', \{ bubbles: true \}\)\)/.test(aj) && /twSync\('sTime'\); twSync\('bTime'\);/.test(aj) && /st\.h\.disabled = dis/.test(aj) && /data-hset/.test(aj), '보이는 칸 → 숨은 칸(change 로 기존 코드 그대로) · 숨은 칸 → 보이는 칸(renderStart 마다) · 자가용 "정하지 않았어요" 잠금 · 가까운 기차 단추도 같은 길');
  // (5) 글씨 기본
  ok(/<body>/.test(hh) && !/<body class="big"/.test(hh) && /setBig\(lsGet\('tour\.big'\) === '1'\)/.test(aj) && /lsSet\('tour\.big'/.test(aj) && /id="bigBtn"[^>]*aria-pressed="false"/.test(hh), '글씨: 기본은 보통(body.big 없음) · 가+ 로 크게 · localStorage tour.big 기억');
  ok(/body:not\(\.big\)\{ --fs:clamp\(1rem/.test(cc) && /body\.big\{ --fs:clamp\(1\.125rem/.test(cc), '보통 16~18px / 큰 글씨 18~21px 두 가지 크기 모두 정의');
  ok(rd('../../CLAUDE.md').includes('기본은 보통 글씨, 가+ 로 크게 (2026-10-18 사용자)') && !/큰글씨 모드 기본 켬/.test(rd('../../CLAUDE.md')), 'CLAUDE.md 의 "큰글씨 기본 켬" 줄이 새 결정으로 바뀜');
  // (6)(7) 접힌 장
  ok(!/line-clamp/.test(cc.slice(cc.indexOf('.p-cap{'), cc.indexOf('.p-cap{') + 260)) && !/data-act="more"/.test(aj) && !/cap\.classList\.toggle\('open'/.test(aj), '열린 장 안에는 줄 수 제한·"더 보기" 단추가 없음(글 전체가 보임)');
  { const fold = aj.slice(aj.indexOf('function foldSet('), aj.indexOf('function chapterHtml(')); ok(/S\.openFold\[id\] = true/.test(fold) && /delete S\.openFold\[id\]/.test(fold) && !/\.chap\.open'\)\.forEach/.test(fold) && !/ovQ\('#timeline \.chap\.open'/.test(aj), '열림은 S.openFold 에 기억 · 다른 장을 열어도 닫지 않음(한 번에 하나 규칙 삭제)'); }
  ok(/isOpen = !extra && !!S\.openFold\[p\.id\]/.test(aj) && /S\.openFold = \{\}/.test(aj.slice(aj.indexOf('function makeCourse('), aj.indexOf('function makeCourse(') + 500)), '다시 그릴 때마다 열린 장을 되살림 · 새 코스를 짤 때만 초기화');
  ok(/foldOpen\(e\.node\.id, false\)/.test(aj) && !/foldSet\(o, false\)/.test(aj), '길안내 도착은 그 장을 "더" 열 뿐 다른 장을 닫지 않음');
  // (8) 지도 식당·숙소
  { const TW = require('./town.js'); require('./facilities.js'); const FACd = require('./facilities.js');
    const eatPts = new Set(), lodPts = new Set(), key = (n, la, ln) => String(n).replace(/\s+/g, '').slice(0, 4) + '|' + Math.round(la * 2500) + '|' + Math.round(ln * 2000);
    TW.list('eat').filter(TW.hasPos).forEach((x) => eatPts.add(key(x.name, x.lat, x.lng))); D.eateries.forEach((e) => eatPts.add(key(e.name, e.lat, e.lng))); (FACd.eats || []).forEach((e) => eatPts.add(key(e.name, e.lat, e.lng)));
    TW.list('lodge').filter(TW.hasPos).forEach((x) => lodPts.add(key(x.name, x.lat, x.lng))); (FACd.lodging || []).forEach((e) => lodPts.add(key(e.name, e.lat, e.lng)));
    ok(eatPts.size >= 60 && lodPts.size >= 19, '지도에 올릴 자료(좌표 있는 곳): 식당 약 ' + eatPts.size + '곳 · 숙소 약 ' + lodPts.size + '곳 (동네 자료 + 시설 자료 + 관광공사 음식점)'); }
  ok(/id="layCourse"[^>]*aria-pressed="true"/.test(hh) && /id="layEat"[^>]*aria-pressed="false"/.test(hh) && /id="layLodge"[^>]*aria-pressed="false"/.test(hh) && /S\.mapLay = \{ course: true, eat: false, lodge: false \}/.test(aj), '지도 칩 [코스][식당][숙소]: 코스만 기본 켜짐');
  ok(/var POI_ICON = \{ eat:/.test(aj) && /lodge:/.test(aj.slice(aj.indexOf('var POI_ICON'), aj.indexOf('var POI_ICON') + 400)) && /\.kpoi\.eat i,\.poi-ic\.eat\{ background:#b35c00/.test(cc) && /\.kpoi\.lodge i/.test(cc) && /\.kpoi\{ width:44px; height:44px/.test(cc), '식당(포크)·숙소(침대) 작은 표시: 색·그림이 서로 다름 · 누름 칸 44px');
  ok(/function poiLimit\(level\)/.test(aj) && (() => { const f = new Function(aj.match(/function poiLimit\(level\) \{[^\n]+\}/)[0] + '; return poiLimit;')(); return f(3) > f(4) && f(4) > f(5) && f(5) > f(6) && f(6) > f(7) && f(7) >= 10; })() && /zoom_changed/.test(aj) && /taken\[k\]/.test(aj) && /\['eat', 'lodge'\]\.forEach\(function \(kind\)/.test(aj), '확대 수준에 따라 보여 줄 곳 수를 줄임(넓게 볼수록 적게 · 6 이상은 칸마다 한 곳씩 고르게 · 식당/숙소 몫 따로) · 지도 확대가 바뀌면 다시 맞춤');
  ok(/data-poi="' \+ p\.id/.test(aj) && /카카오맵에서 보기/.test(aj.slice(aj.indexOf('function renderPoiUi'), aj.indexOf('function layToggle'))) && /sel\.addr/.test(aj) && /sel\.type/.test(aj) && /class="spoi"/.test(aj), '표시를 누르면 작은 카드(이름·업종·주소·"카카오맵에서 보기") · 묶음 정적 지도에도 같은 점(.spoi) · 아래 가까운 곳 목록');
  // (9) 코스에 식당 없음 · 끼니 시간 줄 · 동네 · 제보
  ok(/function slotHtml\(/.test(aj) && /근처 식당 지도에서 보기/.test(aj) && /data-slotmap/.test(aj) && /openMapAt\(\{ lat: base\.lat, lng: base\.lng \}, \{ eat: true/.test(aj), '끼니 시간 줄: "점심 12:10~13:00" + "근처 식당 지도에서 보기"(지도 탭, 식당 켬, 그 자리 가운데)');
  ok(!/EAT\[|mealHtml|menuReadHtml|otherEatsHtml|announceMeal|data-menufile|aiReadMenu\(EAT/.test(aj), '앱 코드에서 식당 장·메뉴판 도우미·가게 제보 반영이 모두 빠짐');
  ok(!/data-type="meal"|id="mealKinds"|오부자|오뚜기/.test(hh) && /점심·저녁 포함<br>예시/.test(hh) && /id="runDemoMeal"/.test(hh), '제보 화면에 한 끼 칸·식당 빠른 단추 없음 · 예시 카드 "점심·저녁 포함 예시"(id runDemoMeal 그대로)');
  ok(!/pickedFor|registerPicked|K_PICK/.test(aj) && /tw-onmap/.test(aj) && /townLodge\(x\)/.test(aj.slice(aj.indexOf('function townAdd('), aj.indexOf('function tripLate('))), '동네 탭: 식당은 "코스에 넣기" 없이 "지도에서 보기" · 숙소 넣기(여러 날)는 그대로');
  { const E = require('./editor.js'), env = { D, o: { ...base, date: '2026-10-24', routes: RP }, frame: P.plan(D, { ...base, now: T('10:00'), train: T('19:40'), food: true, date: '2026-10-24', routes: RP }) };
    const sp = E.fromPlan(env.frame); ok(E.addItem(env, sp, 0, 0, 'eat_obuja') === null && E.suggest(env, sp, 0, 0, '').every((c) => !/^eat_/.test(c.id)) && E.suggest(env, sp, 0, 0, '물회').every((c) => !/^eat_/.test(c.id)), '코스 고치기: 식당은 넣기 목록·검색에 안 나오고 넣을 수도 없음');
    const rt = E.retime(env, sp); ok(rt.stops.every((s, i) => s.id === env.frame.stops[i].id && s.arrive === env.frame.stops[i].arrive && s.leave === env.frame.stops[i].leave) && E.blocks(rt).length === 0, '끼니 슬롯이 든 코스를 고치기 계산으로 다시 짜도 시각이 그대로(슬롯 이동 0분)');
    const noM = E.removeItem(sp, env.frame.stops.find((s) => s.kind === 'meal').id); ok(noM && noM.noMeal === true && E.retime(env, noM).stops.every((s) => s.kind !== 'meal'), '끼니 시간을 빼면 "식사 안 넣음" 표시');
    const aiR = E.applyIntents(env, noM, AI.aiEditIntent('점심 넣어줘', { places: D.places.map((p) => ({ id: p.id, name: p.name, short: p.short })) }).intents); ok(aiR.ok && E.retime(env, aiR.spec).stops.some((s) => s.kind === 'meal' && s.place.slot), '"점심 넣어줘" → 끼니 시간만 다시 넣음(식당 안 고름)'); }
  // 모든 조합의 코스: 식당 0개 + 마감 위반 0
  { let n = 0, bad = 0, eatN = 0, slotN = 0;
    for (const date of ['2026-10-23', '2026-10-24', '2026-10-25']) for (const how of [['train', 'train'], ['car', 'car'], ['bus', 'train']]) for (const now of [T('09:30'), T('12:00'), T('16:00')]) for (const train of [T('15:10'), T('18:10'), T('21:00')]) for (const comp of [{}, { kid: true, avoidStairs: true }, { slow: true, avoidStairs: true, soft: true }]) for (const food of [false, true]) {
      const pl = P.plan(D, { ...base, interests: [], date, how: how[0], backHow: how[1], start: how[0] === 'car' ? 'park' : how[0] === 'bus' ? 'bus' : 'mukho', end: how[1] === 'car' ? 'park' : how[1] === 'bus' ? 'bus' : 'mukho', now, train, food, ...comp });
      n++; if (pl.stops.some((s) => isRestaurantId(s.id))) eatN++; if (meals(pl).length) slotN++;
      if (pl.feasible && pl.back.arrive > pl.deadline + 1e-9) bad++;
    }
    ok(eatN === 0 && bad === 0 && slotN > 0, `계획 조합 ${n}가지: 식당 장 ${eatN}개 · 마감 위반 ${bad}건 · 끼니 시간 들어간 코스 ${slotN}개`);
    const MD = P.planDays(D, { ...base, now: T('10:00'), train: T('15:48'), date: '2026-10-24', backDate: '2026-10-25', sunrise: true, food: true, routes: RP }); ok(MD.stops.every((s) => !isRestaurantId(s.id)) && MD.days.every((d) => d.plan.stops.every((s) => !isRestaurantId(s.id))) && (!MD.days[1].breakfast || (MD.days[1].breakfast.place.slot && MD.days[1].breakfast.kind === 'meal')), '여러 날(1박 2일): 식당 장 없음 · 둘째 날 일출 뒤 아침도 식당이 아니라 아침 시간'); }
  { const pr = AI.aiClassifyReport('오부자 줄 30분', null, ''); ok(pr.shop === true && !pr.placeId && /가게 제보는 받지 않아요/.test(aj), '가게 줄·휴무 제보는 코스를 바꾸지 않음(안내만) · 볼거리 제보는 그대로'); }
  ok(/#demo-meal|'demo-meal'/.test(aj) && /점심도 먹고 싶어요/.test(aj), '#demo-meal: "점심도 먹고 싶어요" 로 점심 시간이 들어가는 예시');
}


console.log('\n[33] 식당 좌표 대량 추가 (2026-10-18) · 색 통일 (보라)');
{ const path = require('path'), rd = (f) => fs.readFileSync(path.join(__dirname, f), 'utf8'), TD = require('./town.data.js'), TWn = require('./town.js');
  const css = rd('style.css'), aj = rd('app.js'), td = rd('town.data.js');
  const pos = TD.eats.filter((r) => r[4] && r[5]);
  ok(pos.length >= 1500 && pos.length > 0.9 * TD.eats.length, '좌표 있는 식당 ' + pos.length + ' / ' + TD.eats.length + ' (1,500곳 이상)');
  ok(pos.every((r) => r[4] >= 37.40 && r[4] <= 37.62 && r[5] >= 128.95 && r[5] <= 129.20), '모든 좌표가 동해시 상자 안(위도 37.40~37.62, 경도 128.95~129.20)');
  ok(pos.every((r) => r[7] === 'a' || r[7] === 'k') && TD.eats.filter((r) => !r[4]).every((r) => !r[7]) && pos.some((r) => r[7] === 'k') && pos.some((r) => r[7] === 'a'), '정밀도 칸: a(주소) · k(이름 찾기), 좌표 없으면 빈칸');
  ok(pos.every((r) => (String(r[4]).split('.')[1] || '').length <= 5 && (String(r[5]).split('.')[1] || '').length <= 5), '좌표는 소수 5자리까지만');
  ok(!/(KakaoAK|kakao_rest|rest_api_key|appkey|[0-9a-f]{32})/i.test(td) && !/[�─-╿]/.test(td), 'town.data.js 에 키·깨진 글자 없음');
  ok(td.length < 400000 && TWn.list('eat').filter(TWn.hasPos).length === pos.length && TWn.list('eat').find(TWn.hasPos).prec, '자료 크기 작게 · town.js 가 정밀도(prec)를 줌');
  ok(/function poiGroups\(/.test(aj) && /class="poi-src"/.test(rd('index.html')) && /위치는 주소로 찾은 대략 위치/.test(TD.src.eats), '지도 묶음(poiGroups) · 출처 줄 "위치는 주소로 찾은 대략 위치"');
  { const f = new Function(aj.match(/function poiCell\(level\) \{[^\n]+\}/)[0] + '; return poiCell;')(); ok(f(3) === 0 && f(5) > 0 && f(7) > f(5) && f(10) >= f(7), '확대 수준별 묶음 칸: 가까울수록 작고 3 이하는 낱개'); }
  ok(!/pickedFor|registerPicked/.test(aj) && /tw-onmap/.test(aj), '식당은 코스에 넣지 않음(지도·동네만)');
  const OVm = require('./ov.js');
  ok(!/#0b7f76/i.test(css), 'style.css 에 옛 청록(#0b7f76) 없음');
  ok(/--brand:#5b49e0/.test(css) && /--brand-soft:#f1efff/.test(css) && /--brand-dark:#2b2563/.test(css), '앱 전체 주색: 보라 --brand #5b49e0');
  ok(OVm.DAYC[0] === '#5b49e0' && OVm.DAYC[1] === '#b35c00' && OVm.ONE === '#5b49e0' && !OVm.DAYC.some((c) => /^#(d9480f|b3351c|e03131|f0443a)$/i.test(c)), '날짜 색: 1일 보라 · 2일 주황갈색(빨강 아님)');
  const lum = (h) => { const c = [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255).map((v) => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
  const cr = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  ok(cr('#5b49e0', '#ffffff') >= 4.5 && cr('#3a2fa8', '#f1efff') >= 4.5 && cr('#ffffff', '#2b2563') >= 4.5 && cr('#b35c00', '#ffffff') >= 4.5 && cr('#243a00', '#c8f08a') >= 4.5 && cr('#5b49e0', '#f1efff') >= 4.5, '글자 대비 4.5 이상(보라/흰 · 진보라/연보라 · 갈색/흰 · 라임)');
}

console.log('\n[34] 현장 제보 새 규칙 (2026-10-18, 신청서 v1.4 핵심기능 2): 알림만 가고 코스는 사람이 눌러야 바뀜');
{ const path = require('path'), rd = (f) => fs.readFileSync(path.join(__dirname, f), 'utf8'), R = require('./rep.js');
  const aj = rd('app.js'), hh = rd('index.html'), css = rd('style.css'), lj = rd('live.js');
  const rp = (id, dev, simTs, o = {}) => ({ id, dev, type: 'crowd', placeId: 'skyvalley', minutes: 20, simTs, at: 1e12 + simTs * 6e4, near: true, ...o });
  const vote = (id, dev, v, simTs, o = {}) => ({ id, dev, vote: v, type: 'crowd', placeId: 'skyvalley', simTs, at: 1e12 + simTs * 6e4, ...o });
  const st = (recs, now) => { const a = R.alerts(recs, now)[0]; return a ? a.state : 'none'; };
  // 코스는 자동으로 안 바뀐다 (코드 모양)
  const ing = aj.slice(aj.indexOf('function ingest(extra) {'), aj.indexOf('/* ---------- 근처 제보 알림'));
  ok(!/replan\(|buildPlan\(|recomputeFx\(/.test(ing), 'ingest(제보 받기)는 코스를 다시 짜지 않음 — 알림만 그림');
  const snd = aj.slice(aj.indexOf('function sendRep(o) {'), aj.indexOf('/* ---------- 제보 받기'));
  ok(!/replan\(|buildPlan\(|recomputeFx\(/.test(snd) && /renderRepAlerts\(\)/.test(snd), '제보 보내기도 코스를 다시 짜지 않음');
  ok(/function recomputeFx\(\) \{ S\.fx = P\.effectsFromReports\(REP\.acceptedReports\(S\.reports, S\.applied/.test(aj) && /S\.applied\[key\] = true; recomputeFx\(\)/.test(aj), '코스 계산에 들어가는 제보는 [코스 다시 짜기]로 받아들인 알림의 것뿐');
  ok(/data-ra="go"[^>]*>코스 다시 짜기</.test(aj) && /data-ra="ok"[^>]*>괜찮아요</.test(aj) && />아직 그래요</.test(aj) && />아니에요</.test(aj), '알림 단추: 코스 다시 짜기 · 괜찮아요 · 아직 그래요 · 아니에요');
  ok(/id="repAlerts"/.test(hh) && hh.indexOf('id="repAlerts"') < hh.indexOf('id="dayTabs"') && /lvAlerts/.test(aj) && /liveAlertList\(\)/.test(aj) && /remainderReplan/.test(lj), '알림 자리: 코스 화면 맨 위 + 길안내 시트(lvAlerts) · 길안내 중 다시 짜기는 남은 곳만');
  ok(/list\.slice\(0, 2\)/.test(aj) && /더 보기 \(/.test(aj) && /\.ra\.sm\{/.test(css), '알림이 여럿이면 작게 쌓고 2개까지 + 더 보기');
  // 켜지는 규칙
  ok(st([rp('a', 'd1', 780)], 790) === 'pending', '제보 1건 → 알림 안 켜짐(대기)');
  ok(st([rp('a', 'd1', 780), rp('b', 'd1', 790)], 800) === 'pending', '같은 기기 2건 → 안 켜짐(기기 2대 필요)');
  ok(st([rp('a', 'd1', 780), rp('b', 'd2', 790)], 800) === 'active', '서로 다른 기기 2대 · 60분 안 → 켜짐');
  ok(st([rp('a', 'd1', 780), rp('b', 'd2', 841)], 850) === 'pending', '기기 2대여도 61분 떨어지면 안 켜짐');
  ok(st([rp('a', 'd1', 780), rp('b', 'd2', 840)], 850) === 'active', '정확히 60분 간격은 켜짐');
  ok(R.alerts([rp('a', 'd1', 780), rp('b', 'd2', 790, { type: 'closed' })], 800).every((a) => a.state === 'pending'), '종류가 다르면 합치지 않음');
  ok(R.alerts([rp('a', 'd1', 780), rp('b', 'd2', 790, { placeId: 'nolgol' })], 800).every((a) => a.state === 'pending'), '장소가 다르면 합치지 않음');
  // 꺼지는 규칙
  const two = [rp('a', 'd1', 780), rp('b', 'd2', 790)];
  ok(st(two, 849) === 'active' && st(two, 850) === 'expired', '마지막 제보 60분 뒤(850)에 끝남');
  ok(st([...two, vote('v1', 'd3', 'yes', 840)], 899) === 'active' && st([...two, vote('v1', 'd3', 'yes', 840)], 900) === 'expired', '"아직 그래요" 는 시간을 새로 60분 늘림');
  ok(st([...two, vote('n1', 'd3', 'no', 800), vote('n2', 'd4', 'no', 801)], 805) === 'cancelled', '"아니에요" 2명 → 취소');
  ok(st([...two, vote('n1', 'd3', 'no', 800)], 805) === 'active', '"아니에요" 1명만으로는 안 꺼짐(장난 취소 막기)'); ok(st([...two, vote('y1', 'd5', 'yes', 799), vote('n1', 'd3', 'no', 800), vote('n2', 'd4', 'no', 801), vote('y2', 'd6', 'yes', 802)], 805) === 'active', '"아니에요" 2명이어도 "아직 그래요" 가 같거나 많으면 유지');
  ok(st([...two, vote('n1', 'd3', 'no', 800), vote('y1', 'd4', 'yes', 801)], 805) === 'active', '1:1 이면 그대로');
  ok(st([...two, vote('n1', 'd3', 'no', 800), vote('y2', 'd3', 'yes', 801)], 805) === 'active' && st([...two, vote('y1', 'd3', 'yes', 800), vote('n2', 'd3', 'no', 801), vote('n3', 'd4', 'no', 802)], 805) === 'cancelled', '같은 기기는 마지막 한 표만 셈');
  ok(st([...two, vote('n1', 'd3', 'no', 800), rp('c', 'd5', 810)], 815) === 'active', '새 제보가 오면 옛 "아니에요" 는 지워짐');
  { const a = R.alerts(two, 800)[0]; ok(a.devices === 2 && a.reports === 2 && a.key === 'crowd|skyvalley' && a.minutes === 20 && a.latest === 790 && a.until === 850, '알림 값: 기기 2 · 제보 2 · 줄 20분 · 마지막 790 · 끝 850'); }
  { const acc = R.acceptedReports(two, { 'crowd|skyvalley': true }, 800), fx = P.effectsFromReports(acc, 800, true), none = P.effectsFromReports(R.acceptedReports(two, {}, 800), 800, true);
    ok(acc.length === 2 && fx.crowd.skyvalley && !none.crowd.skyvalley, '받아들이지 않은 알림은 코스 계산에 안 들어가고, 받아들이면 들어감'); }
  // 속도 제한
  const NOW = 2e12, mk = (id, placeId, ago) => rp(id, 'me', 780, { placeId, at: NOW - ago });
  ok(R.rateCheck([], 'me', 'skyvalley', NOW).ok, '처음 제보는 통과');
  ok(!R.rateCheck([mk('r1', 'skyvalley', 14 * 6e4)], 'me', 'skyvalley', NOW).ok && R.rateCheck([mk('r1', 'skyvalley', 14 * 6e4)], 'me', 'skyvalley', NOW).why === 'place', '같은 곳 14분 안 다시 → 막힘');
  ok(R.rateCheck([mk('r1', 'skyvalley', 16 * 6e4)], 'me', 'skyvalley', NOW).ok, '같은 곳 16분 뒤는 통과');
  ok(R.rateCheck([mk('r1', 'nolgol', 1 * 6e4)], 'me', 'skyvalley', NOW).ok, '다른 곳은 바로 가능');
  { const six = ['a', 'b', 'c', 'd', 'e', 'f'].map((p, i) => mk('s' + i, 'p_' + p, (5 + i * 8) * 6e4)); const r7 = R.rateCheck(six, 'me', 'nolgol', NOW);
    ok(!r7.ok && r7.why === 'hour', '1시간 6건 채우면 7번째는 막힘'); ok(R.rateCheck(six.slice(0, 5), 'me', 'nolgol', NOW).ok, '5건까지는 통과'); ok(R.rateCheck(six.map((x) => ({ ...x, dev: 'other' })), 'me', 'nolgol', NOW).ok, '다른 기기의 제보는 세지 않음'); }
  // 근처 확인 (200m · 오차 150m)
  const sky = D.places.find((p) => p.id === 'skyvalley');
  const off = (m, dir = 'n') => dir === 'n' ? { lat: sky.lat + m / 111000, lng: sky.lng } : { lat: sky.lat, lng: sky.lng + m / (111320 * Math.cos(sky.lat * Math.PI / 180)) };
  ok(R.checkNear({ ...off(0), acc: 20 }, sky).state === 'near', '같은 자리 → 근처');
  ok(R.checkNear({ ...off(150), acc: 20 }, sky).ok && R.checkNear({ ...off(150, 'e'), acc: 20 }, sky).ok, '150m → 근처 (남북·동서)');
  ok(R.checkNear({ ...off(195), acc: 20 }, sky).ok && !R.checkNear({ ...off(215), acc: 20 }, sky).ok && R.checkNear({ ...off(215), acc: 20 }, sky).state === 'far', '195m 근처 · 215m 밖(far)');
  ok(R.checkNear({ ...off(10), acc: 151 }, sky).state === 'badacc' && R.checkNear({ ...off(10), acc: 150 }, sky).ok && R.checkNear({ ...off(10) }, sky).state === 'badacc', '위치 오차 150m 넘으면(또는 모르면) "정확하지 않음" — 안 믿음');
  ok(R.checkNear(null, sky).state === 'nopos' && R.checkNear({ lat: NaN, lng: 1, acc: 1 }, sky).state === 'nopos', '위치 없음 → nopos');
  { const places = D.places.filter((p) => ['묵호', '천곡'].includes(p.region)), sd = R.sortByDistance({ ...off(0), acc: 30 }, places);
    ok(sd.near.length >= 1 && sd.near[0].place.id === 'skyvalley' && sd.far.length > 0 && sd.near.every((x) => x.m <= 200) && sd.far.every((x) => x.m > 200) && sd.far.every((x, i, a) => !i || a[i - 1].m <= x.m), '장소 목록: 200m 안이 먼저(가까운 순), 나머지는 거리 순 + 거리 값');
    ok(R.sortByDistance({ ...off(0), acc: 400 }, places).state === 'badacc', '오차가 크면 목록도 "정확하지 않음"'); }
  ok(Math.abs(R.dist(37.5, 129.1, 37.5, 129.1)) < 1e-6 && Math.abs(R.dist(37.5, 129.1, 37.51, 129.1) - 1111.9) < 3, 'haversine: 위도 0.01° ≈ 1,112m');
  // 좌표는 저장하지 않는다
  const mkr = R.makeReport({ id: 'x', dev: 'd', type: 'crowd', placeId: 'skyvalley', minutes: 20, simTs: 780, at: 1, lat: 37.5, lng: 129.1, acc: 10, coords: { latitude: 1 }, text: '줄 20분' });
  ok(!R.hasCoords(mkr) && !/lat|lng|coords|acc/i.test(JSON.stringify(mkr)) && mkr.near === true, '저장되는 제보에는 좌표·오차가 없음 (장소 id + near:true 만)');
  ok(R.hasCoords({ a: 1, lat: 3 }) && R.hasCoords({ coords: {} }) && !R.hasCoords(R.makeVote({ id: 'v', dev: 'd', vote: 'yes', type: 'crowd', placeId: 'x', simTs: 1, at: 1, lat: 3 })), '좌표 검사기: 섞이면 잡고, 확인 표시는 좌표를 못 가짐');
  ok(!/lsSet\([^)]*S\.fix/.test(aj) && /메모리에만/.test(aj) && !/fetch\([^)]*(lat|lng|S\.fix)/.test(aj) && !/JSON\.stringify\([^)]*S\.fix/.test(aj), '앱: 위치(S.fix)는 메모리에만 — localStorage·네트워크로 안 나감');
  // 화면: 위치 확인 창 · 시연 단추 · 번들
  ok(/id="repLoc"[^>]*role="dialog"/.test(hh) && /저장·전송하지 않아요/.test(hh) && /id="repLocGo"/.test(hh) && /근처라고 치고 제보\(시연\)/.test(hh) && /id="repDemoNear"/.test(hh) && /id="repLocDemo"/.test(hh), '제보 화면: 위치 쓰기 전 안내 창("저장·전송하지 않아요") · "근처라고 치고 제보(시연)" 단추(화면·안내 창 둘 다)');
  ok(/function repGpsOk\(\) \{ return !window\.TOUR_BUNDLE/.test(aj) && /repLocNoGps/.test(aj) && /위치가 정확하지 않아요 · 밖으로 나와 다시 해 주세요/.test(aj) && /200m 안에서만 제보할 수 있어요/.test(aj), '묶음(TOUR_BUNDLE)에서는 위치를 안 쓰고 시연 단추만 · 오차 큰 위치 안내 문구');
  ok(/optgroup label="지금 있는 곳 200m 안"/.test(aj) && /200m 밖 · 지금은 제보할 수 없어요/.test(aj) && /optHtml\(x\.place, x\.m >= 1000/.test(aj), '장소 목록: 200m 안이 먼저, 먼 곳은 거리와 함께 못 고르게(disabled)');
  ok(/lv && lv\.myPos/.test(aj.slice(aj.indexOf('function curFix()'), aj.indexOf('function nearState'))), '길안내 중이면 그 위치를 다시 씀');
  ok(/tour\.dev\.v1/.test(aj) && /Math\.random\(\)\.toString\(36\)/.test(aj.slice(aj.indexOf('function myDev()'), aj.indexOf('function repGpsOk'))), '기기 번호: localStorage 에 무작위 번호');
  { const bs = rd('묶음.mjs'); ok(/<script src="rep\.js"><\/script>/.test(hh) && /matchAll\(\/<script src/.test(bs), 'rep.js 는 index.html 순서대로 묶음에 들어감'); }
  ok(/근처 여행자에게 알림으로 가요/.test(hh + aj) && !/다음 여행자의 코스에 바로 반영/.test(hh + aj + rd('places.js') + rd('ai.js')), '문구: "근처 여행자에게 알림으로 가요, 다시 짤지는 본인이 골라요" (옛 "다음 여행자 코스에 바로 반영" 없음)');
  ok(/rep-replan/.test(aj) && /rep-vote/.test(aj) && /확인 표시/.test(aj) && /알림 중인 곳/.test(aj) && !/\blat\b|\blng\b|latitude|longitude|coords/.test(aj.slice(aj.indexOf('function renderWatch()'), aj.indexOf("$('watchBack')"))), '시청 화면: 제보·알림·확인 표시 수(좌표 없음)');
  // 지도 겹침·처음 열 때
  ok(/zIndex: p\.st \? 9 : 8/.test(aj) && /zIndex: 2, clickable: true/.test(aj), '지도: 코스 번호(8)·출발/도착(9)이 식당 묶음(2)·낱개(4)보다 위');
  ok(/containerPointFromCoords/.test(aj) && /코스 표시 가까이\(약 30px 안\)에는 묶음 숫자를 두지 않는다/.test(aj) && /코스 번호·출발 표시 위\(약 30px 안\)/.test(aj), '지도: 코스 표시 가까이(약 30px)의 식당 묶음은 숨김 (카카오 지도·그림 지도 둘 다)');
  ok(/if \(!S\.mapSeen\) \{ S\.mapSeen = true; S\.mapLay = \{ course: true, eat: false, lodge: false \}/.test(aj) && /S\.mapSeen = false; S\.mapLay = \{ course: true, eat: false, lodge: false \}/.test(aj), '지도 탭 처음 열 때 코스만 켜짐(식당·숙소 끔)');
}

console.log('\n[35] 관광지 집중률 예측 (한국관광공사, 2026-10-18): 이름 맞추기 · 서버 · 계획 부드러운 규칙 · 화면 글');
{ const path = require('path'), rd = (f) => fs.readFileSync(path.join(__dirname, f), 'utf8'), C = require('./crowd.js'), cp = require('child_process');
  const aj = rd('app.js'), hh = rd('index.html'), css = rd('style.css');
  const RUN = path.join(__dirname, '..', '..', 'run');
  // 관광공사가 주는 30곳 이름(표본 그대로) 중 우리 장소와 맞춘 것
  const NAMES30 = ['감추사', '금란정', '냉천공원', '노봉해변', '논골담길', '도째비골 해랑전망대', '도째비골스카이밸리', '동쪽바다중앙시장', '동해 해암정', '동해무릉건강숲', '동해보양온천컨벤션호텔', '동해약천온천실버타운', '동해향교', '두타산', '두타산성', '만경대', '망상해변', '무릉계곡', '무릉별유천지', '묵호등대', '묵호항', '묵호항수변공원', '어달해변', '용산서원(동해)', '전망대활어회센터 (묵호항전망대)', '천곡황금박쥐동굴', '추암 촛대바위', '추암조각공원', '추암해변', '횟집명소거리'];
  const placeIds = new Set(D.places.map((p) => p.id));
  ok(Object.keys(C.NAME2ID).every((n) => NAMES30.includes(n)) && Object.values(C.NAME2ID).every((id) => placeIds.has(id)), '이름 맞추기: 관광공사 이름 16개가 모두 실제 30곳 이름이고, 우리 장소 id 가 모두 있음');
  ok(new Set(Object.values(C.NAME2ID)).size === Object.keys(C.NAME2ID).length, '한 장소에 이름 둘이 겹치지 않음');
  const want = { '도째비골스카이밸리': 'skyvalley', '논골담길': 'nolgol', '묵호등대': 'lighthouse', '묵호항': 'mukhoport', '묵호항수변공원': 'suibyeon', '전망대활어회센터 (묵호항전망대)': 'jeonmangdae', '추암 촛대바위': 'chuam', '추암해변': 'chuambeach', '추암조각공원': 'chuamsculpt', '천곡황금박쥐동굴': 'cheongok', '무릉별유천지': 'byeoryu', '망상해변': 'mangsang', '감추사': 'gamchusa', '노봉해변': 'nobong', '어달해변': 'eodal', '무릉계곡': 'yongchu' };
  ok(Object.keys(want).every((n) => C.NAME2ID[n] === want[n]), '이름 → id 표: ' + Object.entries(want).map(([a, b]) => a.replace(/ \(.*$/, '') + '→' + b).join(' · '));
  ok(!C.NAME2ID['도째비골 해랑전망대'] && !C.NAME2ID['두타산'] && !C.NAME2ID['동쪽바다중앙시장'], '맞는 장소가 없는 곳(해랑전망대·두타산·중앙시장 등)은 쓰지 않음');
  // 등급 40/70
  ok(C.level(39.9) === 'low' && C.level(40) === 'mid' && C.level(70) === 'mid' && C.level(70.1) === 'high' && C.LEVEL_NAME.low === '한산' && C.LEVEL_NAME.mid === '보통' && C.LEVEL_NAME.high === '붐빔', '등급: 한산 < 40 · 보통 40~70 · 붐빔 > 70');
  // 자료 모양
  const mkSpots = (vals) => { const s = {}; Object.keys(C.NAME2ID).forEach((n, i) => { s[n] = {}; Object.keys(vals).forEach((d) => { s[n][d] = vals[d] + (i % 3); }); }); s['두타산'] = { '20261024': 10 }; return s; };
  const data = { ok: true, baseYmd: '20261018', from: '20261018', to: '20261116', spots: mkSpots({ 20261018: 60, 20261022: 30, 20261023: 35, 20261024: 80, 20261025: 66, 20261026: 32, 20261116: 50 }), source: 's' };
  ok(C.valid(data) && !C.valid(null) && !C.valid({ ok: false }) && !C.valid({ ok: true, spots: {} }), '자료 검사: 잘 갖춰졌을 때만 씀');
  ok(C.ratesFor(data, '2026-10-24').skyvalley >= 80 && C.rateFor(data, 'nolgol', '2026-10-24') >= 80 && C.rateFor(data, 'nolgol', '2026-12-24') === null && C.ratesFor(data, '2026-10-17') === null && C.ratesFor(data, '2026-11-17') === null, '예측 범위(오늘~+29일) 안의 날만 값이 나옴 — 밖이면 null(아무것도 안 보임)');
  ok(C.has(data, '20261018') && C.has(data, '20261116') && !C.has(data, '20261117') && C.ymd('2026-10-4') === '20261004' && C.iso('20261004') === '2026-10-04', '날짜 형식: 범위 양 끝 포함 · ymd/iso 바꾸기');
  { const a24 = C.avgFor(data, '2026-10-24'), a22 = C.avgFor(data, '2026-10-22'); ok(a24 > 70 && C.level(a24) === 'high' && C.AVG_NAME.high === '높음' && a22 < 40 && C.avgFor(data, '2026-12-01') === null, '날짜 평균(받은 30곳 평균): 24일 높음 · 22일 한산 · 범위 밖 null: ' + a24 + ' / ' + a22); }
  { const q = C.quieter(data, '2026-10-24', '2026-10-18', P.addDays);
    ok(q && ['2026-10-22', '2026-10-26'].includes(q.iso) && q.level === 'low' && C.avgFor(data, '2026-10-24') - q.avg >= 15, '앞뒤 2일 안에 훨씬 한산한 날이 있으면 알려 줌(가장 한산한 날): ' + (q && q.iso));
    ok(C.quieter(data, '2026-10-22', '2026-10-18', P.addDays) === null, '이미 한산한 날에는 안 알려 줌');
    ok(C.quieter(data, '2026-10-24', '2026-10-25', P.addDays) && C.quieter(data, '2026-10-24', '2026-10-25', P.addDays).iso === '2026-10-26', '오늘 이전 날은 추천하지 않음(오늘이 25일이면 22일 제외)');
    ok(C.quieter(data, '2026-10-25', '2026-10-18', P.addDays) === null || C.avgFor(data, '2026-10-25') - C.quieter(data, '2026-10-25', '2026-10-18', P.addDays).avg >= 15, '큰 차이(15점)가 아니면 알리지 않음'); }
  ok(/기준 2026-10-18/.test(C.sourceLine(data)) && /통신 데이터 기반/.test(C.sourceLine(data)) && /날짜별 예측\(실시간 아님\)/.test(C.sourceLine(data)) && /한국관광공사 관광지 집중률 예측/.test(C.sourceLine(data)), '출처 줄: 한국관광공사 관광지 집중률 예측 · 통신 데이터 기반 · 날짜별 예측(실시간 아님) · 기준 날짜');
  // 서버(run/crowd.mjs · serve.mjs)
  const esm = (code) => JSON.parse(cp.execFileSync(process.execPath, ['--input-type=module', '-e', code], { cwd: RUN, encoding: 'utf8', timeout: 60000 }));
  { const r = esm(`import { parseCrowd, covers, realDate, crowdResponse } from './crowd.mjs';
    const arr = [{ baseYmd: '20261018', tAtsNm: '논골담길', cnctrRate: '83.9' }, { baseYmd: '20261019', tAtsNm: '논골담길', cnctrRate: '38.7' }, { baseYmd: '20261019', tAtsNm: '', cnctrRate: '10' }, { baseYmd: 'abc', tAtsNm: 'x', cnctrRate: '1' }, { baseYmd: '20261019', tAtsNm: 'y', cnctrRate: 'NaN' }];
    const a = parseCrowd(arr), b = parseCrowd({ response: { header: { resultCode: '0000' }, body: { items: { item: arr.slice(0, 2) } } } }), c = parseCrowd(null);
    const bad = []; for (const d of ['abc', '2026', '20261340', '20260230', '2026-10-24', '20261024x']) bad.push((await crowdResponse(d)).status);
    console.log(JSON.stringify({ a, b, c, cov: [covers(a, '20261018'), covers(a, '20261020'), covers(a, '20261017')], real: [realDate('20261024'), realDate('20260229'), realDate('20261301')], bad }));`);
    ok(r.a.spots['논골담길']['20261018'] === 83.9 && Object.keys(r.a.spots).length === 1 && r.a.from === '20261018' && r.a.to === '20261019' && JSON.stringify(r.a) === JSON.stringify(r.b) && Object.keys(r.c.spots).length === 0, '서버 파서: 표본 배열·API 응답 둘 다 읽고, 이름 없음·날짜 이상·숫자 아님 줄은 버림');
    ok(JSON.stringify(r.cov) === '[true,false,false]' && JSON.stringify(r.real) === '[true,false,false]', '범위 검사 · 실제 있는 날짜 검사');
    ok(r.bad.every((s) => s === 400), '/api/crowd?date= 에 이상한 값(글자·짧음·없는 날짜·형식 다름)을 주면 400 (바깥으로 부르지 않음): ' + r.bad.join()); }
  { const r = esm(`import { spawn } from 'node:child_process';
    const p = spawn(process.execPath, ['serve.mjs', '8796'], { stdio: 'ignore' });
    await new Promise((r) => setTimeout(r, 1800));
    const st = []; let body = '';
    try { for (let i = 0; i < 32; i++) { const x = await fetch('http://127.0.0.1:8796/api/crowd?date=zzz'); st.push(x.status); if (i === 0) body = await x.text(); } }
    finally { p.kill(); }
    console.log(JSON.stringify({ first: st[0], n429: st.filter((s) => s === 429).length, last: st[31], body }));`);
    ok(r.first === 400 && r.n429 >= 1 && r.last === 429 && !/serviceKey|datagokr|key/i.test(r.body), '서버 /api/crowd: 다른 /api 와 같은 분당 30회 제한(31번째부터 429) · 응답에 키 없음'); }
  { const src = rd(path.join('..', '..', 'run', 'crowd.mjs')), sv = rd(path.join('..', '..', 'run', 'serve.mjs'));
    ok(/datagokr_key/.test(src) && !/console\.(log|error|warn)/.test(src) && !/(serviceKey=[0-9A-Za-z%]{20,})/.test(src) && /수집캐시/.test(src) && /fetchDay === today/.test(src) && /covers\(disk, today\)/.test(src), 'crowd.mjs: 키는 설정에서 읽기만(출력·적기 없음) · 하루 한 번(한국 날짜) · 받아 둔 범위가 오늘을 덮는지 확인 · 수집캐시 파일');
    ok(/p === '\/api\/crowd'/.test(sv) && sv.indexOf("p === '/api/crowd'") > sv.indexOf('limited(req)') && /DENY_DIR = new Set\(\['수집캐시'/.test(sv), 'serve.mjs: /api/crowd 는 요청 제한 뒤에 있고, 저장 파일(수집캐시)은 밖으로 안 내줌');
    ok(/CROWD_SNAPSHOT/.test(rd('묶음.mjs')) && /getCrowd/.test(rd('묶음.mjs')), '묶음: 만들 때의 집중률을 CROWD_SNAPSHOT 으로 넣음(못 받으면 안 넣음)'); }
  // 계획 부드러운 규칙
  { require('./routes.js');
    const b0 = { now: 540, train: T('18:10'), end: 'mukho', slow: false, avoidStairs: false, interests: [], date: '2026-10-24', routes: RP };
    const a = P.plan(D, b0), c = P.plan(D, { ...b0, crowd: { eodal: 100 } }), at = (pl, id) => pl.stops.find((s) => s.id === id);
    ok(at(c, 'eodal') && (!at(a, 'eodal') || at(c, 'eodal').startVisit < at(a, 'eodal').startVisit - 29) && at(c, 'eodal').startVisit < 720 && at(c, 'eodal').crowdEarly === true, '붐빔 예상 > 80 인 곳(어달해변 100)은 오전으로 앞당겨지고 "아침에 먼저" 표시가 붙음: ' + P.fmt(at(a, 'eodal') ? at(a, 'eodal').startVisit : 0) + ' → ' + P.fmt(at(c, 'eodal').startVisit));
    ok(c.feasible && c.back.arrive <= c.deadline + 1e-9 && JSON.stringify(c.skipped) === JSON.stringify(a.skipped), '마감(기차 15분 전)은 그대로 지킴 · 빠지는 곳 목록도 그대로(하드 제외 없음)');
    ok(!P.plan(D, { ...b0, crowd: { eodal: 80 } }).stops.some((s) => s.crowdEarly) && !P.plan(D, { ...b0, crowd: { eodal: 60, nolgol: 70 } }).stops.some((s) => s.crowdEarly) && JSON.stringify(ids(P.plan(D, { ...b0, crowd: { eodal: 60, nolgol: 70 } }))) === JSON.stringify(ids(a)), '80 이하(정확히 80 포함)는 아무 영향 없음 — 코스 그대로');
    ok(ids(P.plan(D, { ...b0, crowd: {} })).join() === ids(a).join() && ids(P.plan(D, { ...b0, crowdFn: () => null })).join() === ids(a).join(), '예측 값이 없으면 코스가 그대로');
    const crowdAll = {}; D.places.forEach((p) => { crowdAll[p.id] = 100; });
    let bad = 0, cnt = 0; for (const train of ['15:10', '18:10', '19:40']) for (const now of [540, 660, 780]) for (const slow of [true, false]) { const o = { ...b0, now, train: T(train), slow, avoidStairs: slow }, pl = P.plan(D, { ...o, crowd: crowdAll }); cnt++; if (pl.feasible && pl.back.arrive > pl.deadline + 1e-9) bad++; if (pl.feasible && !pl.stops.length) bad++; }
    ok(bad === 0, '모든 곳이 100이어도(극단) ' + cnt + '가지 조합에서 마감 위반 0 · 빈 코스 0');
    const md = P.planDays(D, { ...b0, now: 600, train: T('15:48'), backDate: '2026-10-25', sunrise: true, crowdFn: (iso) => (iso === '2026-10-24' ? { nolgol: 99, skyvalley: 95 } : { eodal: 99 }), routes: RP });
    ok(md.multi && md.days.every((d) => d.plan.back && d.plan.back.arrive <= d.plan.deadline + 1e-9), '여러 날: 날마다 그 날짜의 예측만 쓰고 마감은 모두 지킴'); }
  // 화면 글
  ok(/id="crowdLine"/.test(hh) && /id="crowdQuiet"/.test(hh) && /id="crowdSrc"/.test(hh) && hh.indexOf('crowd.js') < hh.indexOf('app.js') && /이날 붐빔 예상: <b>/.test(aj) && /동해 주요 관광지 평균/.test(aj) && /은 더 한산해요/.test(aj) && /data-cdate/.test(aj), '시작 화면 1단계: "이날 붐빔 예상: 높음/보통/한산 (동해 주요 관광지 평균)" + "○일은 더 한산해요" 단추(누르면 날짜 바꿈)');
  ok(/class="p-cr cr-/.test(aj) && /crowdHtml\(s\)/.test(aj.slice(aj.indexOf('function foldHead'), aj.indexOf('/* 접힌 장은'))) && /붐빌 예정이라 아침에 먼저 \(어림\)/.test(aj) && /'붐빔 예상: ' \+ bz\.map/.test(aj) && /CR\.BUSY/.test(aj), '코스: 접힌 장마다 작은 막대·글(한산/보통/붐빔) · 장 안에 "붐빌 예정이라 아침에 먼저 (어림)" · 주요사항에 "붐빔 예상: ○○ 97"(80 넘을 때만)');
  ok(/\.p-cr\{/.test(css) && /\.crowd-q\{[^}]*min-height:44px/.test(css) && /\.cr-bar/.test(css), 'CSS: 막대 · 한산한 날 단추 44px↑');
  ok(/하루 값이라 아침이 더 한산하다는 건 어림이에요/.test(aj) && /CR\.sourceLine\(S\.crowd\)/.test(aj) && /if \(location\.protocol\.indexOf\('http'\) !== 0\) \{ use\(sn\); return; \}/.test(aj) && /fetch\('\/api\/crowd'/.test(aj), '정직 표시: 출처·기준일 줄 · 아침 부분은 어림 · 서버 → 묶음 사진 → 없으면 안 보임');
  ok(!/serviceKey|datagokr_key/.test(aj + rd('crowd.js') + hh), '화면 코드에는 키 이름·값이 없음');
}

console.log(`\n결과: 통과 ${pass} · 실패 ${fail}`);
process.exit(fail ? 1 : 0);
