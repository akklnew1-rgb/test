// 길 수집: 코스에 쓰는 점(역·볼거리·가게) 사이의 실제 걷는 길·대중교통을 카카오 길찾기 REST 로 미리 받아 routes.js 로 만든다.
//   node 길수집.mjs          (이미 받은 건 길캐시/ 에서 다시 쓴다 — 두 번째부터는 호출 0회)
// - 키는 설정/공공데이터.json 의 kakao_rest_key 만 읽고 어디에도 찍지 않는다. 캐시·routes.js·그림에는 키가 들어가지 않는다(서버쪽 전용).
// - 걷기: 직선 4km 이내 모든 쌍 × (BROAD_FIRST, ACCESSIBLE). 대중교통: 직선 1.2km 초과 쌍(역이 낀 쌍은 어디든, 볼거리끼리는 6km 이내, 가게가 낀 쌍은 4km 이내).
//   자동차(택시 시간): 직선 1.2km 초과 쌍(역이 낀 쌍은 어디든, 볼거리끼리는 10km 이내, 가게가 낀 쌍은 4km 이내) — 카카오모빌리티 길찾기(같은 REST 키). 반대 방향은 뒤집어 쓴다(대칭 가정).
//   범위 밖 쌍도 캐시에 이미 있으면 그 값을 쓴다(새 호출만 막는다). 범위 밖 쌍은 planner.js 가 예전 어림으로 계산한다.
// - 호출 사이 0.15초, 새 호출 상한 520.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const HERE = dirname(fileURLToPath(import.meta.url));
const CACHE = join(HERE, '길캐시');
const IMG = join(HERE, '지도그림');
mkdirSync(CACHE, { recursive: true }); mkdirSync(IMG, { recursive: true });
const KEY = JSON.parse(readFileSync(join(HERE, '..', '..', '설정', '공공데이터.json'), 'utf8')).kakao_rest_key;
if (!KEY) { console.error('kakao_rest_key 가 없습니다'); process.exit(1); }

const require = createRequire(import.meta.url);
const D = require('./places.js'), P = require('./planner.js');
const pts = [...Object.values(D.stations), ...D.places, ...(D.eateries || [])];

const CAP = Number(process.env.CAP) || 520, DELAY = 150, DRY = !!process.env.DRY; // DRY=1 이면 새로 받을 호출 수만 센다
let would = 0;
let calls = 0, cached = 0, failed = 0;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// allowNew=false 이면 캐시에 있을 때만 쓰고, 없으면 호출하지 않고 null
async function api(path, params, bin, allowNew = true) {
  const qs = new URLSearchParams(params).toString();
  const h = createHash('sha1').update(path + '?' + qs).digest('hex').slice(0, 16);
  const f = join(CACHE, h + (bin ? '.png' : '.json'));
  if (existsSync(f)) { cached++; return bin ? f : JSON.parse(readFileSync(f, 'utf8')); }
  if (!allowNew) return null;
  if (DRY) { would++; return null; }
  if (calls >= CAP) throw new Error('호출 상한 ' + CAP);
  await sleep(DELAY); calls++;
  const res = await fetch((path.startsWith('https://') ? '' : 'https://dapi.kakao.com') + path + '?' + qs, { headers: { Authorization: 'KakaoAK ' + KEY } });
  if (bin) {
    if (!res.ok) { failed++; return null; }
    writeFileSync(f, Buffer.from(await res.arrayBuffer())); return f;
  }
  const txt = await res.text();
  if (!res.ok) { failed++; console.log('실패', path, res.status); return null; }
  writeFileSync(f, txt, 'utf8');
  return JSON.parse(txt);
}

// 점 줄이기(Douglas-Peucker) → 최대 n 개
function simplify(pts2, n) {
  if (pts2.length <= n) return pts2;
  const sq = (a, b, c) => { // 점 a 에서 선분 b-c 까지 거리^2
    let x = b[0], y = b[1], dx = c[0] - x, dy = c[1] - y;
    if (dx || dy) { const t = Math.max(0, Math.min(1, ((a[0] - x) * dx + (a[1] - y) * dy) / (dx * dx + dy * dy))); x += t * dx; y += t * dy; }
    return (a[0] - x) ** 2 + (a[1] - y) ** 2;
  };
  let eps = 1e-9;
  for (let k = 0; k < 40; k++) {
    const keep = new Uint8Array(pts2.length); keep[0] = keep[pts2.length - 1] = 1;
    const st = [[0, pts2.length - 1]];
    while (st.length) {
      const [s, e] = st.pop(); let m = -1, md = 0;
      for (let i = s + 1; i < e; i++) { const d = sq(pts2[i], pts2[s], pts2[e]); if (d > md) { md = d; m = i; } }
      if (m >= 0 && md > eps) { keep[m] = 1; st.push([s, m], [m, e]); }
    }
    const out = pts2.filter((_, i) => keep[i]);
    if (out.length <= n) return out;
    eps *= 1.6;
  }
  return [pts2[0], pts2[pts2.length - 1]];
}
const r5 = (v) => Math.round(v * 1e5) / 1e5;
const fixPath = (p) => p.map((q) => [r5(q[0]), r5(q[1])]); // [경도, 위도]
function dedupe(p) { return p.filter((q, i) => i === 0 || q[0] !== p[i - 1][0] || q[1] !== p[i - 1][1]); }

// 길찾기에 쓰는 좌표: 걷는 길 끝이라 도로에서 못 찾는 곳(무릉계곡 용추폭포)은 입구(routeAt)로
const at = (p) => p.routeAt || p;
async function walk(a0, b0, mode, allowNew) {
  const a = at(a0), b = at(b0); if (a === b || (a.lat === b.lat && a.lng === b.lng)) return null;
  const j = await api('/v2/routing/walk', { start_x: a.lng, start_y: a.lat, end_x: b.lng, end_y: b.lat, route_mode: mode }, false, allowNew);
  if (!j || j.status !== 'OK' || !j.route) return null;
  const pr = j.route.properties || {};
  let path = [];
  (j.route.legs || []).forEach((l) => (l.steps || []).forEach((s) => { if (s.path && s.path.points) path = path.concat(s.path.points); }));
  path = dedupe(path);
  if (!(pr.totalTime > 0)) return null;
  // 길 안내 토막(2026-10-17 실시간 안내): 단계마다 [경도, 위도, 거리 m, 안내 글]. 이미 받아 둔 응답에서만 뽑는다(새 호출 없음). 반대 방향으로는 뒤집어 쓸 수 없어 한 방향만 쓴다.
  const steps = [];
  (j.route.legs || []).forEach((l) => (l.steps || []).forEach((s) => { const sp = s.properties || {}; if (sp.guidance && sp.x != null && sp.y != null) steps.push([r5(sp.x), r5(sp.y), Math.round(sp.distance || 0), String(sp.guidance)]); }));
  return { sec: Math.round(pr.totalTime), m: Math.round(pr.totalDistance), path: fixPath(simplify(path, 40)), ...(steps.length ? { steps } : {}) };
}

async function transit(a0, b0, allowNew) {
  const a = at(a0), b = at(b0); if (a === b || (a.lat === b.lat && a.lng === b.lng)) return null;
  const j = await api('/v2/routing/publictraffic', { start_x: a.lng, start_y: a.lat, end_x: b.lng, end_y: b.lat }, false, allowNew);
  if (!j || j.status !== 'OK' || !j.routes || !j.routes.length) return null;
  const r = j.routes.slice().sort((x, y) => x.properties.totalTime - y.properties.totalTime)[0];
  const pr = r.properties || {};
  let walkSec = 0; const lines = [];
  let path = [];
  (r.steps || []).forEach((s) => {
    const sp = s.properties || {};
    if (sp.type === 'WALKING') walkSec += sp.time || 0;
    else if (sp.type === 'BUS' || sp.type === 'SUBWAY' || sp.type === 'TRAIN') {
      (sp.vehicles || []).slice(0, 1).forEach((v) => { if (v && v.name) lines.push(String(v.name).replace(/번$/, '')); });
    }
    if (s.path && s.path.points) path = path.concat(s.path.points);
  });
  if (r.path && r.path.points && !path.length) path = r.path.points;
  path = dedupe(path);
  const transfers = pr.transfers != null ? pr.transfers : Math.max(0, lines.length - 1);
  const summary = (lines.length ? '버스 ' + lines.join('→') + '번' : '대중교통') + ' · 환승 ' + transfers + '회';
  return { sec: Math.round(pr.totalTime), m: Math.round(pr.totalDistance), transfers, fare: pr.fare && pr.fare.value != null ? pr.fare.value : null, summary, walkSec: Math.round(walkSec), path: fixPath(simplify(path, 40)) };
}

// 자동차(택시) 길: 카카오모빌리티 길찾기. 시간(초)·거리(m)·길(점 40개 이하)
async function drive(a0, b0, allowNew) {
  const a = at(a0), b = at(b0); if (a === b || (a.lat === b.lat && a.lng === b.lng)) return null;
  const j = await api('https://apis-navi.kakaomobility.com/v1/directions', { origin: a.lng + ',' + a.lat, destination: b.lng + ',' + b.lat, priority: 'RECOMMEND' }, false, allowNew);
  const r = j && j.routes && j.routes[0];
  if (!r || r.result_code !== 0 || !r.summary || !(r.summary.duration > 0)) return null;
  let path = [];
  (r.sections || []).forEach((s) => (s.roads || []).forEach((rd) => { const v = rd.vertexes || []; for (let i = 0; i + 1 < v.length; i += 2) path.push([v[i], v[i + 1]]); }));
  path = dedupe(path);
  return { sec: Math.round(r.summary.duration), m: Math.round(r.summary.distance), path: fixPath(simplify(path, 40)) };
}

// 어디까지 새로 받을지(직선 km). 역이 낀 쌍은 제한 없음.
const isSt = (p) => !!D.stations[p.id], isEat = (p) => String(p.id).startsWith('eat_');
const limTransit = (a, b) => (isSt(a) || isSt(b)) ? 99 : (isEat(a) || isEat(b)) ? 4 : 6;
const limDrive = (a, b) => (isSt(a) || isSt(b)) ? 99 : (isEat(a) || isEat(b)) ? 4 : 10;

// 자가용 점(park)은 대중교통을 받지 않고(자가용 모드는 걷기·자동차만), 버스 터미널(bus)·주차장(park)의 걷기는 직선 2.5km 이내만 받는다(2026-10-17)
const isNew = (p) => p.id === 'bus' || p.id === 'park';
const walkLim = (a, b) => (isNew(a) || isNew(b)) ? 2.5 : 4;
const noTransit = (a, b) => a.id === 'park' || b.id === 'park';
const ROUTES = {};
let walkPairs = 0, transitPairs = 0, drivePairs = 0;
for (let i = 0; i < pts.length; i++) {
  for (let j = i + 1; j < pts.length; j++) {
    const a = pts[i], b = pts[j], d = P.hav(a, b);
    const key = a.id + '|' + b.id; // 입력 순서(i<j)의 한 방향만 저장, 반대는 쓰는 쪽에서 뒤집음
    const rec = {};
    try {
      if (d <= walkLim(a, b)) {
        const w = await walk(a, b, 'BROAD_FIRST'); if (w) rec.walk = w;
        const wa = await walk(a, b, 'ACCESSIBLE'); if (wa) rec.walkAccessible = wa;
        if (rec.walk) walkPairs++;
      }
      if (d > 1.2) {
        const t = await transit(a, b, d <= limTransit(a, b) && !noTransit(a, b)); if (t) { rec.transit = t; transitPairs++; }
        const dv = await drive(a, b, d <= limDrive(a, b)); if (dv) { rec.drive = dv; drivePairs++; }
      }
    } catch (e) { console.log('중단:', e.message); }
    if (rec.walk || rec.walkAccessible || rec.transit || rec.drive) ROUTES[key] = rec;
  }
}

writeFileSync(join(HERE, 'routes.js'),
  '// 자동 생성: node 길수집.mjs — 카카오 길찾기 REST(걷기·대중교통)를 미리 받은 값. 직접 고치지 말 것. [경도,위도] 순서, 한 방향만 저장(반대는 뒤집어 씀)\n' +
  '(typeof window !== "undefined" ? window : globalThis).ROUTES = ' + JSON.stringify({ generated: new Date().toISOString().slice(0, 10), source: '카카오 길찾기', pairs: ROUTES }) + ';\n', 'utf8');

// 정적 지도 그림(지도를 못 불러올 때 대신 보여 줄 PNG). 카카오 정적 지도의 markers 는 위치를 무시하고 가운데에만 찍히므로 쓰지 않고,
// 화면(app.js)이 center·lv 로 계산한 위치에 번호·선을 얹는다. 해상도: lv 5 = CSS 1픽셀 4m(그림은 2배 크기로 받음) → lv 마다 2배.
const MAPS = [
  { id: 'mukho', file: '묵호.png', center: [129.1175, 37.5585], lv: 6, w: 600, h: 420 },
  { id: 'wide', file: '동해넓게.png', center: [129.13, 37.499], lv: 7, w: 600, h: 420 },
  { id: 'all', file: '묵호추암.png', center: [129.125, 37.515], lv: 8, w: 600, h: 420 },
  { id: 'far', file: '동해전체.png', center: [129.07, 37.525], lv: 9, w: 600, h: 420 } // 망상·삼화·추암까지 한 장에 (맨 마지막 = 가장 넓은 그림)
];
for (const m of MAPS) {
  const f = await api('/v2/maps/staticmap', { size: m.w + 'x' + m.h, center: m.center.join(','), lv: String(m.lv) }, true);
  if (f) writeFileSync(join(IMG, m.file), readFileSync(f)); else m.missing = true;
  m.mPerPx = 4 * Math.pow(2, m.lv - 5);
}
const rjs = readFileSync(join(HERE, 'routes.js'), 'utf8').replace('.ROUTES = {', '.ROUTES = {"maps":' + JSON.stringify(MAPS.filter((m) => !m.missing).map((m) => ({ ...m, src: '지도그림/' + m.file }))) + ',');
writeFileSync(join(HERE, 'routes.js'), rjs, 'utf8');

console.log(JSON.stringify({ 새호출예정_DRY: DRY ? would : undefined, 새호출: calls, 캐시사용: cached, 실패: failed, 걷기쌍: walkPairs, 대중교통쌍: transitPairs, 자동차쌍: drivePairs, 저장쌍: Object.keys(ROUTES).length, 그림: MAPS.map((m) => m.file + (m.missing ? '(실패)' : '')) }));
