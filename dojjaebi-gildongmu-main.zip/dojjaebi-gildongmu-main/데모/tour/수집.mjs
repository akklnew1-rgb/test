// 한국관광공사 TourAPI(KorService2)로 동해시 관광지·음식점 자료를 받아 places.js 를 만든다.
// 키는 설정/공공데이터.json 의 datagokr_key — 화면·로그·places.js 어디에도 찍지 않는다.
// 하는 일(호출은 190회 이하, 호출 사이 0.15초 쉼):
//   1) areaBasedList2(동해시 areaCode 32·sigunguCode 3)와 locationBasedList2(묵호역 둘레 6km)로 목록(관광지 12·문화시설 14·음식점 39·축제 15·레포츠 28)을 모은다.
//   2) places.base.mjs 의 장소·가게를 이름(tour.title)으로 찾고, 목록에 없으면 searchKeyword2 로 한 번 더 찾는다.
//   3) 찾은 곳은 detailCommon2(좌표·주소·사진·개요 원문) + detailIntro2(운영시간·쉬는 날 / 음식점은 대표메뉴·영업시간)를 받아 채운다.
// 못 찾았거나 API 가 실패하면 손으로 적은 기본 자료 그대로 쓰고 확인필요 로 둔다. 역(station)은 손으로 적은 좌표를 쓴다.
import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { STATIONS, PLACES, EATERIES, TRAINS, SUNRISE } from './places.base.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = dirname(dirname(here));
let key = '';
try { key = JSON.parse(readFileSync(join(root, '설정', '공공데이터.json'), 'utf8')).datagokr_key || ''; } catch { /* 키 없음 */ }

const BASE = 'https://apis.data.go.kr/B551011/KorService2';
// 받은 응답은 수집캐시/ 에 하루 동안 둔다(places.base.mjs 만 고쳐 다시 돌릴 때 호출을 아끼려고). 새로 받으려면: node 수집.mjs --fresh. 캐시에는 키가 들어가지 않는다(키 빼고 이름을 짓고 응답 본문만 저장).
const CACHE = join(here, '수집캐시');
const FRESH = process.argv.includes('--fresh');
mkdirSync(CACHE, { recursive: true });
const MAX_CALLS = 190;
let calls = 0, cached = 0;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const redact = (s) => (key ? String(s).split(key).join('***') : String(s));
const km = (a, b) => {
  const R = 6371, r = (x) => (x * Math.PI) / 180;
  const dLat = r(b.lat - a.lat), dLng = r(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};

async function call(op, params) {
  const cf = join(CACHE, createHash('sha1').update(op + JSON.stringify(params)).digest('hex').slice(0, 16) + '.json');
  if (!FRESH && existsSync(cf) && Date.now() - statSync(cf).mtimeMs < 24 * 3600 * 1000) { cached++; return JSON.parse(readFileSync(cf, 'utf8')); }
  if (calls >= MAX_CALLS) throw new Error('호출 한도(' + MAX_CALLS + ')에 도달');
  calls++;
  await sleep(150);
  const u = new URL(`${BASE}/${op}`);
  u.searchParams.set('serviceKey', key);
  u.searchParams.set('MobileOS', 'ETC');
  u.searchParams.set('MobileApp', 'glab-donghae');
  u.searchParams.set('_type', 'json');
  for (const [k, v] of Object.entries(params)) u.searchParams.set(k, String(v));
  let res;
  try { res = await fetch(u, { signal: AbortSignal.timeout(15000) }); } catch (e) { throw new Error(`${op} 연결 실패 ${redact(e.message)}`); }
  const text = await res.text();
  if (!res.ok) throw new Error(`${op} HTTP ${res.status}`);
  let j; try { j = JSON.parse(text); } catch { throw new Error(`${op} 응답이 JSON 아님`); }
  const code = j?.response?.header?.resultCode;
  if (code && code !== '0000') throw new Error(`${op} 결과코드 ${code} ${j?.response?.header?.resultMsg || ''}`);
  const it = j?.response?.body?.items?.item;
  const arr = Array.isArray(it) ? it : it ? [it] : [];
  try { writeFileSync(cf, JSON.stringify(arr), 'utf8'); } catch { /* 캐시 못 써도 계속 */ }
  return arr;
}

// ---------- 1) 목록 모으기 ----------
const pool = new Map(); // contentid -> 목록 항목
const notes = [];
async function collect(label, op, params) {
  try {
    const items = await call(op, params);
    items.forEach((a) => { if (!pool.has(String(a.contentid))) pool.set(String(a.contentid), a); });
    notes.push(`${label} ${items.length}`);
  } catch (e) { notes.push(`${label} 실패(${redact(e.message)})`); }
}
if (key) {
  for (const t of [12, 14, 39, 15, 38]) await collect(`동해시 목록 ${t}`, 'areaBasedList2', { areaCode: 32, sigunguCode: 3, contentTypeId: t, numOfRows: 200, pageNo: 1 });
  for (const t of [12, 14, 39, 15, 28]) await collect(`묵호역 6km ${t}`, 'locationBasedList2', { mapX: STATIONS.mukho.lng, mapY: STATIONS.mukho.lat, radius: 6000, contentTypeId: t, numOfRows: 100, pageNo: 1 });
}
const status = key ? `TourAPI 목록 ${pool.size}곳 (${notes.join(' · ')})` : '키 없음';
console.log(status);

const norm = (s) => String(s || '').replace(/\s+/g, '');
async function findItem(tour) {
  const want = norm(tour.title);
  let hit = [...pool.values()].find((a) => norm(a.title) === want);
  if (!hit && key) {
    // 지역 필터를 걸면 빠지는 항목이 있어(묵호등대 등) 필터 없이 한 번 더 찾고, 주소가 동해시인 것만 쓴다
    const pick = (r) => r.find((a) => norm(a.title) === want && /동해시/.test(a.addr1 || '')) || r.find((a) => /동해시/.test(a.addr1 || '') && (norm(a.title).includes(want) || want.includes(norm(a.title))));
    for (const area of [{ areaCode: 32, sigunguCode: 3 }, {}]) {
      try {
        hit = pick(await call('searchKeyword2', { keyword: tour.kw || tour.title, ...area, numOfRows: 20, pageNo: 1 }));
        if (hit) break;
      } catch (e) { notes.push('검색 실패 ' + redact(e.message)); }
    }
  }
  return hit || null;
}
async function detail(hit, typeHint) {
  const id = String(hit.contentid), type = +hit.contenttypeid || typeHint;
  let common = null, intro = null;
  try { common = (await call('detailCommon2', { contentId: id }))[0] || null; } catch (e) { notes.push('공통 실패 ' + redact(e.message)); }
  try { intro = (await call('detailIntro2', { contentId: id, contentTypeId: type }))[0] || null; } catch (e) { notes.push('소개 실패 ' + redact(e.message)); }
  return { id, type, common: common || hit, intro: intro || {} };
}

// ---------- 보조 ----------
const clean = (s) => String(s || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/\r/g, '').trim();
const hhmm = (m) => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
/* 운영시간 글에서 시각 범위를 읽는다. 계절마다 달라도 안전한 쪽(늦게 열고 일찍 닫는 쪽)으로 모은다.
   "점검·준비·브레이크" 앞에 붙은 범위는 쉬는 시간(brk)으로 따로 둔다. 읽을 수 없으면 ok:false. */
function parseHours(raw) {
  const t = clean(raw);
  const re = /(\d{1,2}):(\d{2})\s*[~\-–]\s*(\d{1,2}):(\d{2})/g;
  const mains = [], brks = []; let m, bad = false;
  while ((m = re.exec(t))) {
    const r = [+m[1] * 60 + +m[2], +m[3] * 60 + +m[4]];
    if (r[1] <= r[0]) { bad = true; continue; }
    (/점검|준비|브레이크|휴게|휴식|쉬는/.test(t.slice(Math.max(0, m.index - 12), m.index)) ? brks : mains).push(r);
  }
  if (!mains.length) {
    if (/상시\s*개방|24\s*시간|연중\s*개방|항시/.test(t)) return { ok: true, open: [0, 1440], text: '상시 개방', brk: null, multi: false };
    return { ok: false };
  }
  if (bad) return { ok: false };
  const open = [Math.max(...mains.map((r) => r[0])), Math.min(...mains.map((r) => r[1]))];
  if (open[1] <= open[0]) return { ok: false };
  const multi = new Set(mains.map((r) => r.join('-'))).size > 1;
  return { ok: true, open, text: `${hhmm(open[0])}~${hhmm(open[1])}`, brk: brks[0] || null, multi };
}
const restOf = (raw) => clean(raw).split('※')[0].replace(/\s+/g, ' ').trim();
const SOFT = /죽|순두부|계란찜|국수|칼국수|수제비|곰치국|미역국|만둣국|떡국/;
const josa = (w, a, b) => { const c = String(w).replace(/[^가-힣0-9A-Za-z]+$/, '').slice(-1); if (!c) return b; const code = c.charCodeAt(0); if (code >= 0xac00 && code <= 0xd7a3) return (code - 0xac00) % 28 ? a : b; return /[013678lmnrLMNR]/.test(c) ? a : b; };
const OK_COPY = new Set(['Type1', 'Type3']); // 공공누리 제1유형(출처표시)·제3유형(출처표시+변경금지)만 사진을 보여 준다
// 사진은 원본 바이트 그대로 사진캐시/<contentid>.<확장자> 에 한 번만 받는다(이미 있으면 다시 받지 않음). 고치지 않는다(제3유형 변경금지).
const PHOTO_DIR = join(here, '사진캐시');
mkdirSync(PHOTO_DIR, { recursive: true });
const IMG_EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp' };
async function fetchPhoto(id, url) {
  const have = readdirSync(PHOTO_DIR).find((f) => f.replace(/\.[^.]+$/, '') === String(id));
  if (have && statSync(join(PHOTO_DIR, have)).size > 1000) return { file: have, fresh: false };
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(30000) });
    const ct = (r.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
    if (!r.ok) return null;
    const buf = Buffer.from(await r.arrayBuffer());
    if (buf.length < 1000) return null;
    // 확장자는 파일 첫 바이트로 정한다(서버가 image/jpg 처럼 틀린 이름을 주기도 함). 바이트는 그대로 저장.
    const ext = buf[0] === 0xff && buf[1] === 0xd8 ? 'jpg' : buf.slice(1, 4).toString() === 'PNG' ? 'png' : buf.slice(0, 3).toString() === 'GIF' ? 'gif' : buf.slice(8, 12).toString() === 'WEBP' ? 'webp' : '';
    if (!ext || !/image/i.test(ct)) return null;
    const file = id + '.' + ext;
    writeFileSync(join(PHOTO_DIR, file), buf);
    return { file, fresh: true };
  } catch { return null; }
}
async function photoOf(common) {
  const raw = String(common.firstimage || '').trim();
  const type = String(common.cpyrhtDivCd || '');
  if (!raw) return { photo: '', why: '사진 없음' };
  if (!OK_COPY.has(type)) return { photo: '', why: `공공누리 유형 ${type || '없음'}` };
  const https = raw.replace(/^http:\/\//i, 'https://');
  const got = await fetchPhoto(common.contentid, https);
  if (!got) return { photo: '', why: '사진 받기 실패' };
  return { photo: '사진캐시/' + got.file, why: '', type };
}

// ---------- 2) 장소 ----------
const log = [];
const places = [];
for (const p of PLACES) {
  const { tour, storyReal, noPhoto, ...rest } = p; // noPhoto: 사진은 아직 넣지 않는 곳(2026-10-17 추가분)
  const out = { ...rest };
  const hit = tour && key ? await findItem(tour) : null;
  if (!hit) { out.좌표확인필요 = true; out.확인필요 = true; places.push(out); log.push(`${p.id}: 못 찾음(손으로 적은 대략값)`); continue; }
  const d = await detail(hit, tour.type);
  const c = d.common;
  out.lat = +c.mapy; out.lng = +c.mapx; out.좌표확인필요 = false;
  if (p.coordKeep) { out.lat = p.lat; out.lng = p.lng; out.coordSource = p.coordKeep; } // 손으로 확인한 좌표를 지킴(관광공사 좌표가 정문과 어긋난 곳)
  out.contentid = d.id; out.tourapi = { contentid: d.id, title: c.title, type: d.type };
  out.addr = [c.addr1, c.addr2].filter(Boolean).join(' ').trim();
  out.원문 = clean(c.overview);
  out.출처 = '한국관광공사 관광정보';
  if (storyReal && out.원문) out.story = storyReal;
  const h = parseHours(d.intro.usetime);
  if (h.ok) {
    out.open = h.open;
    out.openText = h.text + (h.multi ? ' (계절마다 달라 짧은 쪽 기준)' : '') + ' · 관광공사 자료';
    out.확인필요 = false;
  } else { out.확인필요 = true; }
  const rest1 = restOf(d.intro.restdate); if (rest1) out.restText = rest1;
  const ph = await photoOf(c);
  if (ph.photo) { out.photo = ph.photo; out.photoType = ph.type; }
  log.push(`${p.id}: ${c.title} (${d.id}) 좌표 O · 운영시간 ${h.ok ? h.text : '읽지 못함→대략값'} · 사진 ${ph.photo ? '쓰기(' + ph.type + ')' : '안 씀(' + ph.why + ')'}`);
  places.push(out);
}

// ---------- 3) 음식점 ----------
const eateries = [];
for (const e of EATERIES) {
  const { tour, fallbackName, ...rest } = e;
  const out = { ...rest, name: fallbackName, menu: [], openText: '방문 전 확인', open: [660, 1200], 확인필요: true, 좌표확인필요: true };
  const hit = tour && key ? await findItem(tour) : null;
  if (!hit) { log.push(`${e.id}: 못 찾음(자료 없음)`); eateries.push(out); continue; }
  const d = await detail(hit, 39);
  const c = d.common, i = d.intro;
  out.name = c.title; out.lat = +c.mapy; out.lng = +c.mapx; out.좌표확인필요 = false;
  out.contentid = d.id; out.tourapi = { contentid: d.id, title: c.title, type: 39 };
  out.addr = [c.addr1, c.addr2].filter(Boolean).join(' ').trim();
  out.원문 = clean(c.overview);
  const km0 = km(STATIONS.mukho, out);
  out.거리km = Math.round(km0 * 10) / 10;
  // 메뉴: 대표메뉴 + 취급메뉴(이름만. 값은 자료에 없으면 적지 않는다)
  const first = clean(i.firstmenu), others = clean(i.treatmenu).split(/[\/,\n]/).map((x) => x.replace(/\s*등$/, '').trim()).filter(Boolean);
  const names = [...new Set([first, ...others].filter(Boolean))].slice(0, 6);
  out.menu = names.map((n) => ({ name: n, soft: SOFT.test(n), ...(n === first ? { 대표: true } : {}) }));
  out.soft = !!first && SOFT.test(first); // 대표메뉴 이름이 분명히 부드러운 음식일 때만
  out.category = first || '음식점';
  const h = parseHours(i.opentimefood);
  if (h.ok) {
    out.open = h.open; out.brk = h.brk;
    out.openText = h.text + (h.brk ? ` (쉬는 시간 ${hhmm(h.brk[0])}~${hhmm(h.brk[1])})` : '');
  } else { out.openText = clean(i.opentimefood) || '방문 전 확인'; }
  const rest1 = restOf(i.restdatefood); if (rest1) out.restText = rest1;
  const loc = String(c.addr1 || '').replace(/^강원특별자치도\s*/, '');
  const where = loc ? `${loc}에 있는` : '묵호 둘레에 있는';
  const second = names.filter((n) => n !== first).slice(0, 3);
  let story = `${out.short}${josa(out.short, '은', '는')} ${where} 음식점이에요.`;
  if (first) story += ` 대표 메뉴는 ${first}${josa(first, '이에요', '예요')}.`;
  if (second.length) story += ` ${second.join(', ')} 같은 메뉴도 있어요.`;
  if (out.restText) story += /무휴/.test(out.restText) ? ' 연중무휴예요.' : ` 쉬는 날은 ${out.restText.replace(/[.\s]+$/, '')}${josa(out.restText.replace(/[.\s]+$/, ''), '이에요', '예요')}.`;
  out.story = story;
  const ph = await photoOf(c);
  if (ph.photo) { out.photo = ph.photo; out.photoType = ph.type; }
  log.push(`${e.id}: ${c.title} (${d.id}) 묵호역에서 ${out.거리km}km · 메뉴 ${out.menu.length} · 영업 ${out.openText} · soft ${out.soft} · 사진 ${ph.photo ? '쓰기(' + ph.type + ')' : '안 씀(' + ph.why + ')'}`);
  eateries.push(out);
}

log.forEach((l) => console.log('  ' + l));
const matched = places.filter((p) => p.tourapi).length;
const matchedEat = eateries.filter((e) => e.tourapi).length;
console.log(`TourAPI 와 짝지은 장소 ${matched}/${places.length} · 음식점 ${matchedEat}/${eateries.length} · 호출 ${calls}회 (캐시 ${cached}회)`);
notes.filter((n) => /실패/.test(n)).forEach((n) => console.log('  주의: ' + n));

const data = {
  generated: new Date().toISOString().slice(0, 10), apiStatus: status, matched, matchedEateries: matchedEat, apiCalls: calls,
  photoNote: '사진: 한국관광공사 · 공공누리 (제1·제3유형만 사용, 제3유형은 변경금지)',
  stations: STATIONS, places, eateries, trains: TRAINS, sunrise: SUNRISE,
};
const js = `// 자동 생성: node 수집.mjs (${data.generated}) — 직접 고치지 말고 places.base.mjs 를 고칠 것\n` +
  `(function(root){var D=${JSON.stringify(data, null, 1)};\n` +
  `if(typeof module!=='undefined'&&module.exports)module.exports=D;else root.TOUR_DATA=D;})(typeof window!=='undefined'?window:globalThis);\n`;
writeFileSync(join(here, 'places.js'), js, 'utf8');
console.log('places.js 저장');
