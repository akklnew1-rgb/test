// 폰 한 파일 묶음: tour/index.html 을 읽어 style.css 와 스크립트(routes.js 포함)를 안에 넣고, 정적 지도 그림은 data URI 로 넣는다.
//   node 묶음.mjs [나가는 파일]      (기본: 프로젝트 도구/발행/dokkaebi-demo.html — 어느 PC 에서나 같은 곳) — 게시하지 않고 파일만 쓴다.
// 사진: places.js 의 "photo": "사진캐시/…" 를 원본 바이트 그대로 base64 data URI 로 넣는다(다시 인코딩·크기 조절 없음). 묶음이 12MB(12,000,000바이트)를 넘으면 가장 큰 제1유형 사진부터 빼고 목록을 찍는다(빠진 곳은 그림). 제3유형은 빼지 않는다.
// 키 검사: 카카오 REST 키가 묶음에 들어갔는지 값으로 찾는다(값은 찍지 않는다). 들어갔으면 파일을 지우고 중단.
import { readFileSync, writeFileSync, unlinkSync, statSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const TOUR = dirname(fileURLToPath(import.meta.url));
// 날씨·기차 시간표 사진: 묶음을 만들 때 서버 코드(run/weather.mjs · run/trains.mjs, 같은 코드)로 한 번 받아 넣는다. 못 받으면 넣지 않는다(화면이 안내 글로 대신). 키는 이 코드 안에서만 쓰이고 결과에는 들어가지 않는다.
const RUN = new URL('../../run/', import.meta.url);
let WX = null, TR = null, CRD = null;
try {
  const kst = (d) => new Date(d.getTime() + 9 * 3600e3);
  const { getWeather } = await import(new URL('weather.mjs', RUN).href);
  const w = await getWeather();
  if (w && !w.error && w.temp != null) { const t = kst(new Date()); WX = { ...w, label: `${t.getUTCMonth() + 1}월 ${t.getUTCDate()}일 ${parseInt(w.baseTime, 10)}시 기준(묶음 만든 때)` }; }
  const { getTrains } = await import(new URL('trains.mjs', RUN).href);
  const dates = {}, now = new Date();
  for (let k = 0; k < 4; k++) {
    const t = kst(new Date(now.getTime() + k * 86400e3)), ymd = `${t.getUTCFullYear()}${String(t.getUTCMonth() + 1).padStart(2, '0')}${String(t.getUTCDate()).padStart(2, '0')}`, iso = `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}`;
    const a = await getTrains(ymd, '묵호', '청량리'), b = await getTrains(ymd, '동해', '서울');
    if ((a.ok && a.list.length) || (b.ok && b.list.length)) dates[iso] = { mukho: a.ok ? a.list : [], donghae: b.ok ? b.list : [] };
  }
  if (Object.keys(dates).length) { const t = kst(now); TR = { builtAt: `${t.getUTCMonth() + 1}월 ${t.getUTCDate()}일`, dates }; }
} catch (e) { console.error('날씨·시간표 사진은 못 받아서 넣지 않음:', e.message); }
// 관광지 집중률 예측(한국관광공사): 묶음 만들 때의 값을 CROWD_SNAPSHOT 으로(기준일이 값 안에 있어 화면에 "기준 ○○" 으로 나온다). 못 받으면 넣지 않는다.
try {
  const { getCrowd } = await import(new URL('crowd.mjs', RUN).href);
  const c = await getCrowd();
  if (c && c.ok && c.spots) CRD = { ok: true, baseYmd: c.baseYmd, from: c.from, to: c.to, spots: c.spots, source: c.source };
} catch (e) { console.error('집중률 예측은 못 받아서 넣지 않음:', e.message); }
const DEFAULT_OUT = new URL('../../도구/발행/dokkaebi-demo.html', import.meta.url);
const OUT = process.argv[2] || DEFAULT_OUT;
const html = readFileSync(join(TOUR, 'index.html'), 'utf8');

const title = (html.match(/<title>[^<]*<\/title>/) || ['<title>도째비 길동무</title>'])[0];
const fontLinks = (html.match(/<link[^>]*>/g) || []).filter((t) => /fonts\.(googleapis|gstatic)\.com/.test(t));
const bodyClass = (html.match(/<body[^>]*class="([^"]*)"/) || [, ''])[1];
// 본문: <body ...> 다음부터 첫 <script 직전까지
const bodyStart = html.indexOf('>', html.indexOf('<body')) + 1;
const firstScript = html.indexOf('<script', bodyStart);
let body = html.slice(bodyStart, firstScript).trim();
body = body.replace('href="index.html#watch" target="_blank" rel="noopener"', 'href="#watch"');

const css = readFileSync(join(TOUR, 'style.css'), 'utf8');
// index.html 에 적힌 스크립트 순서를 따른다 (../지도키.js 는 뺀다)
const srcs = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)].map((m) => m[1]).filter((s) => !s.includes('지도키'));
let embedded = 0;
const LIMIT = 12000000; // 묶음 전체 12MB(12,000,000바이트) 미만
const MIME = { jpg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp' };
const EATPH = []; // 식당 사진: 코스·화면 어디에도 식당을 보여 주지 않게 되어(2026-10-18) 묶음에는 넣지 않는다 → 그만큼 대표 사진(묵호항 등)을 더 넣을 수 있다
const NAMES = (() => { // 사진 파일 → 장소 id·공공누리 유형 (보고용·빼는 순서용)
  const D = createRequire(import.meta.url)(join(TOUR, 'places.js')); const m = {};
  [...D.places, ...(D.eateries || [])].forEach((p) => { if (p.photo) m[p.photo] = { id: p.id, type: p.photoType, size: statSync(join(TOUR, p.photo)).size }; });
  (D.eateries || []).forEach((p) => { if (p.photo) EATPH.push(p.photo); });
  return m;
})();
/* places.js 의 "photo": "사진캐시/…" 를 원본 바이트 그대로 data URI 로. drop 에 든 파일은 photo·photoType 을 지워 그림으로 대신한다. */
function embedPhotos(t, drop) {
  for (const fl of drop) {
    const at = t.indexOf('"photo": "' + fl + '"'); if (at < 0) continue;
    const start = t.lastIndexOf(',', at), m = /^"photo": "[^"]*",\s*"photoType": "Type[13]"/.exec(t.slice(at));
    if (!m) throw new Error('photo 줄 모양이 달라 뺄 수 없음: ' + fl);
    t = t.slice(0, start) + t.slice(at + m[0].length);
  }
  return t.replace(/"photo": "(사진캐시\/[^"]+)"/g, (_, fl) => '"photo": "data:' + (MIME[fl.split('.').pop().toLowerCase()] || 'image/jpeg') + ';base64,' + readFileSync(join(TOUR, fl)).toString('base64') + '"');
}
function build(drop) {
  embedded = 0;
  const js = srcs.map((s) => {
    let t = readFileSync(join(TOUR, s), 'utf8');
    if (s === 'places.js') t = embedPhotos(t, drop);
    if (s === 'app.js') { // 보기 창이 막는 '파일 내려받기 링크'(DL-BEGIN~DL-END)는 묶음에서 뺀다 → 저장 기능이 있으면 그것을, 없으면 그림을 화면에 띄워 길게 눌러 저장
      const a = t.indexOf('/*DL-BEGIN*/'), b = t.indexOf('/*DL-END*/');
      if (a < 0 || b < a) throw new Error('app.js 에 DL-BEGIN/DL-END 블록이 없음');
      t = t.slice(0, a) + 'function plainDownload() { return false; }' + t.slice(b + '/*DL-END*/'.length);
      if (/.downloads*=|download=/.test(t)) throw new Error('묶음에 파일 내려받기 링크가 남아 있음');
    }
    if (s === 'routes.js') { // 정적 지도 그림 → data URI
      t = t.replace(/"src":"(지도그림\/[^"]+)"/g, (_, f) => { embedded++; return '"src":"data:image/png;base64,' + readFileSync(join(TOUR, f)).toString('base64') + '"'; });
    }
    if (t.includes('</script')) throw new Error(s + ' 안에 </script 가 있음');
    return '<script>\n' + t + '\n</script>';
  });
  if (css.includes('</style')) throw new Error('css 안에 </style 이 있음');
  const viewport = (html.match(/<meta[^>]*name="viewport"[^>]*>/) || ['<meta name="viewport" content="width=device-width, initial-scale=1">'])[0];
  return [title, viewport, ...fontLinks, '<style>\n' + css + '\n</style>',
    `<script>window.KAKAO_JS_KEY="";window.TOUR_BUNDLE=true;${WX ? 'window.WX_SNAPSHOT=' + JSON.stringify(WX) + ';' : ''}${TR ? 'window.TRAIN_SNAPSHOT=' + JSON.stringify(TR) + ';' : ''}${CRD ? 'window.CROWD_SNAPSHOT=' + JSON.stringify(CRD) + ';' : ''}if(document.body)document.body.className=${JSON.stringify(bodyClass)};</script>`,
    '', body, '', ...js].join('\n') + '\n';
}
// 12MB 를 넘으면 가장 큰 제1유형 사진부터 뺀다 (제3유형은 빼지 않는다)
const drop = new Set(EATPH);
let out = build(drop);
const t1 = Object.entries(NAMES).filter(([fl, v]) => v.type === 'Type1' && !drop.has(fl)).sort((a, b) => b[1].size - a[1].size).map(([fl]) => fl);
while (Buffer.byteLength(out) > LIMIT && t1.length) { drop.add(t1.shift()); out = build(drop); }
if (Buffer.byteLength(out) > LIMIT) console.error('주의: 제1유형을 다 빼도 12MB 를 넘음 (' + Buffer.byteLength(out) + ')');
const photoStat = {
  넣음: Object.entries(NAMES).filter(([fl]) => !drop.has(fl)).map(([, v]) => `${v.id}(${v.type})`),
  뺌: [...drop].map((fl) => `${NAMES[fl].id}(${NAMES[fl].type}, ${NAMES[fl].size}B)`),
};
writeFileSync(OUT, out, 'utf8');

// 깨진 글자(U+FFFD) 검사 — 하나라도 있으면 파일을 지우고 중단
{
  const bad = out.split('\n').map((l, i) => [i + 1, l]).filter(([, l]) => l.includes(String.fromCharCode(0xFFFD)));
  if (bad.length) { unlinkSync(OUT); console.error('깨진 글자(U+FFFD)가 묶음에 ' + bad.length + '줄 들어 있어 파일을 지우고 중단했습니다. 첫 줄 번호: ' + bad[0][0] + ' · 앞부분: ' + JSON.stringify(bad[0][1].slice(0, 80))); process.exit(1); }
}
// 키가 들어갔는지(값으로) 검사 — 설정의 모든 kakao_* 키와 지도키.js 의 JS 키
let leaked = 0;
try {
  const cfg = JSON.parse(readFileSync(join(TOUR, '..', '..', '설정', '공공데이터.json'), 'utf8'));
  for (const [k, v] of Object.entries(cfg)) if (/key|token/i.test(k) && typeof v === 'string' && v.length >= 8 && out.includes(v)) leaked++;
} catch { /* 설정 없으면 건너뜀 */ }
try {
  const jk = readFileSync(join(TOUR, '..', '지도키.js'), 'utf8').match(/KAKAO_JS_KEY\s*=\s*["']([^"']{8,})["']/);
  if (jk && out.includes(jk[1])) leaked++;
} catch { /* 없으면 건너뜀 */ }
if (leaked) { unlinkSync(OUT); console.error('키가 묶음에 들어가 있어 파일을 지우고 중단했습니다 (' + leaked + '곳)'); process.exit(1); }
console.log(JSON.stringify({ out: OUT, bytes: Buffer.byteLength(out), scripts: srcs, fontLinks: fontLinks.length, bodyClass, 지도그림포함: embedded, 날씨사진: WX ? WX.label : '없음', 시간표사진: TR ? Object.keys(TR.dates).join(',') : '없음', 집중률: CRD ? CRD.from + '~' + CRD.to + ' ' + Object.keys(CRD.spots).length + '곳' : '없음', 키검사: '통과(0곳)', 깨진글자검사: '통과(U+FFFD 0줄)', 사진: photoStat }));
