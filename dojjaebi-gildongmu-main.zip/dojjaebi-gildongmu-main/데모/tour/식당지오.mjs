// 동해시 음식점현황 전체 좌표 만들기 (빌드 때만, 오프라인 1회): node 식당지오.mjs [--max N]
//  1) 도로명 주소 → 카카오 로컬 address.json (건물 위치, 정밀도 'a')
//  2) 안 되면 "동해 <상호>" keyword.json (동해시 둘레 20km, 이름이 비슷하고 주소가 동해시일 때만, 정밀도 'k')
//  결과는 수집캐시/식당지오캐시.json 에 실패까지 전부 저장 → 다시 돌려도 호출하지 않는다. 키는 설정/공공데이터.json 의 kakao_rest_key 만 읽고 어디에도 찍지 않는다.
//  동네수집.mjs 가 이 캐시를 읽어 town.data.js 를 만든다(브라우저에는 키가 전혀 가지 않음).
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const TOUR = dirname(fileURLToPath(import.meta.url));
const ROOT = join(TOUR, '..', '..');
const PUB = join(ROOT, '자료', '공공데이터');
const CACHE = join(TOUR, '수집캐시');
mkdirSync(CACHE, { recursive: true });
const FILE = join(CACHE, '식당지오캐시.json');
const OLD = join(CACHE, '편의지오캐시.json');
const MAX = process.argv.includes('--max') ? +process.argv[process.argv.indexOf('--max') + 1] : Infinity;
const BBOX = { la0: 37.40, la1: 37.62, ln0: 128.95, ln1: 129.20 };
const inBox = (la, ln) => la >= BBOX.la0 && la <= BBOX.la1 && ln >= BBOX.ln0 && ln <= BBOX.ln1;

function parse(t) {
  const rows = []; let r = [], f = '', q = false; t = t.replace(/^﻿/, '');
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ',') { r.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; r.push(f); f = ''; if (r.length > 1 || r[0]) rows.push(r); r = []; }
    else f += c;
  }
  if (f || r.length) { r.push(f); rows.push(r); }
  return rows.slice(1);
}
const BAD = (txt) => { for (const ch of String(txt)) { const n = ch.codePointAt(0); if (n === 0xFFFD || (n < 32 && n !== 9 && n !== 10 && n !== 13) || (n >= 127 && n <= 159) || (n >= 0x2500 && n <= 0x257F)) return true; } return false; };
const roadQ = (a) => { const m = /(동해시\s+)([^\s,()]+(?:로|길)\d*)\s?(\d+(?:-\d+)?)/.exec(a.replace(/(로|길)(\d)/, '$1$2')); return m ? '강원특별자치도 동해시 ' + m[2] + ' ' + m[3] : null; };
const normName = (s) => String(s || '').toLowerCase().replace(/\(.*?\)/g, '').replace(/[^0-9a-z가-힣]/g, '');
const stripSfx = (s) => s.replace(/(동해|북평|묵호|천곡|발한|망상|추암|본점|직영|점)$/g, '');
function nameOk(shop, place) {
  const a = stripSfx(normName(shop)), b = normName(place);
  if (a.length < 2 || b.length < 2) return false;
  return b.includes(a) || a.includes(stripSfx(b));
}

const rows = parse(readFileSync(join(PUB, '강원특별자치도_동해시_음식점현황_20260324_utf8.csv'), 'utf8')).filter((r) => !BAD(r.join('|')));
const cache = existsSync(FILE) ? JSON.parse(readFileSync(FILE, 'utf8')) : {};
// 예전에 받아 둔 주소 좌표(편의수집)를 시작 캐시로
if (existsSync(OLD)) { const o = JSON.parse(readFileSync(OLD, 'utf8')); for (const [q, c] of Object.entries(o)) if (c && !('a|' + q in cache)) cache['a|' + q] = [c[0], c[1]]; }

const KEY = JSON.parse(readFileSync(join(ROOT, '설정', '공공데이터.json'), 'utf8')).kakao_rest_key;
let calls = 0, last = 0;
const stat = { addr_calls: 0, kw_calls: 0, retry: 0, err: 0 };
async function call(path, params) {
  for (let t = 0; t < 5; t++) {
    const wait = 200 - (Date.now() - last); if (wait > 0) await new Promise((s) => setTimeout(s, wait));
    last = Date.now(); calls++;
    let r;
    try { r = await fetch('https://dapi.kakao.com/v2/local/search/' + path + '?' + new URLSearchParams(params), { headers: { Authorization: 'KakaoAK ' + KEY } }); }
    catch (e) { stat.retry++; await new Promise((s) => setTimeout(s, 1000 * (t + 1))); continue; }
    if (r.ok) return await r.json();
    if (r.status === 429 || r.status >= 500) { stat.retry++; await new Promise((s) => setTimeout(s, 1500 * (t + 1))); continue; }
    stat.err++; console.error('카카오 로컬 응답', r.status); return null; // 401·403 등: 재시도해도 같음
  }
  stat.err++; return null;
}
const save = () => writeFileSync(FILE, JSON.stringify(cache));

let n = 0;
for (const r of rows) {
  if (calls >= MAX) break;
  const name = r[2], road = r[3], q = roadQ(road);
  const rk = 'r|' + name + '|' + road;
  if (rk in cache) continue;
  let res = null;
  if (q) {
    const ak = 'a|' + q;
    if (!(ak in cache)) {
      stat.addr_calls++;
      const j = await call('address.json', { size: 1, query: q });
      if (j === null) { n++; continue; } // 오류는 캐시에 남기지 않음(다음에 다시)
      const d = j.documents && j.documents[0];
      cache[ak] = d ? [+(+d.y).toFixed(5), +(+d.x).toFixed(5)] : null;
    }
    if (cache[ak]) res = { y: cache[ak][0], x: cache[ak][1], p: 'a' };
  }
  if (!res) {
    const kk = 'k|' + name;
    if (!(kk in cache)) {
      stat.kw_calls++;
      const j = await call('keyword.json', { query: '동해 ' + name, x: 129.1, y: 37.52, radius: 20000, size: 5 });
      if (j === null) { n++; continue; }
      const hit = (j.documents || []).find((d) => /동해시/.test(d.address_name + ' ' + d.road_address_name) && nameOk(name, d.place_name) && inBox(+d.y, +d.x));
      cache[kk] = hit ? [+(+hit.y).toFixed(5), +(+hit.x).toFixed(5)] : null;
    }
    if (cache[kk]) res = { y: cache[kk][0], x: cache[kk][1], p: 'k' };
  }
  if (res && !inBox(res.y, res.x)) res = null; // 동해시 밖 좌표는 버림
  cache[rk] = res;
  if (++n % 50 === 0) { save(); console.log('진행', n, '/', rows.length, '호출', calls); }
}
save();
const vals = rows.map((r) => cache['r|' + r[2] + '|' + r[3]]);
console.log(JSON.stringify({ 행: rows.length, 처리끝: vals.filter((v) => v !== undefined).length, 주소성공: vals.filter((v) => v && v.p === 'a').length, 키워드성공: vals.filter((v) => v && v.p === 'k').length, 실패: vals.filter((v) => v === null).length, 호출: calls, ...stat }));
