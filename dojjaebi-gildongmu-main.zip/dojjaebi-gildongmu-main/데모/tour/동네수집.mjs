// 동네 탭 자료: 동해시 음식점현황(1,670곳) · 숙박업소(19곳) CSV → town.js (자동 생성, 직접 고치지 말 것)
//   node 동네수집.mjs      네트워크·키 없음. 좌표는 편의수집.mjs 가 이미 받아 둔 수집캐시/편의지오캐시.json 에 있는 주소만 붙인다(없으면 좌표 없음 → '코스에 넣기' 못 함).
//   줄 모양: 식당 [이름, 업태, 주소, 동, 위도|0, 경도|0, 한끼id|'', 정밀도 a(주소)|k(이름찾기)|''] · 숙소 [이름, 업태, 주소, 동, 전화, 위도|0, 경도|0]
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const TOUR = dirname(fileURLToPath(import.meta.url));
const PUB = join(TOUR, '..', '..', '자료', '공공데이터');
const D = createRequire(import.meta.url)(join(TOUR, 'places.js'));
function parse(t) { // 따옴표 안의 쉼표·줄바꿈을 지키는 CSV 읽기
  const rows = []; let r = [], f = '', q = false; t = t.replace(/^﻿/, '');
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ',') { r.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; r.push(f); f = ''; if (r.length > 1 || r[0]) rows.push(r); r = []; }
    else f += c;
  }
  if (f || r.length) { r.push(f); rows.push(r); }
  return rows.slice(1);
}
const geoFile = join(TOUR, '수집캐시', '편의지오캐시.json');
const geo = existsSync(geoFile) ? JSON.parse(readFileSync(geoFile, 'utf8')) : {};
const roadKey = (a) => { const m = /(동해시\s+)([^\s,()]+(?:로|길)\d*)\s?(\d+(?:-\d+)?)/.exec(a.replace(/(로|길)(\d)/, '$1$2')); return m ? '강원특별자치도 동해시 ' + m[2] + ' ' + m[3] : null; };
const dongOf = (road, jibun) => { const m = /\(([^)]*)\)\s*$/.exec(road); if (m) return m[1].split(',')[0].trim(); return (String(jibun || '').split(/\s+/)[2] || '').trim(); };
const shortAddr = (a) => a.replace(/^강원특별자치도\s+동해시\s+/, '').replace(/\s*\([^)]*\)\s*$/, '').trim();
const coord = (a) => { const k = roadKey(a), c = k && geo[k]; return c ? [c[0], c[1]] : [0, 0]; };
// 음식점 전체 좌표: 식당지오.mjs 가 카카오 로컬로 만든 캐시(키는 어디에도 없음). 값 {y,x,p:'a'(주소)|'k'(이름 찾기)}
const eatGeoFile = join(TOUR, '수집캐시', '식당지오캐시.json');
const eatGeo = existsSync(eatGeoFile) ? JSON.parse(readFileSync(eatGeoFile, 'utf8')) : {};
const BOX = { la0: 37.40, la1: 37.62, ln0: 128.95, ln1: 129.20 };
const r5 = (v) => Math.round(v * 1e5) / 1e5;
const eatPos = (name, road) => { const g = eatGeo['r|' + name + '|' + road]; if (g && g.y >= BOX.la0 && g.y <= BOX.la1 && g.x >= BOX.ln0 && g.x <= BOX.ln1) return [r5(g.y), r5(g.x), g.p]; const c = coord(road); return c[0] ? [r5(c[0]), r5(c[1]), 'a'] : [0, 0, '']; };
const eatId = new Map(D.eateries.map((e) => [e.name, e.id]));

// 이름이 깨진 줄(U+FFFD · 제어문자 · 상자그리기 U+2500-257F)은 화면에 내보내지 않고 센다
const BAD = (txt) => { for (const ch of String(txt)) { const n = ch.codePointAt(0); if (n === 0xFFFD || (n < 32 && n !== 9 && n !== 10 && n !== 13) || (n >= 127 && n <= 159) || (n >= 0x2500 && n <= 0x257F)) return true; } return false; };
const dropped = [];
const eats = parse(readFileSync(join(PUB, '강원특별자치도_동해시_음식점현황_20260324_utf8.csv'), 'utf8')).filter((r) => {
  if (BAD(r.join('|'))) { dropped.push(r[3] || '(주소 없음)'); return false; }
  return true;
}).map((r) => {
  const c = eatPos(r[2], r[3]);
  return [r[2], r[6], shortAddr(r[3]), dongOf(r[3], r[4]), c[0], c[1], eatId.get(r[2]) || '', c[2]];
});
console.log('깨진 글자 줄 제외: ' + dropped.length + '곳' + (dropped.length ? ' (' + dropped.join(' / ') + ')' : ''));
const lodging = parse(readFileSync(join(PUB, '강원특별자치도_동해시_숙박업소_20251104_utf8.csv'), 'utf8')).filter((r) => !BAD(r.join('|'))).map((r) => {
  const c = coord(r[2]);
  return [r[1], r[4], shortAddr(r[2]), dongOf(r[2], ''), /^0+-?0+-?0+$/.test(r[3]) ? '' : r[3], c[0], c[1]];
});
const T = {
  ref: { eats: '2026-03-24', lodging: '2025-11-04' },
  src: {
    eats: '동해시 음식점 현황(공공데이터포털) · 위치는 주소로 찾은 대략 위치 · 기준 2026-03-24',
    lodging: '동해시 숙박업소 · 공공데이터포털 · 기준 2025-11-04 (호텔·호스텔·콘도 19곳만 실려 있어요)',
  },
  eats, lodging,
};
const out = '// 자동 생성: node 동네수집.mjs (2026-10-17) — 직접 고치지 말 것\n(function(root){var T=' + JSON.stringify(T) + ';\nif(typeof module!=="undefined"&&module.exports)module.exports=T;else root.TOWN_DATA=T;})(typeof window!=="undefined"?window:globalThis);\n';
writeFileSync(join(TOUR, 'town.data.js'), out, 'utf8');
console.log(JSON.stringify({ 식당: eats.length, 깨진줄_제외: dropped.length, 식당_좌표: eats.filter((x) => x[4]).length, 식당_한끼id: eats.filter((x) => x[6]).length, 숙소: lodging.length, 숙소_좌표: lodging.filter((x) => x[5]).length, bytes: out.length }));
