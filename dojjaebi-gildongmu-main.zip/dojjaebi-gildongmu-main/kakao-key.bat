@echo off
title Kakao REST key
cd /d "%~dp0"
node run\kakao-key.mjs
timeout /t 3 >nul
