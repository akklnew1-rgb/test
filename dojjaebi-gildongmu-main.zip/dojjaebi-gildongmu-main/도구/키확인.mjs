// 공공데이터포털 인증키 정리 + 3개 API 호출 시험. 키는 화면에 찍지 않는다.
import { readFileSync, writeFileSync } from 'node:fs';

const cfgPath = new URL('../설정/공공데이터.json', import.meta.url);
const cfg = JSON.parse(readFileSync(cfgPath, 'utf8'));
let key = String(cfg.datagokr_key || '').replace('여기에_인증키_붙여넣기', '').trim();
if (key !== cfg.datagokr_key) {
  cfg.datagokr_key = key;
  writeFileSync(cfgPath, JSON.stringify(cfg, null, 2), 'utf8');
  console.log('안내문구 제거하고 저장함');
}
console.log(`키 길이 ${key.length}자, 앞 4자 ${key.slice(0, 4)}…`);

const tests = [
  ['병원정보(동해시)', `https://apis.data.go.kr/B551182/hospInfoServicev2/getHospBasisList?serviceKey=${key}&sidoCd=320000&sgguCd=320300&numOfRows=3&pageNo=1&_type=json`],
  ['약국정보(동해시)', `https://apis.data.go.kr/B551182/pharmacyInfoService/getParmacyBasisList?serviceKey=${key}&sidoCd=320000&sgguCd=320300&numOfRows=3&pageNo=1&_type=json`],
  ['응급의료기관(강원 동해시)', `https://apis.data.go.kr/B552657/ErmctInfoInqireService/getEgytListInfoInqire?serviceKey=${key}&Q0=${encodeURIComponent('강원특별자치도')}&Q1=${encodeURIComponent('동해시')}&numOfRows=3&pageNo=1&_type=json`],
];

for (const [name, url] of tests) {
  try {
    const r = await fetch(url);
    const t = await r.text();
    const safe = t.replace(key, '***');
    let summary = safe.slice(0, 300).replace(/\s+/g, ' ');
    try {
      const j = JSON.parse(safe);
      const h = j?.response?.header;
      const b = j?.response?.body;
      summary = `code=${h?.resultCode} msg=${h?.resultMsg} total=${b?.totalCount}`;
      const items = b?.items?.item;
      const first = Array.isArray(items) ? items[0] : items;
      if (first) summary += ` | 예: ${first.yadmNm || first.dutyName || JSON.stringify(first).slice(0, 80)}`;
    } catch {}
    console.log(`[${name}] HTTP ${r.status} → ${summary}`);
  } catch (e) {
    console.log(`[${name}] 실패: ${e.message}`);
  }
}
