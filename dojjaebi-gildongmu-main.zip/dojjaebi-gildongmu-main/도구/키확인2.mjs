import { readFileSync } from 'node:fs';
const key = JSON.parse(readFileSync(new URL('../설정/공공데이터.json', import.meta.url), 'utf8')).datagokr_key;
const get = async (url) => { const r = await fetch(url); const t = (await r.text()).replace(key, '***'); return [r.status, t]; };

// 1) 강원 시군구 코드 찾기 — 병원 200건 받아 sgguCd/sgguCdNm 집계
{
  const [s, t] = await get(`https://apis.data.go.kr/B551182/hospInfoServicev2/getHospBasisList?serviceKey=${key}&sidoCd=320000&numOfRows=500&pageNo=1&_type=json`);
  const j = JSON.parse(t); const items = j.response.body.items.item;
  const m = {}; for (const it of items) m[it.sgguCd] = it.sgguCdNm;
  console.log('강원 시군구코드:', JSON.stringify(m));
  console.log('총', j.response.body.totalCount);
}
// 2) 약국 — 다른 호출 형태 시험
for (const u of [
  `https://apis.data.go.kr/B551182/pharmacyInfoService/getParmacyBasisList?serviceKey=${key}&sidoCd=320000&numOfRows=3&_type=json`,
  `http://apis.data.go.kr/B551182/pharmacyInfoService/getParmacyBasisList?serviceKey=${key}&sidoCd=320000&numOfRows=3`,
]) { const [s, t] = await get(u); console.log('[약국]', s, t.slice(0, 250).replace(/\s+/g, ' ')); }
// 3) 응급실 실시간 가용병상
{
  const [s, t] = await get(`https://apis.data.go.kr/B552657/ErmctInfoInqireService/getEmrrmRltmUsefulSckbdInfoInqire?serviceKey=${key}&STAGE1=${encodeURIComponent('강원특별자치도')}&STAGE2=${encodeURIComponent('동해시')}&numOfRows=5&_type=json`);
  console.log('[실시간병상]', s, t.slice(0, 600).replace(/\s+/g, ' '));
}
// 4) 응급실 메시지
{
  const [s, t] = await get(`https://apis.data.go.kr/B552657/ErmctInfoInqireService/getEmrrmSrsillDissMsgInqire?serviceKey=${key}&Q0=${encodeURIComponent('강원특별자치도')}&Q1=${encodeURIComponent('동해시')}&numOfRows=5&_type=json`);
  console.log('[응급실메시지]', s, t.slice(0, 400).replace(/\s+/g, ' '));
}
