// 카카오 REST API 키 넣기: 입력 창 → 키 시험(카카오 로컬 검색) → 설정/공공데이터.json 에 저장.
// 키 값은 화면·로그에 찍지 않는다.
import { readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const cfgUrl = new URL('../설정/공공데이터.json', import.meta.url);

// PowerShell 창은 한글이 깨지지 않게 UTF-16 으로 인코딩해서 넘긴다 (-ExecutionPolicy 넣지 않음 — 이 PC 에서 명령이 안 돎)
function ps(script) {
  const enc = Buffer.from(script, 'utf16le').toString('base64');
  return execFileSync('powershell', ['-NoProfile', '-EncodedCommand', enc], { encoding: 'utf8' }).trim();
}
function inputBox(msg, title) {
  const q = (s) => s.replace(/'/g, "''");
  return ps(`[Console]::OutputEncoding=[Text.Encoding]::UTF8; Add-Type -AssemblyName Microsoft.VisualBasic; [Microsoft.VisualBasic.Interaction]::InputBox('${q(msg)}','${q(title)}','')`);
}
function msgBox(msg, title, icon = 'Information') {
  const q = (s) => s.replace(/'/g, "''");
  ps(`Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('${q(msg)}','${q(title)}','OK','${icon}') | Out-Null`);
}

const TITLE = '카카오 REST 키 넣기';
const key = inputBox(
  '카카오 개발자 사이트 → 내 애플리케이션 → [앱] → [플랫폼 키] 의\n"REST API 키" 를 복사해서 아래 칸에 붙여 넣고 [확인]을 누르세요.\n\n(키는 이 PC 의 설정 파일에만 저장됩니다)',
  TITLE,
).replace(/\s+/g, '');

if (!key) { msgBox('입력이 없어 아무것도 바꾸지 않았습니다.', TITLE, 'Warning'); process.exit(1); }
if (!/^[A-Za-z0-9]{20,64}$/.test(key)) { msgBox('키 모양이 이상합니다 (영문·숫자 32자 정도여야 함).\n다시 복사해서 실행해 주세요.', TITLE, 'Error'); process.exit(1); }

// 키 시험: 카카오 로컬 키워드 검색으로 "묵호역" 찾기
let ok = false, why = '';
try {
  const r = await fetch('https://dapi.kakao.com/v2/local/search/keyword.json?size=1&query=' + encodeURIComponent('묵호역'), { headers: { Authorization: 'KakaoAK ' + key } });
  const t = await r.text();
  if (r.ok && t.includes('documents')) ok = true;
  else why = `HTTP ${r.status} ` + (t.match(/"msg"\s*:\s*"([^"]*)"/)?.[1] || t.match(/"message"\s*:\s*"([^"]*)"/)?.[1] || '').slice(0, 120);
} catch (e) { why = '인터넷 연결 오류: ' + e.message; }

// 저장 (시험 실패여도 저장은 하되 알림) — 원본은 .bak 로 남긴다
const raw = readFileSync(cfgUrl, 'utf8').replace(/^﻿/, '');
const cfg = JSON.parse(raw);
copyFileSync(cfgUrl, new URL('../설정/공공데이터.json.bak', import.meta.url));
const out = { kakao_rest_key: key, ...Object.fromEntries(Object.entries(cfg).filter(([k]) => k !== 'kakao_rest_key')) };
writeFileSync(cfgUrl, JSON.stringify(out, null, 2) + '\n', 'utf8');

if (ok) {
  console.log('kakao_rest_key saved, test OK (' + key.length + ' chars)');
  msgBox('저장했고, 키 시험도 통과했습니다.\n\n이제 Claude 에게 "키 넣음" 이라고 알려 주세요.', TITLE);
} else {
  console.log('kakao_rest_key saved, test FAILED: ' + why);
  msgBox('저장은 했지만 키 시험이 실패했습니다.\n' + why + '\n\n· REST API 키가 맞는지(JavaScript 키 아님)\n· [카카오맵] 사용 설정이 ON 인지 확인해 주세요.\n그래도 Claude 에게 알려 주시면 이어서 봅니다.', TITLE, 'Warning');
}
