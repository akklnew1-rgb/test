// 설정/공공데이터.json 의 카카오 JavaScript 키를 데모/지도키.js 로 옮긴다 (index.html 이 읽음).
// 키 값은 화면에 찍지 않는다.
import { readFileSync, writeFileSync } from 'node:fs';
const cfg = JSON.parse(readFileSync(new URL('../설정/공공데이터.json', import.meta.url), 'utf8'));
const k = String(cfg.kakao_js_key || '').replace('여기에_카카오_JavaScript_키_붙여넣기', '').trim();
const out = new URL('../데모/지도키.js', import.meta.url);
writeFileSync(out, `window.KAKAO_JS_KEY=${JSON.stringify(k)};\n`, 'utf8');
console.log(k ? `카카오맵 키 적용됨 (${k.length}자)` : '카카오맵 키 없음 → 임시 지도로 열림');
