// 신청서 초안 md → A4 HTML → Chrome 으로 PDF
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const [src, out] = process.argv.slice(2);
const md = fs.readFileSync(src, 'utf8').replace(/\r/g, '');
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const inline = s => esc(s)
  .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  .replace(/`(.+?)`/g, '<code>$1</code>')
  .replace(/\[ \]/g, '<span class="box">☐</span>');

const lines = md.split('\n');
let html = '', i = 0;
while (i < lines.length) {
  const l = lines[i];
  if (/^\|/.test(l)) {
    const rows = [];
    while (i < lines.length && /^\|/.test(lines[i])) rows.push(lines[i++]);
    const cells = r => r.replace(/^\||\|$/g, '').split('|').map(c => c.trim());
    const head = cells(rows[0]);
    html += '<table><thead><tr>' + head.map(c => `<th>${inline(c)}</th>`).join('') + '</tr></thead><tbody>';
    for (const r of rows.slice(2)) html += '<tr>' + cells(r).map((c, k) => k === 0 ? `<th scope="row">${inline(c)}</th>` : `<td>${inline(c)}</td>`).join('') + '</tr>';
    html += '</tbody></table>';
    continue;
  }
  if (/^- /.test(l)) {
    html += '<ul>';
    while (i < lines.length && /^- /.test(lines[i])) html += `<li>${inline(lines[i++].slice(2))}</li>`;
    html += '</ul>';
    continue;
  }
  let m;
  if ((m = l.match(/^(#{1,3}) (.*)/))) html += `<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`;
  else if (/^---$/.test(l)) html += '';
  else if (l.trim()) html += `<p>${inline(l)}</p>`;
  i++;
}

const page = `<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>신청서 초안</title><style>
@page { size: A4; margin: 16mm 15mm 18mm; }
body { font-family: "Malgun Gothic", "맑은 고딕", sans-serif; font-size: 10.5pt; line-height: 1.6; color: #1d2430; word-break: keep-all; }
h1 { font-size: 19pt; margin: 0 0 4pt; color: #0b3b66; border-bottom: 3px solid #0b3b66; padding-bottom: 6pt; }
h1 + p { color: #3d4a5c; margin: 6pt 0 2pt; }
h2 { font-size: 13.5pt; color: #0b3b66; margin: 18pt 0 6pt; padding-left: 8pt; border-left: 5px solid #e07a1f; break-after: avoid; }
p { margin: 3pt 0; }
ul { margin: 4pt 0; padding-left: 16pt; }
li { margin: 2pt 0; }
table { width: 100%; border-collapse: collapse; margin: 4pt 0 6pt; table-layout: fixed; }
th, td { border: 1px solid #b9c3d0; padding: 5pt 7pt; vertical-align: top; text-align: left; }
thead th { background: #0b3b66; color: #fff; font-weight: 700; }
tbody th { background: #eef3f8; width: 22%; font-weight: 700; color: #0b3b66; }
tr { break-inside: avoid; }
strong { color: #0b2a4a; }
code { font-family: Consolas, monospace; background: #f1f3f6; padding: 0 3pt; border-radius: 2pt; }
.box { color: #c0392b; font-weight: 700; }
</style></head><body>${html}</body></html>`;

const tmpHtml = path.join(path.dirname(out), 'tmp_draft.html');
fs.writeFileSync(tmpHtml, page);
const tmpPdf = path.join(path.dirname(out), 'tmp_draft.pdf');
execFileSync('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--disable-gpu', '--no-pdf-header-footer',
  `--print-to-pdf=${tmpPdf}`, 'file:///' + tmpHtml.replace(/\\/g, '/'),
], { stdio: 'inherit' });
fs.copyFileSync(tmpPdf, out);
console.log('OK', out, fs.statSync(out).size);
