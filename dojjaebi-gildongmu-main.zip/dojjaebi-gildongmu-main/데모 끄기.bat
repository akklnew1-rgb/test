@echo off
title Donghae demo stop
cd /d "%~dp0"
node run\stop.mjs
timeout /t 3 >nul
