// Vercel 빌드: 시연 화면(데모/tour)에서 공개해도 되는 파일만 public/ 로 복사하고, 지도 키 파일을 환경 변수로 만든다.
// 공개 규칙은 run/serve.mjs 의 allowed() 와 같다 (캐시·시험·수집 스크립트·README 는 빼기).
import { cpSync, mkdirSync, rmSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, extname, relative } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const SRC = join(ROOT, '데모', 'tour');
const OUT = join(ROOT, 'public');
const ALLOW = new Set(['.html', '.js', '.css', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.ico', '.mp3']);
const DENY_DIR = new Set(['수집캐시', '길캐시', 'tour_백업_사진전', 'backup', 'node_modules']);
const ok = (rel) => {
  const parts = rel.split(/[\\/]/).filter(Boolean), name = parts[parts.length - 1] || '';
  if (parts.some((s) => DENY_DIR.has(s) || s.startsWith('.'))) return false;
  if (/\.before|\.bak|\.base\./i.test(name) || /^test[.\-_]/i.test(name) || /\.test\./i.test(name)) return false;
  return ALLOW.has(extname(name).toLowerCase());
};

rmSync(OUT, { recursive: true, force: true });
mkdirSync(join(OUT, 'tour'), { recursive: true });
let n = 0;
(function walk(dir) {
  for (const e of readdirSync(dir)) {
    const p = join(dir, e), rel = relative(SRC, p);
    if (statSync(p).isDirectory()) { if (!DENY_DIR.has(e) && !e.startsWith('.')) walk(p); continue; }
    if (!ok(rel)) continue;
    mkdirSync(dirname(join(OUT, 'tour', rel)), { recursive: true });
    cpSync(p, join(OUT, 'tour', rel)); n++;
  }
})(SRC);
// index.html 이 ../지도키.js 를 읽는다 → public/지도키.js (카카오 JavaScript 키는 원래 브라우저에 보이는 키, 도메인으로 제한됨)
writeFileSync(join(OUT, '지도키.js'), `window.KAKAO_JS_KEY=${JSON.stringify(process.env.KAKAO_JS_KEY || '')};\n`);
writeFileSync(join(OUT, 'index.html'), '<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=/tour/"><a href="/tour/">도째비 길동무</a>\n');
console.log(`public/: ${n} files, kakao key ${process.env.KAKAO_JS_KEY ? 'set' : 'missing'}`);
