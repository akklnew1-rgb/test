@echo off
title Donghae demo server
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js is not installed. Install from https://nodejs.org then try again.
  pause
  exit /b 1
)
node run\open.mjs 
if errorlevel 1 (
  echo [ERROR] Demo did not start. See run\open.log
  pause
  exit /b 1
)
timeout /t 3 >nul 2>&1
