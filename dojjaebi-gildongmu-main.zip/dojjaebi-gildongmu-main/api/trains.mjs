// Vercel 함수: /api/trains?date=YYYYMMDD&from=묵호&to=청량리 — run/trains.mjs 를 그대로 쓴다
import { getTrains } from '../run/trains.mjs';

export default async function handler(req, res) {
  const q = new URL(req.url, 'http://x').searchParams;
  try {
    const v = await getTrains(q.get('date'), q.get('from'), q.get('to'));
    res.setHeader('Cache-Control', v && v.ok ? 's-maxage=3600' : 'no-store');
    res.status(v && v.error === 'bad_request' ? 400 : 200).json(v);
  } catch { res.status(200).json({ ok: false, error: 'fail' }); }
}
