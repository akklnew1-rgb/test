// Vercel 함수: /api/crowd[?date=YYYYMMDD] — run/crowd.mjs 를 그대로 쓴다
import { crowdResponse } from '../run/crowd.mjs';

export default async function handler(req, res) {
  const q = new URL(req.url, 'http://x').searchParams;
  try {
    const r = await crowdResponse(q.get('date'));
    res.setHeader('Cache-Control', r.body && r.body.ok ? 's-maxage=3600' : 'no-store');
    res.status(r.status).json(r.body);
  } catch { res.status(200).json({ ok: false, error: 'fail' }); }
}
