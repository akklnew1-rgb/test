// Vercel 함수: /api/weather — run/weather.mjs 를 그대로 쓴다 (키는 환경 변수 DATAGOKR_KEY)
import { getWeather } from '../run/weather.mjs';

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 's-maxage=600');
  try { res.status(200).json(await getWeather()); } catch { res.status(200).json({ error: 'fail' }); }
}
